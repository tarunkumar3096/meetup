#include <stdio.h>
#include <stdlib.h>
#include <vector.h>
#define APPEND 1
#define PREPEND 2
#define INSERT 3
#define CHOP 4
#define BEHEAD 5
#define DELETE 6
#define SET 7
#define GET 8
#define IS_EMPTY 9
#define FIRST 10
#define LAST 11
#define SIZE 12
#define MOVE 13
#define SPLICE 14
#define CLEAR 15
#define DESTRUCT 16
#define BUBBLE_SORT 1
#define VECTOR_OPERATION 2
#define EXIT 3
int destroy;
int breakloop;
static void clear_buff(void)
{
	char c;

	while ((c = getchar()) != '\n' && (c != EOF))
		;
}
static int validate_input(struct element *element)
{
	switch (element->field_type) {
	case CHAR:
		while (1) {
			printf("Enter a char element\n");
			if (scanf(" %c", &element->field.char_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	case SHORT:
		while (1) {
			printf("Enter a short element\n");
			if (scanf(" %hu", &element->field.short_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	case INT:
		while (1) {
			printf("Enter a integer element\n");
			if (scanf(" %d", &element->field.int_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	case LONG:
		while (1) {
			printf("Enter a long element\n");
			if (scanf(" %ld", &element->field.long_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	case FLOAT:
		while (1) {
			printf("Enter a float element\n");
			if (scanf(" %f", &element->field.float_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	case DOUBLE:
		while (1) {
			printf("Enter a double element\n");
			if (scanf(" %lf", &element->field.double_g) == 0) {
				clear_buff();
				continue;
			} else
				break;
		}
		break;
	}
	return 0;
}
static void get_input(struct element *element)
{
	int choice = 0;

	printf("Enter the element type\n");
	while (1) {
	printf("0.Char\n1.SHORT\n2.INT\n3.LONG\n4.FLOAT\n5.DOUBLE\n");
	if (scanf(" %d", &choice) == 0 || (choice < 0 || choice > 5)) {
		clear_buff();
		printf("Enter valid choice\n");
		continue;
	} else
		break;
	}
	getchar();
	element->field_type = choice;
	validate_input(element);
}
static void display_separate(struct vector *v, struct element *element)
{
	switch (element->field_type) {
	case CHAR:
		printf("%c, %d\n", (*element).field.char_g,
		       (*element).field_type);
		break;
	case SHORT:
		printf("%hu, %d\n", (*element).field.short_g,
		       (*element).field_type);
		break;
	case INT:
		printf("%d, %d\n", (*element).field.int_g,
		       (*element).field_type);
		break;
	case LONG:
		printf("%ld, %d\n", (*element).field.long_g,
		       (*element).field_type);
		break;
	case FLOAT:
		printf("%f, %d\n", (*element).field.float_g,
		       (*element).field_type);
		break;
	case DOUBLE:
		printf("%lf, %d\n", (*element).field.double_g,
		       (*element).field_type);
		break;
	}
}
static void display(struct vector *v, struct element *element)
{
	struct vector *node = v;

	for_each(tmp, node) {
		switch (TYPE(tmp)) {
		case CHAR:
			printf("%c, %d\n", VALUE(tmp).char_g, TYPE(tmp));
			break;
		case SHORT:
			printf("%hu, %d\n", VALUE(tmp).short_g, TYPE(tmp));
			break;
		case INT:
			printf("%d, %d\n", VALUE(tmp).int_g, TYPE(tmp));
			break;
		case LONG:
			printf("%ld, %d\n", VALUE(tmp).long_g, TYPE(tmp));
			break;
		case FLOAT:
			printf("%f, %d\n", F_VALUE(tmp), TYPE(tmp));
			break;
		case DOUBLE:
			printf("%lf, %d\n", D_VALUE(tmp), TYPE(tmp));
			break;
		}
	}
}
static int bubble_sort(struct vector *bubble)
{
	struct element element;
	struct element element1;
	int i = 0;
	int j = 0;

	element.field_type = INT;
	printf("Enter 10 integer elements\n");
	for (i = 0; i < 10; i++) {
		while (1) {
			if (scanf("%d", &element.field.int_g) == 0) {
				clear_buff();
				printf("Enter correct input\n");
			} else {
				bubble->append(bubble, element);
				break;
			}
		}
	}
	for (i = 1; i <= 10; i++) {
		for (j = 1; j <= 10 - i; j++) {
			bubble->get(bubble, j, &element);
			bubble->get(bubble, j+1, &element1);
			if (element.field.int_g > element1.field.int_g)
				bubble->move(bubble, j, j+1);
		}
	}
	printf("\n");
	for_each(tmp, bubble)
		printf("%d, %d\n", VALUE(tmp).int_g, TYPE(tmp));
	printf("\n");
	return 0;
}
static int operation(struct vector *v, struct element *element)
{
	int operation = 0;
	int pos = 0;
	int new_pos = 0;
	struct vector *split;
	struct element get;
	char choice;
	int check = 0;

	while (1) {
		printf("Enter the operation\n");
		printf("1.append\t2.prepend \t3.insert\t4.chop   \t");
		printf("5.behead \t6.delete \t7.set   \t8.get\n");
		printf("9.is empty\t10.first\t11.last \t12.size \t");
		printf("13.move  \t14.splice\t15.clear \t16.destruct\n");
		scanf(" %d", &operation);
		switch (operation) {
		case APPEND:
			get_input(element);
			v->append(v, *element);
			display(v, element);
			break;
		case PREPEND:
			get_input(element);
			v->prepend(v, *element);
			display(v, element);
			break;
		case INSERT:
			while (1) {
				get_input(element);
				printf("Enter the position ");
				printf("to insert the element\n");
				scanf(" %d", &pos);
				check = v->insert(v, pos, *element);
				if (check == -1) {
					printf("incorrect position\n");
					clear_buff();
					continue;
				} else
					break;
			}
			display(v, element);
			break;
		case CHOP:
			check = v->chop(v);
			printf("Element chopped\n");
			if (check == -1)
				printf("Vector empty\n");
			else
				display(v, element);
			break;
		case BEHEAD:
			check = v->behead(v);
			printf("Element beheaded\n");
			if (check == -1)
				printf("Vector empty\n");
			else
				display(v, element);
			break;
		case DELETE:
			printf("Enter the position ");
			printf("to delete the element\n");
			scanf(" %d", &pos);
			check = v->delete(v, pos);
			if (check == -1)
				printf("Vector empty\n");
			else if (check == -2)
				printf("Unable to delete element\n");
			else
				display(v, element);
			break;
		case SET:
			get_input(element);
			printf("Enter the postion ");
			printf("to set the value to the node\n");
			scanf(" %d", &pos);
			check = v->set(v, pos, *element);
			if (check == -1)
				printf("Incorrect position\n");
			else
				display(v, element);
			break;
		case GET:
			printf("Enter the position ");
			printf("to get the value of the node\n");
			scanf(" %d", &pos);
			check = v->get(v, pos, &get);
			if (check == -1)
				printf("Unable to get data\n");
			else
				display_separate(v, &get);
			break;
		case IS_EMPTY:
			check = v->is_empty(v);
			if (check == -1)
				printf("Not Empty\n");
			else
				display(v, element);
			break;
		case FIRST:
			check = v->first(v, element);
			if (check == -1)
				printf("Vector empty\n");
			else
				display_separate(v, element);
			break;
		case LAST:
			check = v->last(v, element);
			if (check == -1)
				printf("Vector empty\n");
			else
				display_separate(v, element);
			break;
		case SIZE:
			check = v->size(v);
			if (check == -1)
				printf("Vector empty\n");
			else
				printf("size=%d\n", check);
			break;
		case MOVE:
			printf("Enter the source position\n");
			scanf(" %d", &pos);
			printf("Enter the destination position\n");
			scanf(" %d", &new_pos);
			check = v->move(v, pos, new_pos);
			if (check == -1)
				printf("Unable to move data\n");
			else
				display(v, element);
			break;
		case SPLICE:
			printf("Enter the position ");
			printf("to splice the vector\n");
			scanf(" %d", &pos);
			split = v->splice(v, pos);
			if (split == NULL)
				printf("Unable to splice\n");
			else {
				display(v, element);
				printf("\n");
				display(split, element);
			}
			break;
		case CLEAR:
			check = v->clear(v);
			if (check == -1)
				printf("Vector already cleared\n");
			else
				display(v, element);
			break;
		case DESTRUCT:
			v->destruct(v);
			printf("Vector destructed\n");
			destroy = 1;
			return 0;
		default:
			printf("Incorrect value.");
			clear_buff();
			continue;
		}
		while (1) {
			printf("Do you want to continue(y/n)\n");
			scanf(" %c", &choice);
			if (choice != 'y' && choice != 'n')
				continue;
			else if (choice == 'y') {
				breakloop = 1;
				break;
			} else if (choice == 'n')
				return 0;
		}
		if (breakloop == 1) {
			continue;
			breakloop = 0;
		}
	}
}
static int choice(struct vector *v)
{
	int choice;
	struct vector *bubble;
	struct element element;

	printf("Enter choice\n");
	while (1) {
		printf("1.Bubble Sort\t2.Vector Operation\t3.EXIT\n");
		scanf(" %d", &choice);
		switch (choice) {
		case BUBBLE_SORT:
			bubble = malloc(sizeof(struct vector));
			vector(bubble);
			bubble_sort(bubble);
			free(bubble);
			break;
		case VECTOR_OPERATION:
			if (destroy == 1) {
				v = malloc(sizeof(struct vector));
				vector(v);
				destroy = 0;
			}
			operation(v, &element);
			break;
		case EXIT:
			if (destroy == 0)
				free(v);
			exit(0);
		default:
			printf("Enter correct choice\n");
			clear_buff();
			continue;
		}
	}
	return 0;
}
int main(void)
{
	struct vector *v = malloc(sizeof(struct vector));

	vector(v);
	choice(v);
	return 0;
}
