#ifndef __VECTOR_H__
#define __VECTOR_H__

typedef union g_datatype {
	char char_g;
	short short_g;
	int int_g;
	long long_g;
	float float_g;
	double double_g;
} g_datatype;

enum g_typename {
	CHAR,
	SHORT,
	INT,
	LONG,
	FLOAT,
	DOUBLE
};

struct element {
	g_datatype field;
	enum g_typename field_type;
};

struct vector_node {
	struct element element;
	struct vector_node *next;
	struct vector_node *prev;
};

struct vector {
	struct vector_node *head;
	struct vector_node *tail;
	/* # Internal APIs # */
	/*
	 * append() - This function will append at the tail position
	 of the vector.
	 * @vector - structure variable containing vector.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if appended
	 *        -1, otherwise.
	 */
	int (*append)(struct vector *vector, struct element element); /* V1 */
	/*
	 * prepend() - This function will prepend at the head position
	 of the vector.
	 * @vector - structure variable containing vector.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if prepended
	 *        -1, otherwise.
	 */
	int (*prepend)(struct vector *vector, struct element element);/* V1 */
	/*
	 * insert() - This function will insert the node based
	 on the postion given.
	 * @vector - structure variable containing vector.
	 * @pos - Position at which node is inserted.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if inserted.
	 *        -1, otherwise.
	 */
	int (*insert)(struct vector *vector, int pos,
		      struct element element);/* V1 */
	/*
	 * chop() - This function will remove the element at the end.
	 * @vector - structure variable containing vector.
	 * Return: 0, if chopped.
	 *        -1, otherwise.
	 */
	int (*chop)(struct vector *vector); /* V1 */
	/*
	 * behead() - This function will remove the first element.
	 * @vector - structure variable containing vector.
	 * Return: 0, if beheaded.
	 *        -1, otherwise.
	 */
	int (*behead)(struct vector *vector); /* V1 */
	/*
	 * delete() - This function will delete the node based
	 on the postion given.
	 * @vector - structure variable containing vector.
	 * @pos - Position at which node is deleted.
	 * Return: 0, if deleted.
	 *        -1, otherwise.
	 */
	int (*delete)(struct vector *vector, int pos); /* V1 */
	/*
	 * set() - This function will set the new element into
	 the specified node based on position.
	 * @vector - structure variable containing vector.
	 * @pos - This will specify the position to set the value
	 to the node.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if set.
	 *        -1, otherwise.
	 */
	int (*set)(struct vector *vector, int pos,
		   struct element element); /* V1 */
	/*
	 * get () - It will return the element of the
	 node based on the given position.
	 * @vector - structure variable containing vector.
	 * @pos - It will specify the position to get the element.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if element is get.
	 *        -1, otherwise.
	 */
	int (*get)(struct vector *vector, int pos,
		   struct element *element); /* V1 */
	/*
	 * is_empty () - It will check whether the vector
	 is empty or not.
	 * @vector - structure variable containing vector.
	 * Return: 0, if vector is empty.
	 *        -1, otherwise.
	 */
	int (*is_empty)(struct vector *vector);
	/* Gives the element value but doesn't alter the list */

	/*
	 * first () - It will return the first element of the vector.
	 * @vector - structure variable containing vector.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if first element is present.
	 *        -1, otherwise.
	 */
	int (*first)(struct vector *vector, struct element *element); /* V2 */
	/*
	 * last () - It will return the last element of the vector.
	 * @vector - structure variable containing vector.
	 * @element - structure variable containg element field
	 along with field type.
	 * Return: 0, if last element is present.
	 *        -1, otherwise.
	 */
	int (*last)(struct vector *vector, struct element *element); /* V2 */
	/* Removes all the elements, but vector is
	 * available for other operations
	 */
	/*
	 * clear() - This function will clear all nodes present
	 in the vector.
	 * @vector - structure variable containing vector.
	 * Return: 0, if cleared.
	 *        -1, otherwise.
	 */
	int (*clear)(struct vector *vector); /* V2 */
	/* Frees the complete vector useful only when dynamically allocated */
	/*
	 * destruct() - This function will destroy the vector.
	 * @vector - structure variable containing vector.
	 * Return: 0, if destruct.
	 *        -1, otherwise.
	 */
	int (*destruct)(struct vector *vector); /* V2 */
	/*
	 * size() - It will return the size of the vector.
	 * @vector - structure variable containing vector.
	 * Return: size, returns the size.
	 *        -1, otherwise.
	 */
	int (*size)(struct vector *vector); /* V2 */
	/*
	 * move() - This function will move the element from
	 one position to another position.
	 * @vector - structure variable containing vector.
	 * @old_pos - This will specify the source position.
	 * @new_pos - This will specify the destination position.
	 * Return: 0, if moved.
	 *        -1, otherwise.
	 */
	int (*move)(struct vector *vector, int old_pos, int new_pos); /* V2 */
	/*
	 * Splices the vector into two and returns
	 * second vector which starts from the `pos`.
	 */

	/*
	 * splice() - It will split a vector into two vectors
	 based on the position.
	 * @vector - structure variable containing vector.
	 * @pos - Splice is done based on the position
	 * Return: struct *, returns the structure pointer of vector.
	 *        NULL, otherwise.
	 */
	struct vector * (*splice)(struct vector *vector, int pos); /* V2 */
};

#define ELEMENT(data, type) (						\
			     (struct element) { .field = (g_datatype)data, \
					     .field_type = type})

#define for_each(entry, vector)				\
	for (struct vector_node *entry = vector->head;	\
	     entry != NULL; entry = entry->next)

#define for_each_rev(entry, vector)			\
	for (struct vector_node *entry = vector->tail;	\
	     entry != NULL; entry = entry->prev)

#define VALUE(entry)  entry->element.field
#define TYPE(entry)   entry->element.field_type

#define F_VALUE(entry)  entry->element.field.float_g
#define D_VALUE(entry)  entry->element.field.double_g
/* # Public APIs # */
struct vector vector(struct vector *vector);

#endif /* __VECTOR_H__ */
