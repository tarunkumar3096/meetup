#include <stdio.h>
#include <stdlib.h>
#include <vector.h>
static int append(struct vector *vector, struct element element);
static int prepend(struct vector *vector, struct element element);
static int insert(struct vector *vector, int pos, struct element element);
static int chop(struct vector *vector);
static int behead(struct vector *vector);
static int delete(struct vector *vector, int pos);
static int clear(struct vector *vector);
static int destruct(struct vector *vector);
static int move(struct vector *vector, int old_pos, int new_pos);
static int set(struct vector *vector, int pos, struct element element);
static int first(struct vector *vector, struct element *element);
static int last(struct vector *vector, struct element *element);
static int get(struct vector *vector, int pos, struct element *element);
static int is_empty(struct vector *vector);
static int size(struct vector *vector);
static struct vector *splice(struct vector *vector, int pos);
struct vector vector(struct vector *vector)
{
	vector->head = NULL;
	vector->tail = NULL;
	vector->append = &append;
	vector->prepend = &prepend;
	vector->insert = &insert;
	vector->chop = &chop;
	vector->behead = &behead;
	vector->delete = &delete;
	vector->set = &set;
	vector->get = &get;
	vector->is_empty = &is_empty;
	vector->clear = &clear;
	vector->first = &first;
	vector->last = &last;
	vector->size = &size;
	vector->move = &move;
	vector->splice = &splice;
	vector->destruct = &destruct;
	return *vector;
};

static int append(struct vector *vector, struct element element)
{
	struct vector_node *temp;
	struct vector_node *pointer;

	temp = (struct vector_node *)malloc(sizeof(struct vector_node));
	temp->element = element;
	if (vector->head == NULL) {
		vector->head = temp;
		vector->tail = temp;
		vector->head->next = NULL;
	} else {
		vector->tail->next = temp;
		pointer = vector->tail;
		vector->tail = vector->tail->next;
		temp->next = NULL;
		vector->tail->prev = pointer;
	}
	return 0;
}
static int prepend(struct vector *vector, struct element element)
{
	struct vector_node *next_temp;

	next_temp = (struct vector_node *)malloc(sizeof(struct vector_node));
	next_temp->element = element;
	if (vector->head == NULL) {
		vector->head = next_temp;
		vector->tail = next_temp;
	} else {
		next_temp->next = vector->head;
		vector->head->prev = next_temp;
		vector->head = next_temp;
	}
	return 0;
}
static int insert(struct vector *vector, int pos, struct element element)
{
	struct vector_node *temp_insert;
	struct vector_node *temp;
	struct vector_node *t_prev;
	struct vector_node *pointer;

	temp_insert = (struct vector_node *)malloc(sizeof(struct vector_node));
	temp_insert->element = element;
	int i = 1;
	int append;

	append = size(vector);
	temp = vector->head;
	if (vector->head == NULL && pos == 1) {
		vector->head = temp_insert;
		vector->tail = temp_insert;
		vector->head->next = NULL;
	} else if (vector->head == NULL && (pos > 1 || pos < 1))
		return -1;
	else if (pos < 1)
		return -1;
	else if (pos == 1) {
		temp_insert->next = vector->head;
		vector->head->prev = temp_insert;
		vector->head = temp_insert;
	} else if ((pos > 1) && pos <= (append)) {
		while (1) {
			if (i != pos) {
				i++;
				temp = temp->next;
			} else if (i == pos) {
				t_prev = temp->prev;
				t_prev->next = temp_insert;
				temp_insert->prev = t_prev;
				temp_insert->next = temp;
				temp->prev = temp_insert;
				break;
			}
		}
	} else if (pos == (append+1)) {
		vector->tail->next = temp_insert;
		pointer = vector->tail;
		vector->tail = vector->tail->next;
		temp_insert->next = NULL;
		vector->tail->prev = pointer;
	} else if (pos > append) {
		return -1;
	}
	return 0;
}
static int chop(struct vector *vector)
{
	struct vector_node *chop;
	struct vector_node *pointer;

	if (vector->head == NULL)
		return -1;
	if (vector->head->next == NULL) {
		free(vector->head);
		vector->head = NULL;
		vector->tail = NULL;
		return -1;
	}
	pointer = vector->tail;
	chop = pointer->prev;
	chop->next = NULL;
	vector->tail = chop;
	free(pointer);
	return 0;
}
static int behead(struct vector *vector)
{
	struct vector_node *behead;
	struct vector_node *pointer;

	if (vector->head == NULL)
		return -1;
	if (vector->head->next == NULL) {
		free(vector->head);
		vector->head = NULL;
		vector->tail = NULL;
		return -1;
	}
	pointer = vector->head;
	behead = pointer->next;
	behead->prev = NULL;
	vector->head = behead;
	free(pointer);
	return 0;
}
static int delete(struct vector *vector, int pos)
{
	struct vector_node *temp;
	struct vector_node *t_prev;
	int i = 1;
	int append;

	append = size(vector);
	temp = vector->head;
	if (vector->head == NULL)
		return -1;
	else if (pos > append)
		return -2;
	else if (pos == 1) {
		behead(vector);
	} else if ((pos > 1) && pos < (append)) {
		while (1) {
			if (i != pos) {
				i++;
				temp = temp->next;
			} else if (i == pos) {
				t_prev = temp->prev;
				t_prev->next = temp->next;
				temp->next->prev = t_prev;
				free(temp);
				break;
			}
		}
	} else if (pos == (append)) {
		chop(vector);
	} else if (pos > append) {
		return -1;
	}
	return 0;
}
static int set(struct vector *vector, int pos, struct element element)
{
	struct vector_node *temp_set;
	int i = 1;
	int append;

	append = size(vector);
	temp_set = vector->head;
	if (vector->head == NULL && pos == 1) {
		return -1;
	} else if (vector->head == NULL && pos > 1)
		return -1;
	else if (pos == 1) {
		temp_set->element = element;
		vector->head->element = temp_set->element;
	} else if ((pos > 1) && pos <= (append)) {
		while (1) {
			if (i != pos) {
				i++;
				temp_set = temp_set->next;
			} else if (i == pos) {
				temp_set->element = element;
				break;
			}
		}
	} else if (pos == (append)) {
		vector->tail->element = temp_set->element;
	} else if (pos > append) {
		return -1;
	}
	return 0;
}
static int get(struct vector *vector, int pos, struct element *element)
{
	struct vector_node *temp_get;
	int i = 1;

	temp_get = vector->head;
	if (vector->head == NULL && pos == 1)
		return -1;
	else if (vector->head == NULL && pos > 1)
		return -1;
	for (temp_get = vector->head;
	     temp_get != NULL;
	     temp_get = temp_get->next, i++) {
		if (i == pos) {
			*element = temp_get->element;
			return 0;
		}
	}
	return -1;
}

static int is_empty(struct vector *vector)
{
	if (vector->head == NULL && vector->tail == NULL)
		return 0;
	return -1;
}

static int clear(struct vector *vector)
{
	if (vector->head == NULL)
		return -1;
	struct vector_node *temp1;
	struct vector_node *temp2;

	temp1 = vector->tail;
	while (temp1 != NULL) {
		temp2 = temp1;
		temp1 = temp1->prev;
		free(temp2);
	}
	vector->head = NULL;
	vector->tail = NULL;
	return 0;
}
static int first(struct vector *vector, struct element *element)
{
	if (vector->head == NULL)
		return -1;
	*element = vector->head->element;
	return 0;
}
static int last(struct vector *vector, struct element *element)
{
	if (vector->head == NULL)
		return -1;
	*element = vector->tail->element;
	return 0;
}
static int size(struct vector *vector)
{
	int count = 0;
	struct vector_node *temp;

	if (vector->head == NULL)
		return -1;
	temp = vector->head;
	while (temp != NULL) {
		temp = temp->next;
		count++;
	}
	return count;
}
static int move(struct vector *vector, int old_pos, int new_pos)
{
	if ((vector == NULL) || (vector->head == NULL))
		return -1;
	if ((old_pos > size(vector)) ||
	    (new_pos > size(vector)) ||
	    (old_pos == new_pos))
		return -1;
	struct element temp;

	if (get(vector, old_pos, &temp))
		return -1;
	if (delete(vector, old_pos))
		return -1;
	if (insert(vector, new_pos, temp))
		return -1;
	return 0;
}
static struct vector *splice(struct vector *vector, int pos)
{
	struct vector_node *v1;
	struct vector *v2 = (struct vector *)malloc(sizeof(struct vector));
	int i = 1;
	int vector_size = size(vector);

	v1 = vector->head;
	if (vector == NULL)
		return NULL;
	if (pos == 1 && vector->head != NULL) {
		v2->head = v1;
		v2->tail = vector->tail;
		vector->head = NULL;
		vector->tail = NULL;
		return v2;
	} else if (pos > vector_size)
		return NULL;
	while (1) {
		if (i != pos) {
			i++;
			v1 = v1->next;
		} else if (i == pos) {
			v2->tail = vector->tail;
			vector->tail = v1->prev;
			vector->tail->next = NULL;
			v2->head = v1;
			v2->head->prev = NULL;
			return v2;
		}
	}
}
static int destruct(struct vector *vector)
{
	clear(vector);
	free(vector);
	vector = NULL;
	return 0;
}
