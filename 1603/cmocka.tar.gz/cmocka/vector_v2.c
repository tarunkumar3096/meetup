#include <vector_v2.h>
#include <stdio.h>
#include <stdlib.h>

static int append(struct vector *vector, struct element element);
static int prepend(struct vector *vector, struct element element);
static int insert(struct vector *vector, int pos, struct element element);
static int chop(struct vector *vector);
static int behead(struct vector *vector);
static int delete(struct vector *vector, int pos);
static int set(struct vector *vector, int pos, struct element element);
static int get(struct vector *vector, int pos, struct element *element);
static int is_empty(struct vector *vector);
static int first(struct vector *vector, struct element *element);
static int last(struct vector *vector, struct element *element);
static int clear(struct vector *vector);
static int destruct(struct vector *vector);
static int move(struct vector *vector, int old_pos, int new_pos);
static struct vector * splice(struct vector *vector, int pos);
static int size(struct vector *vector);


static int size(struct vector *vector)
{
	struct vector_node *temp;
	int size = 0;
	
	temp = vector->head;
	while (temp != NULL) {
		size++;
		temp = temp->next;
	}
	return size;
}

static int append(struct vector *vector, struct element element)
{
	struct vector_node *next_temp = malloc(sizeof(struct vector_node));
	struct vector_node *prev_temp;
	
	next_temp->element = element;
	if(vector == NULL || next_temp == NULL)
		return FAILURE;
	if (vector->head == NULL) {
		vector->head = next_temp;
		vector->tail = next_temp;
	} else {
		prev_temp = vector->tail;
		vector->tail->next = next_temp;
		vector->tail = vector->tail->next;
		vector->tail->prev = prev_temp;
	}
	return SUCCESS;
}

static int prepend(struct vector *vector, struct element element)
{
        struct vector_node *temp = malloc(sizeof(struct vector_node));
      
	temp->element = element;
	if(vector == NULL || temp == NULL)
		return FAILURE;
        if (vector->head == NULL) {
		vector->head = temp;
		vector->tail = temp;
	} else {
	        temp->next = vector->head;
		vector->head->prev = temp;
		vector->head = temp;
	}
	return SUCCESS;
}

static int insert(struct vector *vector, int pos, struct element element)
{
	struct vector_node *node = malloc(sizeof(struct vector_node));
	struct vector_node *temp = vector->head;
	struct vector_node *prev_temp;
	int i = 1;
	int vector_size = size(vector);
	
	node->element = element;
        if (pos > (vector_size + 1) || pos < 1 || vector == NULL || node == NULL)
		return FAILURE;
	if (pos == 1) {
		prepend(vector, element);
	} else if (pos == (vector_size + 1)) {
		append(vector, element);
	} else {
		while (i <= vector_size) {
		        if (i == pos){
				prev_temp = temp->prev;
				prev_temp->next = node;
				node->prev  = prev_temp;
				node->next = temp;
				temp->prev = node;
				break;
			}
			i++;
			temp = temp->next;
		}
        }
	return SUCCESS;
}

static int chop(struct vector *vector)
{
	struct vector_node *temp = vector->tail;

	if (vector == NULL || vector->head == NULL)
		return FAILURE;
        if (vector->tail->prev == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
	        free(temp);
	}
	if (vector->head != NULL) {
	        vector->tail = vector->tail->prev;
		vector->tail->next = NULL;
		free(temp);
	}
	return SUCCESS;
}

static int behead(struct vector *vector)
{
	struct vector_node *temp = vector->head;

	if (vector == NULL || vector->head == NULL)
		return FAILURE;
        if (vector->head->next == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
		free(temp);
	}
	if (vector->head != NULL) {
	        vector->head = vector->head->next;
		vector->head->prev = NULL;
		free(temp);
	}
	return SUCCESS;
}

static int delete(struct vector *vector, int pos)
{
        struct vector_node *temp;
	struct vector_node *prev_temp;
	struct vector_node *next_temp;
	int i = 1;
	int vector_size = size(vector);
        
	if (vector == NULL || pos < 1 || pos > vector_size || vector_size < 1)
		return FAILURE;
	if (pos == 1) {
	        behead(vector);
	} else if (pos == vector_size){
		chop(vector);
	} else {
		temp = vector->head;
		while (i < vector_size) {
			if (i == pos) {
				prev_temp = temp->prev;
				next_temp = temp->next;
				prev_temp->next = next_temp;
				next_temp->prev = prev_temp;
				free(temp);
				break;
			}
			temp = temp->next;
			i++;
		}
	}
	return SUCCESS;
}

static int set(struct vector *vector, int pos, struct element element)
{
	struct vector_node *temp = vector->head;
	int vector_size = size(vector);
	int i = 1;
        
	if (vector == NULL || pos < 1 || pos > vector_size || vector_size < 1)
		return FAILURE;
	while (i <= vector_size) {
		if (pos == i) {
			temp->element.field = element.field;
			temp->element.field_type = element.field_type;
			break;
		}
		i++;
		temp = temp->next;
	}
	return SUCCESS;
}

static int get(struct vector *vector, int pos, struct element *element)
{
	struct vector_node *temp = vector->head;
	int vector_size = size(vector);
	int i = 1;

	if (vector == NULL || pos < 1 || pos > vector_size || vector_size < 1)
		return FAILURE;
	while (i <= vector_size) {
		if (pos == i) {
		        element->field = temp->element.field;
			element->field_type = temp->element.field_type;
			break;
		}
		i++;
		temp = temp->next;
	}
	return SUCCESS;
}

static int is_empty(struct vector *vector)
{
	if(vector == NULL)
		return FAILURE;
	if (vector->head == NULL)
		return SUCCESS;
	else
		return FAILURE;
}

static int first(struct vector *vector, struct element *element)
{
	if (vector == NULL || vector->head == NULL) {
		return FAILURE;
	} else {
		element->field = vector->head->element.field;
		element->field_type = vector->head->element.field_type;
		return SUCCESS;
	}
}

static int last(struct vector *vector, struct element *element)
{
	if (vector == NULL || vector->head == NULL) {
		return FAILURE;
	} else {
		element->field = vector->tail->element.field;
		element->field_type = vector->tail->element.field_type;
		return SUCCESS;
	}
}

static int clear(struct vector *vector)
{
	struct vector_node *temp1 = vector->tail;
	struct vector_node *temp2;
	
        if (vector == NULL)
		return FAILURE;
	while(temp1 != NULL) {
		temp2 = temp1;
		temp1 = temp1->prev;
		free(temp2);
	}
	vector->head = NULL;
	vector->tail = NULL;
	return SUCCESS;
}

static int destruct(struct vector *vector)
{
        clear(vector);
	free(vector);
	return SUCCESS;
}

static int move(struct vector *vector, int old_pos, int new_pos)
{
	struct vector_node *temp;
	struct vector_node *prev_temp;
	struct vector_node *next_temp;
	struct element node;
	int i = 1;
	int vector_size = size(vector);
        
	if (vector == NULL || vector->head == NULL || old_pos > vector_size ||
	    old_pos < 1 || new_pos > vector_size || new_pos < 1)
		return FAILURE;
        if (old_pos == 1) {
		node = vector->head->element;
	        behead(vector);
	} else if (old_pos == vector_size){
		node = vector->tail->element;
		chop(vector);
	} else {
		temp = vector->head;
		while (i < vector_size) {
			if (i == old_pos) {
				prev_temp = temp->prev;
				next_temp = temp->next;
				prev_temp->next = next_temp;
				next_temp->prev = prev_temp;
				node = temp->element;
				free(temp);
				break;
			}
			temp = temp->next;
			i++;
		}
	}
	insert(vector, new_pos, node);
	return SUCCESS;
}

static struct vector * splice(struct vector *vector, int pos)
{
	struct vector *new_vector = malloc(sizeof(struct vector));
        struct vector_node *temp = vector->head;
	int vector_size = size(vector);
	int i = 1;

	if (vector == NULL || vector->head == NULL ||
	    pos < 1 || pos > vector_size || new_vector == NULL) {
		new_vector = NULL;
		return new_vector;
	}
        
	new_vector->tail = vector->tail;
	while (temp != NULL) {
		if (i == pos) {
			new_vector->head = temp;
			break;
		}
	        temp = temp->next;
		i++;
        }
	return new_vector;
}

struct vector vector(struct vector *vector)
{
	vector->head = NULL;
	vector->tail = NULL;
	vector->append = append;
	vector->prepend = prepend;
	vector->insert = insert;
	vector->delete = delete;
	vector->chop = chop;
	vector->behead = behead;
	vector->set = set;
	vector->get = get;
        vector->is_empty = is_empty;
	vector->first = first;
	vector->last = last;
	vector->clear = clear;
	vector->destruct = destruct;
	vector->size = size;
	vector->move = move;
	vector->splice = splice;
	return *
vector;
}
