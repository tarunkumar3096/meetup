#ifndef __VECTOR_H__
#define __VECTOR_H__

#define SUCCESS 0
#define FAILURE -1
#define ELEMENT(data, type)					\
	(struct element) { .field = (g_datatype)data, .field_type = type}
#define for_each(entry, vector)				\
	for(struct vector_node * entry = vector->head;	\
	    entry != NULL; entry = entry->next)
#define for_each_rev(entry, vector)			\
	for(struct vector_node * entry = vector->tail;	\
	    entry != NULL; entry = entry->prev)       
#define VALUE(entry)  entry->element.field

#define FLOAT_VALUE(entry) entry->element.field.float_g
#define DOUBLE_VALUE(entry) entry->element.field.double_g

#define TYPE(entry)   entry->element.field_type

typedef union g_datatype
{
	char char_g;
	short short_g;
	int int_g;
	long long_g;
	float float_g;
	double double_g;
} g_datatype;

enum g_typename
	{
		CHAR,
		SHORT,
		INT,
		LONG,
		FLOAT,
		DOUBLE
	};

struct element {
	g_datatype field;
	enum g_typename field_type;
};

struct vector_node {
	struct element element;
	struct vector_node *next;
	struct vector_node *prev;       
};

struct vector {
	struct vector_node *head;
	struct vector_node *tail;

	/*
	 * append() - Appends a node to the vector.
	 * @vector: Pointer to the structure of type vector
	 * @element: A structure of type element that holds a generic data and
	 *            it's type
	 * 
	 * Append a new tail node to the vector
	 *
	 * Return: 0, if appended successfully
	 *        -1, otherwise
	 */
	int (*append)(struct vector *vector, struct element element);

	/*
	 * prepend() - Prepends a node to the vector.
	 * @vector: Pointer to the structure of type vector
	 * @element: A structure of type element that holds a generic data and
	 *            it's type
	 * 
	 * Add a new head node to the vector.
	 *
	 * Return: 0, if prepended successfully
	 *        -1, otherwise
	 */
	int (*prepend)(struct vector *vector, struct element element);

	/*
	 * insert() - Inserts a new vector node.
	 * @vector: Pointer to the structure of type vector
	 * @pos: Variable holding the position where new node has to be added 
	 * @element: A structure of type element that holds a generic data and
	 *           it's type
	 * 
	 * Insert a new vector node at specified position. New node can be
	 * added before the head node, after the tail node, and anywhere in
	 * between head and tail nodes.
	 *
	 * Return: 0, if node added successfully
	 *        -1, otherwise
	 */
	int (*insert)(struct vector *vector, int pos, struct element element);

	/*
	 * chop() - Removes the tail node from the vector.
	 * @vector: Pointer to the structure of type vector
	 * 
	 * Removes tail node from the vector and the node that preceded
	 * it becomes the new tail node.
	 *
	 * Return: 0, if chopped successfully
	 *        -1, otherwise
	 */
	int (*chop)(struct vector *vector);

	/*
	 * behead() - Removes the head node from the vector.
	 * @vector: Pointer to the structure of type vector
	 * 
	 * Removes head node from the vector and the node that succeeded
	 * it becomes the new head node.
	 *
	 * Return: 0, if operation done successfully
	 *        -1, otherwise
	 */
	int (*behead)(struct vector *vector);

	/*
	 * delete() - Deletes a node from the vector.
	 * @vector: Pointer to the structure of type vector
	 * @pos: Variable holding the position of node to be deleted
	 *
	 * Deletes a node at specified position from the vector. Position
	 * should be in the range 1 to number of vector nodes.
	 *
	 * Return: 0, if deleted successfully
	 *        -1, otherwise
	 */
	int (*delete)(struct vector *vector, int pos);

	/*
	 * set() - Re-writes a vector node with given data of generic type
	 * @vector: Pointer to the structure of type vector
	 * @pos: Variable holding the position of node whose data to be
	 *       re-written
	 * @element: A structure of type element that holds a generic data and
	 *           it's type
	 *
	 * Re-writes a vector node with given data of generic type. Position
	 * should be in the range 1 to the number of vector nodes.
	 *
	 * Return: 0, if operation done successfully
	 *        -1, otherwise
	 */
	int (*set)(struct vector *vector, int pos, struct element element);

	/*
	 * get() - Copies a vector node to a given structure.
	 * @vector: Pointer to the structure of type vector
	 * @pos: Variable holding the position of node whose data to be
	 *       re-written
	 * @element: A structure of type element to store a generic data and
	 *           it's type
	 *
	 * Copies a vector node to a given structure. Position should be in 
	 * the range 1 to the number of vector nodes.
	 *
	 * Return: 0, if operation done successfully
	 *        -1, otherwise
	 */
	int (*get)(struct vector *vector, int pos, struct element *element);

	/*
	 * is_empty() - Checks whether the vector is empty or not.
	 * @vector: Pointer to the structure of type vector
	 *
	 * Checks whether the vector is empty or not and returns the result.
	 *
	 * Return: 0, if the vector is empty
	 *        -1, otherwise
	 */
	int (*is_empty)(struct vector *vector);

	/*
	 * first() - Gets the head node of the vector.
	 * @vector: Pointer to the structure of type vector
	 * @element: A structure of type element to store the copy of
	 *           head node
	 *
	 * Gets the head node of vector and stores it in another structure
	 * that has been passed by argument.
	 *
	 * Return: 0, if operation is successful
	 *        -1, otherwise
	 */
	int (*first)(struct vector *vector, struct element *element);

	/*
	 * last() - Gets the tail node of the vector.
	 * @vector: Pointer to the structure of type vector
	 * @element: A structure of type element to store the copy of
	 *           tail node
	 *
	 * Gets the tail node of vector and stores it in another structure
	 * that has been passed by argument.
	 *
	 * Return: 0, if operation is successful
	 *        -1, otherwise
	 */
	int (*last)(struct vector *vector, struct element *element);

	/*
	 * clear() - Clears the vector nodes.
	 * @vector: Pointer to the structure of type vector
	 *
	 * Removes all the vector nodes, if any.
	 *
	 * Return: 0, if cleared successfully
	 *        -1, otherwise
	 */
	int (*clear)(struct vector *vector);

	/*
	 * destruct() - Destructs the vector.
	 * @vector: Pointer to the structure of type vector
	 *
	 * Removes all the vector nodes, if any. And frees the vector's
	 * memory.
	 *
	 * Return: 0, if cleared successfully
	 *        -1, otherwise
	 */
	int (*destruct)(struct vector *vector);

	/*
	 * size() - Gives the size of the vector.
	 * @vector: Pointer to the structure of type vector
	 *
	 * Calculates the number of vector nodes and returns the value.
	 *
	 * Return: Size of the vector
	 */
	int (*size)(struct vector *vector);

	/*
	 * move() - Moves a vector node to specified position within the 
	 *          vector.
	 * @vector: Pointer to the structure of type vector
	 * @old_pos: Variable holding the position of node that has to moved
	 * @new_pos: Variable holding the position specifying where the node
	 *           has to be moved
	 *
	 * Moves a vector node to specified position within the vector.
	 * Position should be in the range 1 to number of vector nodes.
	 *
	 * Return: 0, if moved successfully
	 *        -1, otherwise
	 */
	int (*move)(struct vector *vector, int old_pos, int new_pos);

	/*
	 * splice() - Construct a new vector from the given vector.
	 * @vector: Pointer to the structure of type vector
	 * @pos: Variable holding the position w.r.t which the splicing has
	 * to be done
	 *
	 * Construct a new vector from the given vector with nodes ranging from
	 * @pos to tail of the source vector. Position should be in the range
	 * 1 to the number of vector nodes.
	 *
	 * Return: Pointer to the newly created vector
	 */
	struct vector * (*splice)(struct vector *vector, int pos);
};

/*
 * vector() - Initializes the vector.
 * @vector: Pointer to the structure of type vector
 * 
 * To initialize the vector with functionalities(Append, Prepend, Insert, 
 * Chop, Behead, Delete, Set, Get and Is_empty) and, head and tail pointing
 * to NULL initially.
 *
 * Return: Structure of type vector which has been initialized, if and only if, the 
 *         vector passed by argument is created dynamically 
 */
struct vector vector(struct vector *vector);

#endif
