#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <vector_v2.h>
#include <stdlib.h>

static void test_get_for_int_data(void **state)
{
	struct vector *v = malloc(sizeof(struct vector));
	struct element *temp;
	union g_datatype data;
       
	vector(v);
	data.int_g = 123;
        v->append(v, ELEMENT(data,INT));
	data.int_g = 124;
        v->append(v, ELEMENT(data,INT));

	temp = malloc(sizeof(struct element));
        v->get(v, 1, temp);
	assert_int_equal(temp->field.int_g, 123);
	free(temp);

	temp = malloc(sizeof(struct element));
        v->get(v, 2, temp);
	temp->field.int_g = 125;//Assume get fn. returned 125
	assert_int_equal(temp->field.int_g, 124);
	free(temp);
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_get_for_int_data),

	};
	return cmocka_run_group_tests(tests, NULL, NULL);
}
