#define __static_fun__
#include <vector.h>
#include <stdio.h>
#include <stdlib.h>
#define MEMORY_FAULT -3
#define INVALID_OPR -2
#define PTR_ERROR -1

struct vector vector(struct vector *vector)
{
	struct vector local_vector;

	local_vector.head = NULL;
	local_vector.tail = NULL;
	local_vector.append = append;
	local_vector.prepend = prepend;
	local_vector.insert = insert;
	local_vector.chop = chop;
	local_vector.behead = behead;
	local_vector.delete = delete;
	local_vector.set = set;
	local_vector.get = get;
	local_vector.is_empty = is_empty;
	local_vector.size = size;
	local_vector.clear = clear;
	local_vector.destruct = destruct;
	local_vector.move = move;
	local_vector.first = first;
	local_vector.last = last;
	local_vector.splice = splice;

	if (vector != NULL)
		*vector = local_vector;

	return local_vector;
}

static int append(struct vector *vector,
		  struct element element)
{
	if (vector == NULL)
		return PTR_ERROR;
	struct vector_node *temp;
	struct vector_node *head = vector->head;

	temp = malloc(sizeof(struct vector_node));
	if (temp == NULL)
		return MEMORY_FAULT;

	temp->element = element;
	temp->next = NULL;
	temp->prev = NULL;

	if (vector->head == NULL) {
		vector->head = temp;
		vector->tail = temp;
	} else {
		head = vector->tail;
		vector->tail = temp;
		vector->tail->prev = head;
		vector->tail->next = NULL;
		head->next = vector->tail;
	}

	return 0;
}

static int prepend(struct vector *vector,
		   struct element element)
{
	if (vector == NULL)
		return PTR_ERROR;
	struct vector_node *temp;

	temp = malloc(sizeof(struct vector_node));
	if (temp == NULL)
		return MEMORY_FAULT;

	temp->element = element;
	temp->next = NULL;
	temp->prev = NULL;

	if (vector->head == NULL) {
		vector->head = temp;
		vector->tail = temp;
	} else {
		temp->next = vector->head;
		vector->head->prev = temp;
		vector->head = temp;
		vector->head->prev = NULL;
	}
	return 0;
}

static int insert(struct vector *vector,
		  int pos, struct element element)
{
	if ((vector == NULL) || ((pos != 1) && (vector->head == NULL)))
		return PTR_ERROR;
	if ((pos < 1) || (pos > (size(vector) + 1)))
		return 	INVALID_OPR;
	struct vector_node *temp;
	struct vector_node *head = vector->head;
	int location = 1;

	if (pos == 1)
		return prepend(vector, element);
	else if (pos == (size(vector) + 1))
		return append(vector, element);

	temp = malloc(sizeof(struct vector_node));
	if (temp == NULL)
		return MEMORY_FAULT;

	temp->element = element;
	temp->next = NULL;
	temp->prev = NULL;
	while ((location != (pos - 1))
	       && (head->next != NULL)) {
		head = head->next;
		location++;
	}
	head->next->prev = temp;
	temp->next = head->next;
	head->next = temp;
	temp->prev = head;
	return 0;
}

static int chop(struct vector *vector)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	struct vector_node *head = vector->tail;

	if (head->prev == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
	} else {
		vector->tail = vector->tail->prev;
		vector->tail->next = NULL;
	}

	free(head);
	return 0;
}

static int behead(struct vector *vector)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	struct vector_node *head = vector->head;

	if (head->next == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
	} else {
		vector->head = vector->head->next;
		vector->head->prev = NULL;
	}

	free(head);
	return 0;
}

static int delete(struct vector *vector, int pos)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	if ((pos < 1) || (pos > size(vector)))
		return 	INVALID_OPR;
	int location = 1;
	struct vector_node *head = vector->head;
	struct vector_node *temp;

	if (pos == 1)
		return behead(vector);
	else if (pos == size(vector))
		return chop(vector);

	while (location != (pos - 1)) {
		head = head->next;
		location++;
	}

	temp = head->next;
	head->next = head->next->next;
	head->next->prev = head;
	free(temp);
	return 0;
}

static int size(struct vector *vector)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;

	int count = 1;
	struct vector_node *head = vector->head;

	while (head->next != NULL) {
		count++;
		head = head->next;
	}

	return count;
}

static int set(struct vector *vector, int pos, struct element element)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	if ((pos < 1) || (pos > size(vector)))
		return 	INVALID_OPR;

	int location = 1;
	struct vector_node *head = vector->head;

	if (pos == 1) {
		vector->head->element = element;
		return 0;
	} else if (pos == size(vector)) {
		vector->tail->element = element;
		return 0;
	}

	while (location != (pos - 1)) {
		head = head->next;
		location++;
	}
	head->next->element = element;
	return 0;
}

static int clear(struct vector *vector)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;

	struct vector_node *head = vector->head;
	struct vector_node *temp;

	while (head != NULL) {
		temp = head->next;
		free(head);
		head = temp;
	}

	vector->head = NULL;
	vector->tail = NULL;
	return 0;
}

static int first(struct vector *vector, struct element *element)
{
	if ((vector == NULL) || (element == NULL))
		return PTR_ERROR;

	if (vector->head != NULL)
		*element = vector->head->element;
	return 0;
}

static int last(struct vector *vector, struct element *element)
{
	if ((vector == NULL) || (element == NULL))
		return PTR_ERROR;

	if (vector->tail != NULL)
		*element = vector->tail->element;
	return 0;
}

static int get(struct vector *vector, int pos, struct element *element)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	if ((pos < 1) || (pos > size(vector)) || (element == NULL))
		return 	INVALID_OPR;

	int location = 1;
	struct vector_node *head = vector->head;

	if (pos == 1)
		return first(vector, element);
	else if (pos == size(vector))
		return last(vector, element);

	while (location != (pos - 1)) {
		head = head->next;
		location++;
	}

	*element = head->next->element;
	return 0;
}

static int is_empty(struct vector *vector)
{
	if ((vector == NULL) || (size(vector) == -1))
		return PTR_ERROR;

	return 0;
}

static int destruct(struct vector *vector)
{
	if (vector == NULL)
		return PTR_ERROR;

	clear(vector);
	free(vector);
	vector = NULL;
	return 0;
}


static int move(struct vector *vector, int old_pos, int new_pos)
{
	if ((vector == NULL) || (vector->head == NULL))
		return PTR_ERROR;
	if ((old_pos > size(vector)) ||
	    (new_pos > size(vector)) ||
	    (old_pos == new_pos))
		return 	INVALID_OPR;

	struct element temp;

	if (get(vector, old_pos, &temp))
		return 	INVALID_OPR;
	if (delete(vector, old_pos))
		return 	INVALID_OPR;
	if (insert(vector, new_pos, temp))
		return 	INVALID_OPR;
	return 0;
}

static struct vector *splice(struct vector *vector, int pos)
{
	if ((vector == NULL) || (vector->head == NULL))
		return NULL;
	if ((pos < 2) || (pos > size(vector)))
		return NULL;

	int location = 1;
	struct vector *spliter = malloc(sizeof(struct vector));
	struct vector_node *temp = vector->head;

	if (spliter == NULL)
		return NULL;
	while (location != (pos - 1)) {
		temp = temp->next;
		location++;
	}
	spliter->head = temp->next;
	spliter->tail = vector->tail;
	vector->tail = temp;
	vector->tail->next = NULL;
	return spliter;
}
