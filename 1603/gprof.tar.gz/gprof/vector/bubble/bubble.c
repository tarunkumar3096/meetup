#include <vector.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h>
#define INSERTING 1
#define DELETING 2
#define GETTING 3
#define DATA_CHECK 4
#define FLUSH 5
#define MOVE_DATA 6
#define SPLITER 7
#define BUBBLE_SORT 8
#define EXIT 9
static int destructed;
static int data_type;
static int get_int(void);
static int display(struct vector_node *element);
static int inserting(struct vector *vector, struct vector_node *data);
static int deleting(struct vector *vector);
static int getting_data(struct vector *vector);
static int vector_availability(struct vector *vector);
static int flush(struct vector *vector);
static int spliter(struct vector *vector);
static int move_data(struct vector *vector);
static int pass(struct vector *vector);
static int bubble_sort(struct vector *list);

enum inserting {
	APPEND = 1,
	PREPEND,
	INSERT,
	SET
};

enum deleting {
	CHOP = 1,
	BEHEAD,
	DELETE
};

enum getting_data {
	FIRST = 1,
	LAST,
	GET
};

enum vector_availability {
	IS_EMPTY = 1,
	SIZE
};

enum flush {
	CLEAR = 1,
	DESTRUCT
};

static int get_int(void)
{
	int temp = -1;

	while (1) {
		scanf("%d", &temp);
		__fpurge(stdin);
		if (temp != -1)
			return temp;
		printf("Invaild data\nEnter again:\t");
		continue;
	}

	return 0;
}

static int display(struct vector_node *element)
{
	if (element == NULL)
		return -1;
	switch (TYPE(element)) {
	case CHAR:
		printf("%c  ",  VALUE(element).char_g);
		break;
	case SHORT:
		printf("%hd  ",  VALUE(element).short_g);
		break;
	case INT:
		printf("%d  ",  VALUE(element).int_g);
		break;
	case LONG:
		printf("%ld  ",  VALUE(element).long_g);
		break;
	case FLOAT:
		printf("%f   ",  VALUE_F(element));
		break;
	case DOUBLE:
		printf("%lf  ",  VALUE_D(element));
		break;
	}

	return 0;
}

static int inserting(struct vector *vector, struct vector_node *data)
{
	int opr =  0;
	int location = 0;
	int check = 0;

	if (data == NULL)
		return -1;
	if (vector == NULL)
		return -1;
	printf("1.Appened\t2.Prepend\t3.Inserting\t4.set\n");
	printf("Select the operation:\t");
	opr = get_int();
	data->element.field_type = (data_type - 1);
	while (1) {
		printf("Enter the data to pass:\t");
		switch (data_type - 1) {
		case CHAR:
			check = scanf("%c",  &VALUE(data).char_g);
			break;
		case SHORT:
			check = scanf("%hd", &VALUE(data).short_g);
			break;
		case INT:
			check = scanf("%d",  &VALUE(data).int_g);
			break;
		case LONG:
			check = scanf("%ld",  &VALUE(data).long_g);
			break;
		case FLOAT:
			check = scanf("%f",  &VALUE_F(data));
			break;
		case DOUBLE:
			check = scanf("%lf",  &VALUE_D(data));
			break;
		}
		__fpurge(stdin);
		if (check == 1)
			break;
		printf("Invalid data\n");
	}
	if (opr == 3 || opr == 4) {
		printf("Enter location in vector\n");
		location = get_int();
	}
	switch (opr) {
	case APPEND:
		if (vector->append(vector, data->element))
			printf("Not possible to appened\n");
		break;
	case PREPEND:
		if (vector->prepend(vector, data->element))
			printf("Not possible to prepend data\n");
		break;
	case INSERT:
		if (vector->insert(vector, location, data->element))
			printf("Not possible to insert data\n");
		break;
	case SET:
		if (vector->set(vector, location, data->element))
			printf("Not possible to set data\n");
		break;
	default:
		printf("Invalid operation seleted\n");
	}

	return 0;
}

int deleting(struct vector *vector)
{
	int opr;
	int location;

	if (vector == NULL)
		printf("\n1.chop(deleting end)\t2.behead(deleting first)");
	printf("\t3.delete(location)\n");
	printf("Select the operation:\t");
	opr = get_int();
	switch (opr) {
	case CHOP:
		if (vector->chop(vector))
			printf("Unable to chop\n");
		break;
	case BEHEAD:
		if (vector->behead(vector))
			printf("Unable to behead\n");
		break;
	case DELETE:
		printf("Enter the location of deletion of node\n");
		scanf("%d", &location);
		if (vector->delete(vector, location))
			printf("Unable to delete at %d\n", location);
		break;
	default:
		printf("Invalid operation seleted\n");
	}

	return 0;
}

static int getting_data(struct vector *vector)
{
	int opr;
	int location;
	struct vector_node temp;

	if (vector == NULL)
		return -1;
	printf("\n1.first\t2.last\t3.delete at position\n");
	printf("Select the operation:\t");
	opr = get_int();
	switch (opr) {
	case FIRST:
		if (vector->first(vector, &temp.element))
			printf("Unable to chop\n");
		break;
	case LAST:
		if (vector->last(vector, &temp.element))
			printf("Unable to behead\n");
		break;
	case GET:
		printf("Enter the location of deletion of node\n");
		scanf("%d", &location);
		if (vector->get(vector, location, &temp.element))
			printf("Unable to delete at %d\n", location);
		break;
	default:
		printf("Invalid operation seleted\n");
	}

	printf("Data from vector:\t\n");
	display(&temp);

	return 0;
}

static int vector_availability(struct vector *vector)
{
	int size;
	int opr;

	if (vector == NULL)
		return -1;
	printf("1.Is_empty\t2.Size\n");
	printf("Select the operation:\t");
	opr = get_int();
	switch (opr) {
	case IS_EMPTY:
		if (vector->is_empty(vector))
			printf("data available in vector\n");
		break;
	case SIZE:
		size = vector->size(vector);
		if (size == -1)
			printf("vector is empty\n");
		else
			printf("vector size = %d\n", size);
		break;
	default:
		printf("Invalid operation seleted\n");
	}

	return 0;
}

static int flush(struct vector *vector)
{
	int opr = 0;

	if (vector == NULL)
		return -1;
	printf("1.Clear\t2.Destruct\n");
	printf("Select the operation:\t");
	opr = get_int();
	switch (opr) {
	case CLEAR:
		if (vector->clear(vector))
			printf("Unable to clear\n");
		break;
	case DESTRUCT:
		if (vector->destruct(vector))
			printf("Unable to free memory\n");
		destructed = 1;
		break;
	default:
		printf("Invalid operation seleted\n");
	}

	return 0;
}

static int spliter(struct vector *vector)
{
	int location = 0;
	struct vector *spliter = NULL;

	if (vector == NULL)
		return -1;
	printf("Enter the location to split the vector\n");
	location = get_int();
	spliter = vector->splice(vector, location);
	if (spliter == NULL) {
		printf("Unable to split\n");
		return -1;
	}
	printf("\nData from the splited vector\n");
	for_each(tmp, spliter)
		display(tmp);
	vector->clear(spliter);
	free(spliter);
	return 0;
}

static int move_data(struct vector *vector)
{
	int new_pos = 0;
	int old_pos = 0;

	if (vector == NULL)
		return -1;
	printf("enter the old_pos of vector\n");
	old_pos = get_int();
	printf("enter the new_pos of vector\n");
	new_pos = get_int();
	if (vector->move(vector, old_pos, new_pos))
		printf("unable to move to new location\n");

	return 0;
}

static int comparsion(struct element l_element, struct element r_element)
{
	int check = 0;
	
	switch (data_type - 1) {
	case CHAR:
		check = (l_element.field.char_g >  r_element.field.char_g);
		break;
	case SHORT:
		check = (l_element.field.short_g >  r_element.field.short_g);
		break;
	case INT:
		check = (l_element.field.int_g >  r_element.field.int_g);
		break;
	case LONG:
		check = (l_element.field.long_g >  r_element.field.long_g);
		break;
	case FLOAT:
		check = (l_element.field.float_g >  r_element.field.float_g);
		break;
	case DOUBLE:
		check = (l_element.field.double_g > r_element.field.double_g);
		break;
	}

	return check;
}
	
static int pass(struct vector *vector)
{
	if (vector == NULL)
		return -1;
	int count = (vector->size(vector) - 1);
	int pass = 1;
	struct element left_element;
	struct element right_element;

	while (count) {
		count--;
		vector->get(vector, pass, &left_element);
		vector->get(vector, (pass + 1), &right_element);
		if (comparsion(left_element, right_element) == 1)
			vector->move(vector, pass, (pass + 1));
		pass++;
	}

	return 0;
}

static int bubble_sort(struct vector *list)
{
	int count = 0;

	if (list == NULL)
		return -1;
	count = list->size(list);
	while (count--) {
		if (pass(list))
			return -1;
	}

	return 0;
}

static int operation(struct vector *list)
{
	struct vector *print_list;
	struct vector_node temp;
	int opr = 0;
	
	if (list == NULL)
		return -1;
	print_list = list;
	printf("\nData in vector:");
	if (list->head == NULL)
		printf("Flused\n");
	for_each(tmp, print_list)
		display(tmp);
	printf("\n1.Inserting\t2.Deleting\t3.Getting data\t4.Data check\n");
	printf("5.Flush  \t6.Move data\t7.Spliter\t8.Bubble_sort\t9.Exit\n");
	printf("Select the operation:\t");
	opr = get_int();
	switch (opr) {
	case INSERTING:
		if (inserting(list, &temp) == -1)
			printf("Unable to insert\n");
		break;
	case DELETING:
		if (deleting(list) == -1)
			printf("Unable to delete\n");
		break;
	case GETTING:
		if (getting_data(list) == -1)
			printf("Unable to get data from vector\n");
		break;
	case DATA_CHECK:
		if (vector_availability(list) == -1)
			printf("Unable to check data availability\n");
		break;
	case FLUSH:
		if (flush(list) == -1)
			printf("Unable to flush the data in vecor\n");
		break;
	case MOVE_DATA:
		if (move_data(list) == -1)
			printf("Unable to move data in vector\n");
		break;
	case SPLITER:
		if (spliter(list) == -1)
			printf("Unable to split the data in vector\n");
		break;
	case BUBBLE_SORT:
		if (bubble_sort(list) == -1)
			printf("Unable to sort the list\n");
		break;
	case EXIT:
		return 0;
	default:
		printf("Invalid operation seleted\n");
	}

	return -1;
}

int main(void)
{
	struct vector *list = malloc(sizeof(struct vector));

	printf("Select datatype for bubble sort\n");
	//printf("1.char\t 2.short\t3.int\t4.long\t5.float\t6.double\n");
	data_type = 2;	
	if (list == NULL)
		return -1;
	vector(list);
	list->append(list, ELEMENT(20, INT));
	list->append(list, ELEMENT(22, INT));
	list->append(list, ELEMENT(2, INT));
	list->append(list, ELEMENT(280, INT));
	list->append(list, ELEMENT(2099, INT));
	list->append(list, ELEMENT(12, INT));
	list->append(list, ELEMENT(222, INT));
	list->append(list, ELEMENT(15, INT));
	list->append(list, ELEMENT(14, INT));
	list->append(list, ELEMENT(12, INT));
	list->append(list, ELEMENT(67, INT));
	list->append(list, ELEMENT(70, INT));
	while (destructed == 0) {
		if (operation(list) == 0)
			break;
	}
	if (destructed == 0)
		free(list);

	return 0;
}
