#include <vector.h>
#include <stdio.h>
#include <stdlib.h>

static int append(struct vector *vector, struct element element);
static int prepend(struct vector *vector, struct element element);
static int insert(struct vector *vector, int pos, struct element element);
static int delete(struct vector *vector, int pos);
static int set(struct vector *vector, int pos, struct element element);
static int get(struct vector *vector, int pos, struct element *element);
static int is_empty(struct vector *vector);
static int first(struct vector *vector, struct element *element);
static int last(struct vector vector, struct element *element);
static int clear(struct vector *vector);
static int destruct(struct vector *vector);
static int size(struct vector *vector);
static int move(struct vector *vector, int old_pos, int new_pos);
static struct vector *splice(struct vector *vector, int pos);
static int behead(struct vector *vector);
static int chop(struct vector *vector);

struct vector vector(struct vector *vector)
{
	struct vector temp;
	
	temp.head = NULL;
	temp.tail = NULL;
	temp.append = &append;
	temp.prepend = &prepend;
	temp.insert = &insert;
	temp.chop = &chop;
	temp.behead = &behead;
	temp.delete = &delete;
	temp.set = &set;
	temp.get = &get;
	temp.is_empty = &is_empty;
	temp.first = &first;
	temp.last = &last;
	temp.clear = &clear;
	temp.size = &size;
	temp.move = &move;
	temp.splice = &splice;
	temp.destruct = &destruct;
	if (vector == NULL)
		return temp;
	*vector = temp;
	return *vector;
}

static int append(struct vector *vector, struct element element)
{
	struct vector_node *new = malloc(sizeof(struct vector_node));

	if (new == NULL)
		return -1;
	new->element = element;
	if (vector->head == NULL) {
		new->prev = NULL;
		new->next = NULL;
		vector->head = new;
		vector->tail = new;
	} else {
		new->prev = vector->tail;
		new->next = NULL;
		vector->tail->next = new;
		vector->tail = new;
	}
	return 0;
}

static int prepend(struct vector *vector, struct element element)
{
	struct vector_node *new = malloc(sizeof(struct vector_node));

	if (new == NULL)
		return -1;
	new->element = element;
	if (vector->head == NULL) {
		new->prev = NULL;
		new->next = NULL;
		vector->head = new;
		vector->tail = new;
	} else {
		new->prev = NULL;
		new->next = vector->head;
		vector->head->prev = new;
		vector->head = new;
	}
	return 0;
}

static int insert(struct vector *vector, int pos, struct element element)
{
	struct vector_node *new = malloc(sizeof(struct vector));
	struct vector_node *temp;
	struct vector_node *prev;
	int count = 1;

	if (new == NULL)
		return -1;
	new->element = element;
	if ((vector->head == NULL && pos > 1) || (pos < 1)) {
		free(new);
		return -1;
	} else if (pos == 1) {
		new->next = vector->head;
		vector->head->prev = new;
		new->prev = NULL;
		vector->head = new;
		if (vector->tail == NULL)
			vector->tail = new;
		return 0;
	}
	for (temp = vector->head; temp != NULL; temp = temp->next) {
		if (count == pos) {
			new->next = temp;
			temp->prev = new;
			new->prev = prev;
			prev->next = new;
			return 0;
		} else if (temp->next == NULL && count == pos-1) {
			new->prev = temp;
			new->next = NULL;
			temp->next = new;
			vector->tail = new;
			return 0;
		}
		prev = temp;
	}
	free(new);
	return -1;
}

static int chop(struct vector *vector)
{
	struct vector_node *temp;

	if (vector->head == NULL)
		return -1;
	temp = vector->tail;
	if (vector->head == vector->tail) {
		vector->head = NULL;
		vector->tail = NULL;
		free(temp);
		return 0;
	}
	vector->tail = vector->tail->prev;
	vector->tail->next = NULL;
	free(temp);
	return 0;
}

static int behead(struct vector *vector)
{
	struct vector_node *temp;

	if (vector->head == NULL)
		return -1;
	temp = vector->head;
	if (vector->head == vector->tail) {
		vector->head = NULL;
		vector->tail = NULL;
		free(temp);
		return 0;
	}
	vector->head = vector->head->next;
	vector->head->prev = NULL;
	free(temp);
	return 0;
}

static int delete(struct vector *vector, int pos)
{
	struct vector_node *temp;
	struct vector_node *prev;
	struct vector_node *clear;
	int count = 1;

	if (vector->head == NULL || pos < 1)
		return -1;
	if (pos == 1) {
		clear = vector->head;
		vector->head = vector->head->next;
		if (vector->head == NULL)
			vector->tail = NULL;
		else
			vector->head->prev = NULL;
		free(clear);
		return 0;
	}
	for (temp = vector->head; temp != NULL; temp = temp->next, count++) {
		if (count < pos) {
			clear = temp;
			if (temp->next != NULL) {
				temp = temp->next;
				temp->prev = prev;
				prev->next = temp;
			} else {
				prev->next = NULL;
				vector->tail = prev;
			}
			free(clear);
			return 0;
		}
		prev = temp;
	}
	return -1;
}

static int set(struct vector *vector, int pos, struct element element)
{
	struct vector_node *temp;
	int count = 1;

	if (vector->head == NULL || pos < 1)
		return -1;
	for (temp = vector->head; temp != NULL; temp = temp->next, count++) {
		if (count == pos) {
			temp->element = element;
			return 0;
		}
	}
	return -1;
}

static int get(struct vector *vector, int pos, struct element *element)
{
	struct vector_node *temp;
	int count = 1;

	if (vector->head == NULL || pos < 1)
		return -1;
	for (temp = vector->head; temp != NULL; temp = temp->next, count++) {
		if (count == pos) {
			*element = temp->element;
			break;
		}
	}
	return -1;
}

static int is_empty(struct vector *vector)
{
	if (vector->head == NULL && vector->tail == NULL)
		return -1;
	return 0;
}

static int first(struct vector *vector, struct element *element)
{
	if (vector->head == NULL)
		return -1;
	*element = vector->head->element;
	return 0;
}

static int last(struct vector *vector, struct element *element)
{
	if (vector->tail == NULL)
		return -1;
	*element = vector->tail->element;
	return 0;
}

static int clear(struct vector *vector)
{
	struct vector_node *temp;

	if (vector->head == NULL)
		return -1;
	for (temp = vector->head; temp != NULL; temp = temp->next)
		vector->delete(vector, FIRST_POS);
	return 0;
}

static int size(struct vector *vector)
{
	int size = 0;
	struct vector_node *temp;

	if (vector->head == NULL)
		return 0;
	for (temp = vector->head; temp != NULL; temp = temp->next, size++)
		;
	return size;
}

static int move(struct vector *vector, int old_pos, int new_pos)
{
	struct element old_element;
	struct vector_node *temp;
	int count = 0;

	for (temp = vector->head; temp != NULL; temp = temp->next, count++)
		;
	if (vector->head == NULL || old_pos < 1 ||
	    new_pos < 1 || old_pos > count || new_pos > count)
		return -1;
	count = 1;
	for (temp = vector->head; temp != NULL; count++)
		if (count == old_pos) {
			old_element = temp->element;
			break;
		}
	vector->delete(vector, old_pos);
	vector->insert(vector, new_pos, old_element);
	return 0;
}

static struct vector *splice(struct vector *vector1, int pos)
{
	struct vector *new_vector = malloc(sizeof(struct vector));
	struct vector_node *temp;
	struct vector_node *prev;
	int count = 1;

	if (new_vector == NULL)
		return NULL;
	if (vector1->head == NULL || pos < 2) {
		free(new_vector);
		return NULL;
	}
	vector(new_vector);
	for (temp = vector1->head; temp != NULL; temp = temp->next, count++) {
		if (count == pos) {
			prev->next = NULL;
			for (temp = temp; temp != NULL; temp = temp->next)
				append(new_vector, temp->element);
			vector1->tail = prev;
			return new_vector;
		}
		prev = temp;
	}
	free(new_vector);
	return NULL;
}

static int destruct(struct vector *vector)
{
	struct vector_node *temp;
	
	for (temp = vector->head; temp != NULL; temp = temp->next)
		vector->delete(vector, FIRST_POS);
	free(vector);
	return 0;
}
