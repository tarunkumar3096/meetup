#include <stdio.h>
#include <stdlib.h>
#include <vector.h>

static void clear_buf(void)
{
	while (getchar() != '\n')
		;
}

static int get_input(g_datatype *value, enum g_typename type)
{
	int check;

	while (1) {
		switch (type) {
		case CHAR:
			printf("enter the value: ");
			check = scanf("%c", &value->char_g);
			clear_buf();
			break;
		case SHORT:
			printf("enter the value: ");
			check = scanf("%hu", &value->short_g);
			clear_buf();
			break;
		case INT:
			printf("enter the value: ");
			check = scanf("%d", &value->int_g);
			clear_buf();
			break;
		case LONG:
			printf("enter the value: ");
			check = scanf("%ld", &value->long_g);
			clear_buf();
			break;
		case FLOAT:
			printf("enter the value: ");
			check = scanf("%f", &value->float_g);
			clear_buf();
			break;
		case DOUBLE:
			printf("enter the value: ");
			check = scanf("%lf", &value->double_g);
			clear_buf();
			break;
		default:
			return -1;
		}
		if (check == 1)
			break;
		printf("invalid input\n");
	}
	return 0;
}

static void get_element(enum g_typename *type, g_datatype *value)
{
	int temp;
	
	while (1) {
		temp = 0;
		printf("1.char\t2.short\t3.int\t4.long\n");
		printf("5.float\t6.double\n");
		scanf("%d", &temp);
		clear_buf();
		*type = temp;
		if (get_input(value, *type) == 0)
			break;
		printf("invalid input\n");
	}
}

static void get_position(int *position)
{
	int check;

	while (1) {
		printf("enter the position: ");
		check = scanf("%d", position);
		clear_buf();
		if (check == 1)
			break;
		printf("invalid input\n");
	}
}

static void switch_print(g_datatype element, enum g_typename type)
{
	switch (type) {
	case CHAR:
		printf("%c ", element.char_g);
		break;
	case SHORT:
		printf("%hu ", element.short_g);
		break;
	case INT:
		printf("%d ", element.int_g);
		break;
	case LONG:
		printf("%ld ", element.long_g);
		break;
	case FLOAT:
		printf("%f ", element.float_g);
		break;
	case DOUBLE:
		printf("%lf ", element.double_g);
		break;
	}
}

static void display(struct vector *vector)
{
	struct vector *temp;

	temp = vector;
	if (vector->head == NULL) {
		printf("list is empty\n");
		return;
	}
	printf("elements in list are: ");
	for_each(element1, temp) {
		switch_print(VALUE(element1), TYPE(element1));
	}
	printf("\n");
}

int main(void)
{
	struct vector *v = malloc(sizeof(struct vector));
	struct vector *spliced_vector;
	struct element element;
	enum choice choice;
	enum g_typename type;
	g_datatype value;
	int temp = 0;
	int position;

	vector(v);
	while (1) {
		printf("1.append\t2.prepand\t3.insert\t4.chop\n");
		printf("5.behead\t6.delete\t7.set   \t8.get\n");
		printf("9.is_empty\t10.first\t11.last \t12.clear\n");
		printf("13.size \t14.move \t15.splice\t16.destruct\n");
		printf("17.display\t18.EXIT\n");
		scanf("%d", &temp);
		clear_buf();
		choice = temp;
		type = 0;
		temp = 0;
		position = 0;
		switch (choice) {
		case APPEND:
			get_element(&type, &value);
			if (v->append(v, ELEMENT(value, type)) == 0)
				display(v);
			else
				printf("append operation failed\n");
			break;
		case PREPEND:
			get_element(&type, &value);
			if (v->prepend(v, ELEMENT(value, type)) == 0)
				display(v);
			else
				printf("prepend operation failed\n");
			break;
		case INSERT:
			get_position(&position);
			get_element(&type, &value);
			if (v->insert(v, position, ELEMENT(value, type)) == 0)
				display(v);
			else
				printf("insert operation failed\n");
			break;
		case CHOP:
			if (v->chop(v) == -1)
				printf("chop operation failed\n");
			else
				display(v);
			break;
		case BEHEAD:
			if (v->behead(v) == -1)
				printf("behead operation failed\n");
			else
				display(v);
			break;
		case DELETE:
			get_position(&position);
			if (v->delete(v, position) == -1)
				printf("delete operation failed\n");
			else
				display(v);
			break;
		case SET:
			get_position(&position);
			get_element(&type, &value);
			if (v->set(v, position, ELEMENT(value, type)) == 0)
				display(v);
			else
				printf("set operation failed\n");
			break;
		case GET:
			get_position(&position);
			if (v->get(v, position, &element) == 0) {
				printf("element in %d pos is: ", position);
				switch_print(element.field, element.field_type);
				printf("\n");
			} else {
				printf("given position is out of range\n");
			}
			break;
		case IS_EMPTY:
			if (v->is_empty(v) == 0)
				printf("list is not empty\n");
			else
				printf("list is empty\n");
			break;
		case FIRST:
			if (v->first(v, &element) == 0) {
				printf("element in 1st pos is: ");
				switch_print(element.field, element.field_type);
				printf("\n");
			} else {
				printf("list is empty\n");
			}
			break;
		case LAST:
			if (v->last(v, &element) == 0) {
				printf("element in last pos is: ");
				switch_print(element.field, element.field_type);
				printf("\n");
			} else {
				printf("list is empty\n");
			}
			break;
		case CLEAR:
			if (v->clear(v) == 0)
				printf("list is cleared\n");
			else
				printf("list is already empty\n");
			break;
		case SIZE:
			temp = v->size(v);
			printf("size of list is: %d\n", temp);
			break;
		case MOVE:
			printf("enter the old position\n");
			get_position(&temp);
			printf("enter the new position\n");
			get_position(&position);
			if (v->move(v, temp, position) == 0)
				display(v);
			else
				printf("operation failed\n");
			break;
		case SPLICE:
			get_position(&position);
			spliced_vector = v->splice(v, position);
			if (spliced_vector->head != NULL) {
				printf("spliced element list\n");
				display(spliced_vector);
				v->clear(spliced_vector);
				free(spliced_vector);
			} else {
				printf("operation failed\n");
			}
			break;
		case DESTRUCT:
			v->destruct(v);
			printf("list is destructed\n");
			return 0;
		case DISPLAY:
			display(v);
			break;
		case EXIT:
			return 0;
		default:
			printf("invalid input\n");
			break;
		}
	}
}
