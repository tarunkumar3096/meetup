#ifndef _VECTOR_H_
#define _VECTOR_H_

#define ELEMENT(data, type) (			             \
		(struct element) { .field = (g_datatype)data, \
				.field_type = type})

#define for_each(entry, vector)				\
	for (struct vector_node *entry = vector->head;	\
	    entry != NULL; entry = entry->next)

#define for_each_rev(entry, vector)			\
	for (struct vector_node *entry = vector->tail;	\
	    entry != NULL; entry = entry->prev)

#define FLOAT_VALUE(entry) entry->element.field.float_g
#define DOUBLE_VALUE(entry) entry->element.field.double_g
#define VALUE(entry)  entry->element.field
#define TYPE(entry)   entry->element.field_type
#define FIRST_POS 1

typedef union g_datatype {
	char char_g;
	short short_g;
	int int_g;
	long long_g;
	float float_g;
	double double_g;
} g_datatype;

enum choice {
	APPEND = 1, PREPEND, INSERT, CHOP, BEHEAD, DELETE,
	SET, GET, IS_EMPTY, FIRST, LAST, CLEAR, SIZE,
	MOVE, SPLICE, DESTRUCT, DISPLAY, EXIT
};

enum g_typename {
	CHAR = 1,
	SHORT,
	INT,
	LONG,
	FLOAT,
	DOUBLE
};

struct element {
	g_datatype field;
	enum g_typename field_type;
};

struct vector_node {
	struct element element;
	struct vector_node *next;
	struct vector_node *prev;
};

struct vector {
	struct vector_node *head;
	struct vector_node *tail;

	/*
	 * append() - adds the given element at last of vector list.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*append)(struct vector *vector, struct element element);

         /*
	 * prepend() - adds the given element at the first of vector list.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*prepend)(struct vector *vector, struct element element);

	/*
	 * insert() - adds the given element at given position of vector list.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: position at which the element is going to be added in list.
	 * @arg3: structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*insert)(struct vector *vector, int pos,
		      struct element element);

	/*
	 * chop() - deletes the last element of vector list.
	 * @arg1: pointer to structure of vector in which the
	 * last element is going to be deleted.
	 *
	 *return: -1, on failure.
	 *         0, on success.
	 */
	int (*chop)(struct vector *vector);

	/*
	 * behead() - deletes the first element of vector list.
	 * @arg1: pointer to structure of vector in which the
	 * first element is going to be deleted.
	 *
	 *return: -1, on failure.
	 *         0, on success.
	 */
	int (*behead)(struct vector *vector);

	/*
	 * delete() - deletes the element at the given position of vector list.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: position at which the element is going to be deleted.
	 *
	 *return: -1, on failure.
	 *         0, on success.
	 */
	int (*delete)(struct vector *vector, int pos);

	/*
	 * set() - It sets the element at the given poistion with given element.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: position at which the given element is going to set in the list.
	 * @arg3: structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*set)(struct vector *vector, int pos, struct element element);

	/*
	 * get() - It gets the element at the given poistion of list
	 * and return it by argument.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: position at which the given element is going to get.
	 * @arg3: pointer to structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*get)(struct vector *vector, int pos, struct element *element);

	/*
	 * is_empty() - It tells the user whether the list is empty or not.
	 * @arg1: pointer to structure of type vector.
	 *
	 * return: -1, when list is empty.
	 *         0, otherwise.
	 */
	int (*is_empty)(struct vector *vector);

	/*
	 * first() - It gets the first element of the list and return it as argument.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: pointer to structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*first)(struct vector *vector, struct element *element);

	/*
	 * last() - It gets the last element of the list and return it as argument.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: pointer to structure element which holds generic data and its type.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*last)(struct vector *vector, struct element *element);

	/*
	 * clear() - It deletes all the elements in the list and
	 * vector is available for other operations.
	 * @arg1: pointer to structure of type vector.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*clear)(struct vector *vector);

	/*
	 * destruct() - It clear the list and frees the complete vector.
	 * @arg1: pointer to structure of type vector.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*destruct)(struct vector *vector);

	/*
	 * size() - It returns the size of list.
	 * @arg1: pointer to structure of type vector.
	 *
	 * return: 0, when no node in list.
	 *         size, number of node in list.
	 */
	int (*size)(struct vector *vector);

	/*
	 * move() - It moves the element at given old position of list to new position.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: old position from which the element is going to be removed.
	 * @arg3: new position at which the removed
	 * element is going to be added in list.
	 *
	 * return: -1, on failure.
	 *         0, on success.
	 */
	int (*move)(struct vector *vector, int old_pos, int new_pos);

	/*
	 * splice() - It divides the list into two from given position.
	 * @arg1: pointer to structure of type vector.
	 * @arg2: position from which the list is divided into two.
	 *
	 * return: newly created vector, on success.
	 *         NULL, on failure.
	 */
	struct vector * (*splice)(struct vector *vector, int pos);
};

/*
 * vector() - initialise the vector.
 * @arg1: pointer to structure of type vector.
 * It sets head, tail values to null and
 * points function pointers to coresponding funtions.
 *
 * return: vector which is initialised.
 */
struct vector vector(struct vector *vector);

#endif
