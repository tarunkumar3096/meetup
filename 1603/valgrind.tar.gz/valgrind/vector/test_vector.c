#include <stdio.h>
#include <stdlib.h>
#include <vector.h>

#define PTR_FAIL -2
#define ERR_VAL -1
#define INDEX_ERR -3

#define PREPEND 1
#define APPEND 2
#define INSERT 3
#define BEHEAD 1
#define CHOP 2
#define DELETE 3
#define FIRST 1
#define LAST 2
#define GET 3
#define MOVE 1
#define SET 2
#define IS_EMPTY 1
#define SIZE 2
#define CLEAR 1
#define DESTRUCT 2

#define INSERT_DATA 1
#define DELETE_DATA 2
#define RETRIEVE_DATA 3
#define MODIFY_DATA 4
#define VECTOR_DETAIL 5
#define CLEAR_DESTRUCT 6
#define SPLICE_VECTOR 7
#define DISPLAY_VECTOR 8
#define BUBBLE_SORT 9
#define EXIT 10

int err_check;
int choice;
int pos;
int destruct_flag;

struct element tmp_element;

int vector_display(struct vector *tmp_vec)
{
	printf("\nDisplaying Vector\n");
	for_each(tmp, tmp_vec) {
		switch (TYPE(tmp)) {
		case CHAR:
			printf("Char   : %c\n", VALUE(tmp).char_g);
			break;
		case SHORT:
			printf("Short  : %hd\n", VALUE(tmp).short_g);
			break;
		case INT:
			printf("Int    : %d\n", VALUE(tmp).int_g);
			break;
		case LONG:
			printf("Long   : %ld\n", VALUE(tmp).long_g);
			break;
		case FLOAT:
			printf("Float  : %f\n", VALUE(tmp).float_g);
			break;
		case DOUBLE:
			printf("Double : %lf\n", VALUE(tmp).double_g);
			break;
		}
	}
	printf("\n");
	return 0;
}

struct element input_element(struct element *element)
{
	int tmp;

	printf("Enter Type\n");
	printf("\t0.CHAR\n\t1.SHORT\n\t2.INT\n");
	printf("\t3.LONG\n\t4.FLOAT\n\t5.DOUBLE\n");
	printf("Enter:");
	scanf("%d", &tmp);
	element->field_type = tmp;
	printf("Data:");
	switch (element->field_type) {
	case CHAR:
		scanf(" %c", &(element->field.char_g));
		break;
	case SHORT:
		scanf("%hd", &(element->field.short_g));
		break;
	case INT:
		scanf("%d", &(element->field.int_g));
		break;
	case LONG:
		scanf("%ld", &(element->field.long_g));
		break;
	case FLOAT:
		scanf("%f", &(element->field.float_g));
		break;
	case DOUBLE:
		scanf("%lf", &(element->field.double_g));
		break;
	default:
		printf("Data type not defined\n");
	}
	return *element;
}

int print_element(struct element *element)
{
	switch (element->field_type) {
	case CHAR:
		printf("CHAR   : %c\n", element->field.char_g);
		break;
	case SHORT:
		printf("SHORT  : %hd\n", element->field.short_g);
		break;
	case INT:
		printf("INT    : %d\n", element->field.int_g);
		break;
	case LONG:
		printf("LONG   : %ld\n", element->field.long_g);
		break;
	case FLOAT:
		printf("FLOAT  : %f\n", element->field.float_g);
		break;
	case DOUBLE:
		printf("DOUBLE : %lf\n", element->field.double_g);
		break;
	default:
		printf("Data type not defined\n");
	}
	return 0;
}

int vector_data_insert(struct vector *tmp_vec, struct element tmp_element)
{
	printf("Insert Menu\n");
	printf("\t1.Prepend Data\n\t2.Append Data\n\t3.Insert at Position\n");
	printf("Enter:");
	scanf("%d", &choice);

	tmp_element = input_element(&tmp_element);

	switch (choice) {
	case PREPEND:
		err_check = tmp_vec->prepend(tmp_vec, tmp_element);
		break;
	case APPEND:
		err_check = tmp_vec->append(tmp_vec, tmp_element);
		break;
	case INSERT:
		printf("Enter the Position:");
		scanf("%d", &pos);
		err_check = tmp_vec->insert(tmp_vec, pos, tmp_element);
		break;
	default:
		printf("Enter the Valid choice\n");
	}
	if (err_check == PTR_FAIL)
		printf("Memory is NULL pointer\n");
	else if (err_check == INDEX_ERR)
		printf("Index out of Range\n");
	else if (err_check == ERR_VAL)
		printf("Empty Vector\n");
	else
		vector_display(tmp_vec);
	return 0;

}

int vector_data_delete(struct vector *tmp_vec)
{
	printf("Delete Menu\n");
	printf("\t1.Behead Data\n\t2.Chop Data\n\t3.Delete Data\n");
	printf("Enter:");
	scanf("%d", &choice);
	switch (choice) {
	case BEHEAD:
		err_check = tmp_vec->behead(tmp_vec);
		break;
	case CHOP:
		err_check = tmp_vec->chop(tmp_vec);
		break;
	case DELETE:
		printf("Enter the Position:");
		scanf("%d", &pos);
		err_check = tmp_vec->delete(tmp_vec, pos);
		break;
	default:
		printf("Enter the valid choice\n");
	}
	if (err_check == PTR_FAIL)
		printf("Memory is NULL pointer\n");
	else if (err_check == INDEX_ERR)
		printf("Index out of Range\n");
	else if (err_check == ERR_VAL)
		printf("Empty Vector\n");
	else
		vector_display(tmp_vec);
	return 0;
}

int vector_retrieve_data(struct vector *tmp_vec, struct element tmp_element)
{
	printf("Retrieve Data Menu\n");
	printf("\t1.First Data\n\t2.Last Dat\n\t3.Get Data\n");
	printf("Enter:");
	scanf("%d", &choice);
	switch (choice) {
	case FIRST:
		err_check = tmp_vec->first(tmp_vec, &tmp_element);
		break;
	case LAST:
		err_check = tmp_vec->last(tmp_vec, &tmp_element);
		break;
	case GET:
		printf("Enter the Position:");
		scanf("%d", &pos);
		err_check = tmp_vec->get(tmp_vec, pos, &tmp_element);
		break;
	default:
		printf("Enter Valid choice\n");
	}
	if (err_check == ERR_VAL)
		printf("Empty Vector\n");
	else if (err_check == PTR_FAIL)
		printf("Memory is NULL pointer\n");
	else if (err_check == INDEX_ERR)
		printf("Position Out of Range");
	else
		print_element(&tmp_element);
	return 0;
}

int vector_data_modify(struct vector *tmp_vec, struct element tmp_element)
{
	int old_pos;
	int new_pos;

	printf("Modification Menu\n");
	printf("\t1.Move Data\n\t2.Set Data\n");
	printf("Enter:");
	scanf("%d", &choice);
	switch (choice) {
	case MOVE:
		printf("Enter the Old Position:");
		scanf("%d", &old_pos);
		printf("Enter the New Position:");
		scanf("%d", &new_pos);
		err_check = tmp_vec->move(tmp_vec, old_pos, new_pos);
		break;
	case SET:
		tmp_element = input_element(&tmp_element);
		printf("Enter the Position:");
		scanf("%d", &new_pos);
		err_check = tmp_vec->set(tmp_vec, new_pos, tmp_element);
		break;
	default:
		printf("Enter Valid choice\n");
	}
	if (err_check == ERR_VAL)
		printf("Empty Vector\n");
	else if (err_check == PTR_FAIL)
		printf("Memory is NULL pointer\n");
	else
		vector_display(tmp_vec);
	return 0;
}

int vector_detail(struct vector *tmp_vec)
{
	printf("Vector Detail Menu\n");
	printf("\t1.Is Empty\n\t2.Vector Size\n");
	printf("Enter:");
	scanf("%d", &choice);

	switch (choice) {
	case IS_EMPTY:
		err_check = tmp_vec->is_empty(tmp_vec);
		if (err_check == 0)
			printf("Vector is Empty\n");
		else if (err_check == PTR_FAIL)
			printf("Memory is NULL pointer\n");
		else
			printf("Vector is not Empty\n");
		break;
	case SIZE:
		err_check = tmp_vec->size(tmp_vec);
		if (err_check == PTR_FAIL)
			printf("Memory is NULL pointer\n");
		else
			printf("Number of element : %d\n", err_check);
		break;
	default:
		printf("Enter Valid choice\n");
	}
	return 0;
}

int vector_clear(struct vector *tmp_vec)
{
	printf("Menu\n");
	printf("\t1.Clear Vector\n\t2.Destruct\n");
	printf("Enter:");
	scanf("%d", &choice);
	switch (choice) {
	case CLEAR:
		err_check = tmp_vec->clear(tmp_vec);
		if (err_check != PTR_FAIL)
			printf("Vector Cleared\n");
		break;
	case DESTRUCT:
		err_check = tmp_vec->destruct(tmp_vec);
		tmp_vec = NULL;
		destruct_flag = 1;
		break;
	default:
		printf("Enter Valid choice\n");
	}
	if (err_check == PTR_FAIL)
		printf("Memory is NULL pointer\n");
	return 0;
}


int bubble_sort(struct vector *tmp_vec)
{
	int i;
	int j;
	int tmp_type;
	int tmp_val = tmp_vec->size(tmp_vec);

	struct element tmp1;
	struct element tmp2;

	if (tmp_val == 0)
		return ERR_VAL;
	for_each(tmp, tmp_vec) {
		tmp_type = TYPE(tmp);
		break;
	}

	for_each(tmp, tmp_vec) {
		if (TYPE(tmp) != tmp_type)
			return -4;
	}

	for (i = 1; i <= tmp_val; i++) {
		for (j = 1; j <= (tmp_val - i); j++) {
			err_check = tmp_vec->get(tmp_vec, j, &tmp1);
			if (err_check == PTR_FAIL)
				return PTR_FAIL;

			err_check = tmp_vec->get(tmp_vec, j + 1, &tmp2);
			if (err_check == PTR_FAIL)
				return PTR_FAIL;

			switch (tmp_type) {
			case CHAR:
				if (tmp1.field.char_g > tmp2.field.char_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			case SHORT:
				if (tmp1.field.short_g > tmp2.field.short_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			case INT:
				if (tmp1.field.int_g > tmp2.field.int_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			case LONG:
				if (tmp1.field.long_g > tmp2.field.long_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			case FLOAT:
				if (tmp1.field.float_g > tmp2.field.float_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			case DOUBLE:
				if (tmp1.field.double_g > tmp2.field.double_g)
					tmp_vec->move(tmp_vec, j, j + 1);
				break;
			}
		}
	}
	return 0;
}

int main(void)
{
	struct vector *tmp_vec = malloc(sizeof(struct vector));
	struct vector *splice_vector;

	int splice_flag = 0;

	if (tmp_vec == NULL) {
		printf("Memory is NULL pointer");
		return 0;
	}
	*tmp_vec = vector(tmp_vec);

	while (1) {
		printf("Menu\n");
		printf("\t1.Insert Data  \t|Prepend |Append |Insert at pos|\n");
		printf("\t2.Delete Data  \t|Behead  |Chop   |Delete at pos|\n");
		printf("\t3.Retrieve Data\t|First   |Last   |Get data pos |\n");
		printf("\t4.Modify Vector\t|Move Data       |Set Data     |\n");
		printf("\t5.Vector Detail\t|Is Empty        |Vector Size  |\n");
		printf("\t6.Clear/Destruct\n");
		printf("\t7.Splice Vector\n");
		printf("\t8.Display\n");
		printf("\t9.Bubble Sort\n");
		printf("\t10.Exit\n");
		printf("Enter:");
		scanf("%d", &choice);

		switch (choice) {
		case INSERT_DATA:
			vector_data_insert(tmp_vec, tmp_element);
			break;
		case DELETE_DATA:
			vector_data_delete(tmp_vec);
			break;
		case RETRIEVE_DATA:
			vector_retrieve_data(tmp_vec, tmp_element);
			break;
		case MODIFY_DATA:
			vector_data_modify(tmp_vec, tmp_element);
			break;
		case VECTOR_DETAIL:
			vector_detail(tmp_vec);
			break;
		case CLEAR_DESTRUCT:
			vector_clear(tmp_vec);
			break;
		case SPLICE_VECTOR:
			printf("Enter the Position:");
			scanf("%d", &pos);
			splice_vector = tmp_vec->splice(tmp_vec, pos);
			splice_flag = 1;
			if (splice_vector != NULL) {
				printf("Original Vector\n");
				vector_display(tmp_vec);
				printf("Spliced Vector\n");
				vector_display(splice_vector);
			}  else {
				printf("Memory ERROR\n");
			}
			break;
		case DISPLAY_VECTOR:
			err_check = vector_display(tmp_vec);
			if (err_check == ERR_VAL)
				printf("Empty Vector/Index out of Range\n");
			else if (err_check == PTR_FAIL)
				printf("Memory is NULL pointer\n");
			break;
		case BUBBLE_SORT:
			err_check = bubble_sort(tmp_vec);
			if (err_check == -4) {
				printf("Mixed types cannot be sorted\n");
				printf("Only same datatypes can  be sorted\n");
			}

			else if (err_check == ERR_VAL)
				printf("Empty Vector\n");
			else if (err_check == PTR_FAIL)
				printf("Memory is NULL pointer\n");
			else
				vector_display(tmp_vec);
			break;
		case EXIT:
			if (destruct_flag != 1)
				free(tmp_vec);
			if (splice_flag != 0)
				free(splice_vector);
			return 0;
		default:
			printf("Enter Valid choice\n");
		}
	}
}
