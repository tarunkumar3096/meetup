#ifndef __VECTOR_H__
#define __VECTOR_H__

typedef union g_datatype {
	char char_g;
	short short_g;
	int int_g;
	long long_g;
	float float_g;
	double double_g;
} g_datatype;

enum g_typename	{
	CHAR,
	SHORT,
	INT,
	LONG,
	FLOAT,
	DOUBLE
};

struct element {
	g_datatype field;
	enum g_typename field_type;
};

struct vector_node {
	struct element element;
	struct vector_node *next;
	struct vector_node *prev;
};

struct vector {
	int count;
	struct vector_node *head;
	struct vector_node *tail;
	int (*append)(struct vector *vector, struct element element);
	int (*prepend)(struct vector *vector, struct element element);
	int (*insert)(struct vector *vector, int pos, struct element element);

	int (*chop)(struct vector *vector);
	int (*behead)(struct vector *vector);
	int (*delete)(struct vector *vector, int pos);

	int (*set)(struct vector *vector, int pos, struct element element);

	int (*get)(struct vector *vector, int pos, struct element *element);

	int (*is_empty)(struct vector *vector);

	int (*first)(struct vector *vector, struct element *element);
	int (*last)(struct vector *vector, struct element *element);
	int (*clear)(struct vector *vector);
	int (*destruct)(struct vector *vector);
	int (*size)(struct vector *vector);
	int (*move)(struct vector *vector, int old_pos, int new_pos);
	struct vector * (*splice)(struct vector *vector, int pos);

	#define ELEMENT(data, type)	\
		(struct element) { .field = data, .field_type = type}

	#define for_each(entry, vector)		\
		for (struct vector_node *entry = vector->head;\
			entry != NULL; entry = entry->next)

	#define for_each_rev(entry, vector)	\
		for (struct vector_node *entry = vector->tail;\
		entry != NULL; entry = entry->prev)

	#define VALUE(entry)  entry->element.field
	#define TYPE(entry)   entry->element.field_type
};

struct vector vector(struct vector *vector);

/*
 * prepend - prepend will prepend the data to starting of vector
 *
 * @struct vector *vector  : Vector which the node is to be prepended
 *
 * @struct element element : Element structure containing the input data
 *
 * Return : Returns 0 If prepended or error if fails
 */
static int prepend(struct vector *vector, struct element element);

/*
 * append - append will append the data to last of vector
 *
 * @struct vector *vector  : Vector which the node is to be appended
 *
 * @struct element element : Element structure containing the input data
 *
 * Return : Returns 0 If appended or error if fails
 */
static int append(struct vector *vector, struct element element);

/*
 * insert - insert will data into the vector at particular position
 *
 * @struct vector *vector  : Vector which the node is to be inserted
 *
 * @pos : position at which the node is to be inserted
 *
 * @struct element element : Element structure containing the input data
 *
 * Return : Returns 0 If inserted or error if fails
 */
static int insert(struct vector *vector, int pos, struct element element);

/*
 * behead - behead will free the first node of the vector
 *
 * @struct vector *vector  : Vector which the first node is to be deleted
 *
 * Return : Returns 0 If behead or error if fails
 */
static int behead(struct vector *vector);

/*
 * chop - chop will free the last node of the vector
 *
 * @struct vector *vector  : Vector which the last node is to be deleted
 *
 * Return : Returns 0 If chopped or error if fails
 */
static int chop(struct vector *vector);

/*
 * delete - delete will free the node of the vector at particular position
 *
 * @struct vector *vector  : Vector which the node is to be deleted
 *
 * @pos : position at which the node is to be deleted
 *
 * Return : Returns 0 If deleted or error if fails
 */
static int delete(struct vector *vector, int pos);

/*
 * clear - clear will free all the elements of the vector
 *
 * @struct vector *vector  : Vector which the elements are to be cleared
 *
 * Return : Returns 0 If cleared or error if fails
 */
static int clear(struct vector *vector);

/*
 * destruct - destruct will free the dynamically allocated memory of the vector
 *
 * @struct vector *vector  : Vector which is to be destroyed
 *
 * Return : Returns 0 If destructed or error if fails
 */
static int destruct(struct vector *vector);

/*
 * first - first will retrieve first data from the vector
 *
 * @struct vector *vector  : Vector in which the data is to be retrieved
 *
 * @struct element element : Element structure to store the retrieved data
 *
 * Return : Returns 0 If retrieved or error if fails
 */
static int first(struct vector *vector, struct element *element);

/*
 * last - last will retrieve last data from the vector
 *
 * @struct vector *vector  : Vector in which the data is to be retrieved
 *
 * @struct element element : Element structure to store the retrieved data
 *
 * Return : Returns 0 If retrieved or error if fails
 */
static int last(struct vector *vector, struct element *element);

/*
 * get - get will retrieve the data of the given position from the vector
 *
 * @struct vector *vector  : Vector in which the data is to be retrieved
 *
 * @pos : position at which the data is to be retrieved
 *
 * @struct element element : Element structure to store the retrieved data
 *
 * Return : Returns 0 If retrieved or error if fails
 */
static int get(struct vector *vector, int pos, struct element *element);

/*
 * is_empty - check whether the vector is empty or not
 *
 * @struct vector *vector  : Vector in which it is to be checked
 *
 * Return : Returns 0 If empty or error if not empty
 */
static int is_empty(struct vector *vector);

/*
 * size - size will return the number of elements in the vector
 *
 * @struct vector *vector  : Vector in which the size is to be found
 *
 * Return : returns the number of data in vector
 *
 */
static int size(struct vector *vector);
/*
 * Move the Data from old pos to New pos
 */
/*
 * move - move the data from the old position to the new position
 *
 * @struct vector *vector  : Vector in which the datas are to be moved
 *
 * @old_pos : position which has the data to be moved
 * @new_pos : new position in which the data is to be moved
 *
 * Return : Returns success if moved or error if not set
 */
static int move(struct vector *vector, int old_pos, int new_pos);

/*
 * set - set a new value in the desired position replacing the new value
 *
 * @struct vector *vector  : Vector in which the value is to be set
 *
 * @pos : position in which the value is to be set
 *
 * @struct element element : Element structure containing the input data
 *
 * Return : Returns success if set or error if not set
 */
static int set(struct vector *vector, int pos, struct element element);

/*
 * splice - splices the vector into two based on given position
 *
 * @struct vector *vector : Vector which is to be spliced
 *
 * @pos    : position from which the vector is spliced
 *
 * Return  : Returns the new vector
 */
static struct vector *splice(struct vector *vector, int pos);

#endif
