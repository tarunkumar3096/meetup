#include <vector.h>
#include <stdlib.h>

#define PTR_FAIL -2
#define ERR_VAL -1
#define SUCCESS 0
#define INDEX_ERR -3

struct vector vector(struct vector *vector)
{
	vector->head = NULL;
	vector->tail = NULL;
	vector->count = 0;

	vector->append = &append;
	vector->prepend = &prepend;
	vector->insert = &insert;

	vector->chop = &chop;
	vector->behead = &behead;
	vector->delete = &delete;

	vector->set = &set;
	vector->get = &get;
	vector->is_empty = &is_empty;

	vector->first = &first;
	vector->last = &last;
	vector->clear = &clear;
	vector->destruct = &destruct;
	vector->size = &size;
	vector->move = &move;
	vector->splice = &splice;

	return *vector;
}

static int prepend(struct vector *vector, struct element element)
{
	if (vector == NULL)
		return PTR_FAIL;

	struct vector_node *new_node = malloc(sizeof(struct vector_node));

	if (vector->head == NULL) {
		vector->head = new_node;
		vector->tail = new_node;
		vector->head->next = NULL;
		vector->head->prev = NULL;
		vector->head->element = element;
		vector->count++;
		return SUCCESS;
	}
	new_node->element = element;
	new_node->next = vector->head;
	new_node->prev = NULL;
	vector->head->prev = new_node;
	vector->head = new_node;
	vector->count++;

	return SUCCESS;
}

static int append(struct vector *vector, struct element element)
{
	if (vector == NULL)
		return PTR_FAIL;

	struct vector_node *new_node = malloc(sizeof(struct vector_node));
	struct vector_node *last = vector->head;

	new_node->element = element;
	vector->count++;
	new_node->next = NULL;

	if (vector->head == NULL) {
		new_node->prev = NULL;
		vector->head = new_node;
		vector->tail = new_node;
		return SUCCESS;
	}

	while (last->next != NULL)
		last = last->next;

	last->next = new_node;
	new_node->prev = last;
	vector->tail = new_node;

	return SUCCESS;
}

static int insert(struct vector *vector, int pos, struct element element)
{
	if (vector == NULL)
		return PTR_FAIL;

	struct vector_node *new_node = malloc(sizeof(struct vector_node));
	struct vector_node *prev_node;
	struct vector_node *next_node;

	int tmp_pos = 2;

	if (pos < 1 || pos > vector->count + 1)
		return INDEX_ERR;

	if (vector->head == NULL && pos != 1)
		return ERR_VAL;

	if (pos == 1)
		return prepend(vector, element);

	if (pos == vector->count + 1)
		return append(vector, element);

	new_node->element = element;
	vector->count++;
	prev_node = vector->head;

	while (prev_node != NULL && tmp_pos < pos) {
		tmp_pos++;
		prev_node = prev_node->next;
	}
	next_node = prev_node->next;

	prev_node->next = new_node;
	new_node->next = next_node;
	next_node->prev = new_node;
	return SUCCESS;
}

static int behead(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	struct vector_node *tmp = vector->head;

	if (vector->head == NULL)
		return ERR_VAL;

	if (vector->head->next == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
	} else {
		vector->head = vector->head->next;
		vector->head->prev = NULL;
	}
	vector->count--;
	free(tmp);
	return SUCCESS;
}


static int chop(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	struct vector_node *last = vector->tail;

	if (vector->head == NULL)
		return ERR_VAL;

	if (last->prev == NULL) {
		vector->head = NULL;
		vector->tail = NULL;
	} else {
		vector->tail = vector->tail->prev;
		vector->tail->next = NULL;
	}
	vector->count--;
	free(last);
	return SUCCESS;
}

static int delete(struct vector *vector, int pos)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;

	struct vector_node *prev_node;
	struct vector_node *next_node;
	struct vector_node *tmp;

	int tmp_pos = 2;

	if (pos < 1 || pos > vector->count)
		return INDEX_ERR;

	if (pos == 1)
		return behead(vector);

	if (pos == vector->count)
		return chop(vector);

	prev_node = vector->head;

	while (prev_node != NULL && tmp_pos < pos) {
		tmp_pos++;
		prev_node = prev_node->next;
	}
	tmp = prev_node->next;
	next_node = tmp->next;
	prev_node->next = next_node;
	next_node->prev = prev_node;
	vector->count--;
	free(tmp);
	return SUCCESS;
}

static int clear(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	while (behead(vector) != ERR_VAL)
		;
	return SUCCESS;
}

static int destruct(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	clear(vector);
	free(vector);
	vector = NULL;
	return SUCCESS;
}

static int first(struct vector *vector, struct element *element)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;
	*element = vector->head->element;
	return SUCCESS;
}

static int last(struct vector *vector, struct element *element)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;
	*element = vector->tail->element;
	return SUCCESS;
}

static int get(struct vector *vector, int pos, struct element *element)
{
	int tmp_pos = 2;
	struct vector_node *tmp_node = vector->head;

	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;

	if (pos < 1 || pos > vector->count)
		return INDEX_ERR;

	if (pos == 1)
		return first(vector, element);

	if (pos == vector->count)
		return last(vector, element);

	while (tmp_node != NULL && tmp_pos < pos) {
		tmp_pos++;
		tmp_node = tmp_node->next;
	}
	tmp_node = tmp_node->next;

	*element = tmp_node->element;

	return SUCCESS;
}
static int is_empty(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return SUCCESS;
	else
		return ERR_VAL;
}

static int size(struct vector *vector)
{
	if (vector == NULL)
		return PTR_FAIL;

	return vector->count;
}

static int move(struct vector *vector, int old_pos, int new_pos)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;

	if (old_pos < 1 || old_pos > vector->count)
		return INDEX_ERR;
	if (new_pos < 1 || new_pos > vector->count)
		return INDEX_ERR;

	struct vector_node *new_node = malloc(sizeof(struct vector_node));

	get(vector, old_pos, &new_node->element);
	delete(vector, old_pos);
	insert(vector, new_pos, new_node->element);

	return SUCCESS;
}

static int set(struct vector *vector, int pos, struct element element)
{
	if (vector == NULL)
		return PTR_FAIL;

	if (vector->head == NULL)
		return ERR_VAL;

	if (pos < 1 || pos > vector->count)
		return INDEX_ERR;

	delete(vector, pos);
	insert(vector, pos, element);
	return SUCCESS;
}

static struct vector *splice(struct vector *vector, int pos)
{
	if (vector == NULL || vector->head == NULL)
		return NULL;

	if (pos < 1 || pos > vector->count)
		return NULL;

	struct vector *tmp_vec = malloc(sizeof(struct vector));
	struct vector_node *tmp_node = vector->head;
	int tmp_pos = 1;

	if (tmp_vec == NULL)
		return NULL;

	while (tmp_node != NULL && tmp_pos < pos - 1) {
		tmp_pos++;
		tmp_node = tmp_node->next;
	}

	tmp_vec->head = tmp_node->next;
	tmp_vec->tail = vector->tail;
	vector->tail = tmp_node;
	vector->tail->next = NULL;

	return tmp_vec;
}
