#include <stdio.h>
#include <stdlib.h>


int main()
{
	int a;
	int *first = malloc(10 * sizeof(int));
	first[11] = 10;
	a = first[11];
	first = malloc(5 * sizeof(int));
	free(first);
	first[0] = 12;
	free(first);

	return 0;
}
