#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <error.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	int ret;
	pid_t fork_ret;
	int status;

	printf("Before Setting UID\n");

	fork_ret = fork();
	switch (fork_ret) {
	case -1:
		error(1, errno, "Error creating child");
	case 0:
		ret = execl("/usr/bin/id", "id", NULL);
		if (ret == -1)
			error(1, errno, "Error in creating child process");
		break;
	default:
		ret = wait(&status);
		if (ret == -1)
			error(1, errno, "Error  in Wait");
	}

	printf("\nAfter setting uid\n");
	fork_ret = fork();
	switch (fork_ret) {
	case -1:
		error(1, errno, "Error creating child");
	case 0:
		ret = setuid(1000);
		if (ret == -1)
			error(1, errno, "Cannot change userid");

		ret = seteuid(1000);
		if (ret == -1)
			error(1, errno, "Cannot change effective uid");

		ret = execl("/usr/bin/id", "id", NULL);
		if (ret == -1)
			error(1, errno, "Error in creating child process");
		break;
		
	default:
		ret = wait(&status);
		if (ret == -1)
			error(1, errno, "Error  in Wait");
	}
	
	return 0;
}
