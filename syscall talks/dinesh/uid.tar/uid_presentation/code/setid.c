#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <error.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	int ret;
	
	printf("Before Setting ID\n");
	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());

	ret = setuid(1000);
	if (ret == -1)
		error(1, errno, "Cannot change userid");
	
	ret = seteuid(1000);
	if (ret == -1)
		error(1, errno, "Cannot change effective userid");
	
	printf("\nAfter Setting ID\n");
	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());
	
	return 0;
}
