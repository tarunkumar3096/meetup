#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
	uid_t uid = getuid();
	uid_t euid = geteuid();

	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());

	return 0;
}

