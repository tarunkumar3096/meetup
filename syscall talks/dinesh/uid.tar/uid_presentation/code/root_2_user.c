#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <error.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	int ret;

	printf("Before Setting UID\n");
	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());

	/* Changing from root to normal user */
	ret = setuid(1000);
	if (ret == -1)
		error(1, errno, "Cannot change userid");
	
	ret = seteuid(1000);
	if (ret == -1)
		error(1, errno, "Cannot change effective userid");
	
	printf("\nAfter Setting UID\n");
	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());

	/*Changing from normal to root user*/
	ret = setuid(0);
	if (ret == -1)
		error(1, errno, "Cannot change into root userid");
	
	ret = seteuid(0);
	if (ret == -1)
		error(1, errno, "Cannot change into root effective userid");
	printf("\nSetting UID 2nd tym\n");
	printf("User ID       : %d\n", getuid());
	printf("Effective UID : %d\n", geteuid());

	return 0;
}
