#include <stdio.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	if (argc != 2)
		error(1, 0, "Usage: program <filename>");

	char *file_name = argv[1];
	int ret;

	ret = access(file_name, F_OK);
	if (ret == 0)
		printf("\"%s\" exists\n", file_name);
	else {
		printf("\"%s\" doesn't exists\n", file_name);
		return 0;
	}

	ret = access(file_name, R_OK);
	if (ret == 0)
		printf("\"%s\" has read permissions\n", file_name);
	else
		printf("\"%s\" has no read permissions\n", file_name);

	
	ret = access(file_name, W_OK);
	if (ret == 0)
		printf("\"%s\" has write permissions\n", file_name);
	else
		printf("\"%s\" has no write permissions\n", file_name);


	ret = access(file_name, X_OK);
	if (ret == 0)
		printf("\"%s\" has executable permissions\n", file_name);
	else
		printf("\"%s\" has no executable permissions\n", file_name);	
	return 0;
}
