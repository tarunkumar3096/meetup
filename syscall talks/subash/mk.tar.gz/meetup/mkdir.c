#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <error.h>
#include <stdio.h>
#include <dirent.h>
#include <errno.h>
void main(int argc, char *argv[])
{
	int i = 0 ;
	int fd;
	int check;
	int check1;

	fd = mkdir(argv[1], 0777);
	printf("fd=%d\n",fd);
	if (fd == -1)
		error(1,errno,"cant create");
	check1 = dirfd(argv[1]);
	if (check1 == -1)
		error(1,errno,"cannnnnnnt create");
	check = mkdirat(check1, argv[2], 0700);
	if (check == -1)
		error(1,errno,"cant create");
       
	
}
