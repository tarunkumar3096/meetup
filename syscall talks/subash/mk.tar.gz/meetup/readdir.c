#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <error.h>
#include <errno.h>
int main(int argc, char *argv[])
{
	DIR *fd;
	struct dirent *dirdetails;
	if (argc != 2)
		error(1, errno, "Few arguments");
	fd = opendir(argv[1]);
	if (fd == NULL)
		error(1, errno, "Cannot Open directory");
	while ((dirdetails = readdir(fd)) != NULL) {
		printf("inode=%d\n", dirdetails->d_ino);
		printf("char=%s\n", dirdetails->d_name);
	}
	
}
