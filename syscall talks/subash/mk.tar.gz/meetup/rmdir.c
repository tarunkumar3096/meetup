#include <unistd.h>
#include <error.h>
#include <stdio.h>
#include <errno.h>

void main(int argc, char *argv[])
{
	int fd1;

	fd1 = rmdir(argv[1]);
	if (fd1 == -1)
		error(1,errno,"cant delete");
}
