#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <error.h>
#include <stdio.h>
#include <dirent.h>

#include <errno.h>
void main(int argc, char *argv[])
{
	int i = 0 ;
	int fd;
	int fd1;
	int check;
	int check1;

	fd1 = rmdir(argv[1]);
	if (fd1 == -1)
	error(1,errno,"cant delete");
}
