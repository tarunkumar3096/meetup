#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	int ret;
	char *linkname;
	char *target;

	if (argc != 3)
		error(1, errno, "usage <redirect>");
	linkname = argv[2];
	target = argv[1];
	ret = symlink(target, linkname);
	if (ret == -1)
		error(1, errno, "link creation failed");
	return 0;
}
