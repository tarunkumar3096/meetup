#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	char *pathname;
	int ret;
	char buf[50];

	if (argc != 2)
		error(1, errno, "usage: redir <pathname>");
	pathname = argv[1];
	memset(buf, 0, sizeof(buf));

	//ret = readlink(pathname, buf, sizeof(buf));
	ret = read(pathname, buf, sizeof(buf));
	if (ret == -1)
		error(1, errno, "readlink failed");
	printf("%s\n", buf);

	ret = remove(buf);
	if (ret == -1)
		error(1, errno, "error remove failed");
	return 0;
}
