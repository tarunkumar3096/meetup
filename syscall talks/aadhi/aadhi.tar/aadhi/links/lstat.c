#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	char *pathname;
	int ret;
	int buf1[10];
	struct stat stat_buf;

	if (argc != 2)
		error(1, errno, "usage: redir <pathname>");
	pathname = argv[1];

	ret = lstat(pathname, &stat_buf);
	if (ret == -1)
		error(1, errno, "lstat failed");

	char buf[stat_buf.st_size + 1];
	//char buf[2];
	
	ret = readlink(pathname, buf, sizeof(buf));
	if (ret == -1)
		error(1, errno, "readlink failed");
	printf("path = %s\n", buf);

	ret = open(buf, O_RDONLY);
	if (ret == -1)
		error(1, errno, "error opening failed");
	printf("open fd = %d\n", ret);

	ret = read(ret, buf1, sizeof(buf1));
	if (ret == -1)
		error(1, errno, "read failed");
	printf("content = %s\n", buf1);
	return 0;
}
