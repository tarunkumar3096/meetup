#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mqueue.h>
#include <error.h>
#include <errno.h>
#include "common.h"


int main(int argc, char **argv)
{
	int mq_sent_ret;
	mqd_t mq;
	struct mq_attr attr;
	char buffer[MAX_SIZE];
	attr.mq_flags = 0;
	attr.mq_maxmsg = 10;
	attr.mq_msgsize = MAX_SIZE;
	attr.mq_curmsgs = 0;

	printf("SENDER\n");
	
        mq = mq_open(QUEUE_NAME, O_CREAT | O_WRONLY, 0644, &attr);
	if (mq == -1)
		error(1, errno, "Opening queue failed");
    
	printf("Send to server (enter \"exit\" to stop it):\n");

	do {
		printf("> ");
		fflush(stdin);

		memset(buffer, 0, MAX_SIZE);
		fgets(buffer, MAX_SIZE, stdin);
	       
		mq_sent_ret = mq_send(mq, buffer, strlen(buffer), 0);
		if (mq_sent_ret == -1)
			error(1, errno, "Sending failed");
	} while (strncmp(buffer, MSG_STOP, strlen(MSG_STOP)));

        
	mq_close(mq);

	return 0;
}
