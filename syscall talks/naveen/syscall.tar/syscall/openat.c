#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main() {

    DIR *dirp;
    int dir_fd;

    int fd;
    char buf[16];
    dirp = opendir("/home/user/tickets/vector/vector");
    perror("opendir");
    dir_fd = dirfd(dirp);
    perror("dirfd");

    fd = openat(dir_fd, "file", O_RDONLY);
    perror("openat");
    sleep(15);

    read(fd, buf, sizeof(buf));
    printf("%s\n", buf); 
    closedir(dirp);
}

