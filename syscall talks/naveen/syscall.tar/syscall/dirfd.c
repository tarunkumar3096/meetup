#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <string.h>

int main(int argc,char *argv[])
{
    DIR *fd = opendir("tickets");
    int fp;
    int fd1;
    int rlen;
    char buffer[256];
    int result = 0;
    char buf[256];
    char *retp;
  
    if (argc > 2) {
	printf("%s: Too many operands \nUsage: %s <pathname>\n", argv[0], argv[0]);
	exit(1);
    }
  
    if (argc == 1) {
	printf("argc is 1\n");
	const char* home = getenv("HOME");
	int i = chdir(home);
    
	if (i < 0) {
	    printf("directory couldn't be changed\n");
	}  else {
	    printf("directory changed\n");
	    printf("home = %s\n", home);
	    //  system("rm -r dir"); /* deleting particular directory or file when we changed to home directory */
	}
	exit(0);
    }
  
    result = chdir(argv[1]);
    
    if (result == 0) {
	system("pwd");
	retp = getcwd(buf, 256);
	printf("CWD: %s\n", retp);
      	printf("directory changed\n");
	fp = dirfd(fd);
	fd1 = openat(fp, "vector/vector/static", O_RDONLY);
	rlen = read(fd1, &buffer, 4);
	write(1, &buffer, rlen);
	//system("mkdir dir");   /* deleting dir directory when we changed to this path */
	exit(0);
    } else {
	printf("Couldn't change directory to %s\n", argv[1]);
    }
    return 0;
}
