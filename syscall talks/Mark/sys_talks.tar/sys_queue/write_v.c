#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/uio.h>

int main(int argc, char *argv[])
{
	char *filename;
	struct iovec iov[4];
	ssize_t size;
	int fd;
	int i;
	int ret;

	char *buff[] = {
		"Bitter bought a butter, \n",
                "But the butter was bitter, \n",
                "So she bought a better butter, \n",
                 "To make the bitter butter better.\n" };
	filename = argv[1];



	fd = open (filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
	if (fd == -1) {
		perror("open");
		return 1;
	}

	for ( i = 0; i < 4; i++) {
		iov[i].iov_base = buff[i];
		iov[i].iov_len = strlen(buff[i])+1;
	}

	size = writev(fd, iov, 4);
	if (size == -1) {
		perror("writev");
		return 1;
	}


	printf( "written %d bytes\n",size);

       	ret = close(fd);
	if (ret == -1) {
		perror("close");
		}
	return 0;
}
		
       
