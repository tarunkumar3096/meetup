#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/uio.h>

int main(int argc, char *argv[])
{
	char *filename;
	struct iovec iov[4];
	ssize_t size;
	int fd;
	int i;
	int ret;
	char foo1[26];
	char foo2[29];
	char foo3[33];
	char foo4[35];

	filename = argv[1];


	fd = open (filename, O_RDONLY);
	if (fd == -1) {
		perror("open");
		return 1;
	}

	iov[0].iov_base = foo1;
	iov[0].iov_len = sizeof(foo1);
	iov[1].iov_base = foo2;
	iov[1].iov_len = sizeof(foo2);
	iov[2].iov_base = foo3;
	iov[2].iov_len = sizeof(foo3);
	iov[3].iov_base = foo4;
	iov[3].iov_len = sizeof(foo4);
	
	size = readv(fd, iov, 4);
	if (size == -1) {
		perror("readv");
		return 1;
	}

	for (i = 0; i < 4; i++)
		printf( "line %d: %s", i,(char *) iov[i].iov_base);

       	ret = close(fd);
	if (ret == -1) {
		perror("close");
		}
	return 0;
}
