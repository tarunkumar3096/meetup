#include <stdio.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	if(argc != 3)
		error(1, 0, "Error Usage: ./my_ln <old_filename> <new_filename>");
	if(link(argv[1], argv[2]) == -1)
		error(1, errno, "Error Linking");

	return 0;
}
	   
