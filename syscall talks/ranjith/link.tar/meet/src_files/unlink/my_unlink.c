#include <stdio.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
int main(int argc, char *argv[])
{
	if(argc != 2)
		error(1, 0, "Error Usage: ./unlink <filename>");
	if(unlink(argv[1]) == -1)
		error(1, errno, "Error unlinking");

	return 0;
}
	   
