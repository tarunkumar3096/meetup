#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(void)
{
	
	if (!fork()) {

		char buf[128];
		int sock_fd;
		int ret;
		int rlen;
		int optval = 1;
		struct sockaddr_in me;
		FILE *fp;

		sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
		if (sock_fd == -1)
			error(1, errno, "unable to create socket");

		ret = setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
				 &optval, sizeof(optval));
		if (ret == -1)
			error(1, errno, "unable to configure socket");
	
		me.sin_family = AF_INET;
		me.sin_port = htons(3000);
		me.sin_addr.s_addr = inet_addr("127.0.0.1");
		
		ret = bind(sock_fd, (struct sockaddr *)&me, sizeof(me));
		if (ret == -1)
			error(1, errno, "unable to bind socket to host");
	
		rlen = recv(sock_fd, buf, sizeof(buf), 0);
		if (rlen == -1)
			error(1, errno, "unable to receive from client");
		buf[rlen] = 0;

		fp = fopen("child", "w+");
		fputs(buf, fp);
		fclose(fp);

		ret = close(sock_fd);
		if (ret == -1)
			error(1, errno, "unable to close child socket");
		
	} else {

		char buf[128];
		int sock_fd;
		int rlen;
		int ret;
		struct sockaddr_in host;
		FILE *fp;

		sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
		if (sock_fd == -1)
			error(1, errno, "unable to create socket");

		host.sin_family = AF_INET;
		host.sin_port = htons(3000);
		host.sin_addr.s_addr = inet_addr("127.0.0.1");

		sleep(1);
		ret = connect(sock_fd, (struct sockaddr *)&host, sizeof(host));
		if (ret == -1)
			error(1, errno, "unable to connect to host");

		fp = fopen("parent", "r");
		fgets(buf, sizeof(buf), fp);
		fclose(fp);

		ret = send(sock_fd, buf, strlen(buf), 0);
		if (ret == -1)
			error(1, errno, "unable to send message");
 
		ret = shutdown(sock_fd, SHUT_RDWR) || close(sock_fd);
		if (ret == 1)
			error(1, errno, "unable to close parent socket");
		wait(NULL);
	}

	return 0;
}
