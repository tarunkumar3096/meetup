#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <error.h>
#include <errno.h>
#include <stdio.h>

int main(void)
{
	char buf[32];
	int sock_fd;
	int optval = 1;
	int ret;
	int rlen;
	struct sockaddr_in me;

	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock_fd == -1)
		error(1, errno, "unable to create socket");

	ret = setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
					 &optval, sizeof(optval));
	if (ret == -1)
		error(1, errno, "unable to configure socket");
	
	me.sin_family = AF_INET;
	me.sin_port = htons(3000);
	me.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = bind(sock_fd, (struct sockaddr *)&me, sizeof(me));
	if (ret == -1)
		error(1, errno, "unable to bind socket to host");

	while (1) {
		ret = recv(sock_fd, buf, sizeof(buf), 0);
		if (ret == -1)
			error(1, errno, "unable to receive from client");
		else if (ret == 0)
			break;

		buf[ret] = 0;
		printf("Msg: %s\n", buf);
	}
	
	ret = close(sock_fd);
	if (ret == -1)
		error(1, errno, "error closing socket");

	return 0;
}
