#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <error.h>
#include <errno.h>
#include <stdio.h>

int main(void)
{
	char buf[32];
	int sock_fd;
	int rlen;
	int ret;
	struct sockaddr_in host;

	sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock_fd == -1)
		error(1, errno, "unable to create socket");

	host.sin_family = AF_INET;
	host.sin_port = htons(3000);
	host.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = connect(sock_fd, (struct sockaddr *)&host, sizeof(host));
	if (ret == -1)
		error(1, errno, "unable to connect to host");

	while (1) {
		ret = scanf("%s", buf);
	        if (ret == -1)
			break;

		ret = send(sock_fd, buf, strlen(buf), 0);
		if (ret == -1)
			error(1, errno, "unable to send message");
	}
	ret = send(sock_fd, NULL, 0, 0);
	if (ret == -1)
		error(1, errno, "unable to send end signal");

	ret = shutdown(sock_fd, SHUT_RDWR) || close(sock_fd);
	if (ret == 1)
		error(1, errno, "error closing socket");

	return 0;
}
