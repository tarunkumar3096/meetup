#include <stdio.h>
#include <ctype.h>
#include <error.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>

int main(void)
{
	int ret;
	int sv[2];
	char buf;
 
	ret = socketpair(AF_UNIX, SOCK_DGRAM, 0, sv);
	if (ret == -1)
		error(1, errno, "error creating socketpair");

	if (!fork()) {

		read(sv[0], &buf, 1);
		printf("child: read '%c'\n", buf);
		buf = toupper(buf);
		write(sv[0], &buf, 1);
		printf("child: sent '%c'\n", buf);

	} else {

		write(sv[1], "b", 1);
		printf("parent: sent 'b'\n");
		read(sv[1], &buf, 1);
		printf("parent: read '%c'\n", buf);
		wait(NULL);

	}

	return 0;
}
