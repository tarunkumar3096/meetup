#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>

#define SOCK_FILE "unixSocket"

int main(void)
{
	if (!fork()) {

		char buf[128];
		int sock_fd;
		int ret;
		int rlen;
		int optval = 1;
		struct sockaddr_un me = {AF_UNIX, SOCK_FILE};
		FILE *fp;

		sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
		if (sock_fd == -1)
			error(1, errno, "unable to create socket");

		unlink(SOCK_FILE);
		ret = bind(sock_fd, (struct sockaddr *)&me, sizeof(me));
		if (ret == -1)
			error(1, errno, "unable to bind socket to host");
	
		rlen = recv(sock_fd, buf, sizeof(buf), 0);
		if (rlen == -1)
			error(1, errno, "unable to receive from client");
		buf[rlen] = 0;

		fp = fopen("child", "w+");
		fputs(buf, fp);
		fclose(fp);

		ret = close(sock_fd);
		if (ret == -1)
			error(1, errno, "unable to close child socket");

		exit(EXIT_SUCCESS);
		
	} else {

		char buf[128];
		int sock_fd;
		int rlen;
		int ret;
		struct sockaddr_un host = {AF_UNIX, SOCK_FILE};
		FILE *fp;

		sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
		if (sock_fd == -1)
			error(1, errno, "unable to create socket");

		sleep(1);
		ret = connect(sock_fd, (struct sockaddr *)&host, sizeof(host));
		if (ret == -1)
			error(1, errno, "unable to connect to host");

		fp = fopen("parent", "r");
		fgets(buf, sizeof(buf), fp);
		fclose(fp);

		ret = send(sock_fd, buf, strlen(buf), 0);
		if (ret == -1)
			error(1, errno, "unable to send message");
 
		ret = shutdown(sock_fd, SHUT_RDWR) || close(sock_fd);
		if (ret == 1)
			error(1, errno, "unable to close parent socket");
		wait(NULL);
	}

	return 0;
}
