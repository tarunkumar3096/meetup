#include <sys/stat.h>
#include <error.h>
#include <errno.h>
#include <stdio.h>
int main(int argc, char* argv[])
{
	if (argc !=  2)
		error(1,0,"Usage:chmod <filename>");
	char *filename = argv[1];
	int ret;
	int opt;
	printf("Select an option:\n1.User r/w/x\n2.Group r/w/x\n3.Others r/w/x\n");
	scanf("%d",&opt);
	switch(opt) {
	case 1:
		ret = chmod(filename,S_IRUSR|S_IWUSR|S_IXUSR);
		break;
	case 2:
		ret = chmod(filename,S_IRGRP|S_IWGRP|S_IXGRP);
		break;
	case 3:
		ret = chmod(filename,S_IROTH|S_IWOTH|S_IXOTH);
		break;
	}
	if (ret == -1)
		error(1,errno,"Unable to change file permissions");
	return 0;
}
