#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <stdio.h>
#include <grp.h>
int main(int argc, char* argv[])
{
	if (argc !=  2)
		error(1,0,"Usage:chown <filename>");
	char *filename = argv[1];
	int ret;
	int fd;
	struct stat buff;
	struct group *gr;
	gr = getgrnam("guest");
	if(!gr)
		error(1,0,"Invalid group");
	ret = stat(filename,&buff);
	if (ret == -1)
		error(1,errno,"Cannot stat");
	fd = open("Chown_examp.txt",O_RDONLY|O_CREAT,0660);
	if (fd == -1)
		error(1,errno,"Cannot open/create file");
	ret = fchown(fd,buff.st_uid,buff.st_gid);
	if (ret == -1)
		error(1,errno,"Cannot change file ownership");
	return 0;
}
