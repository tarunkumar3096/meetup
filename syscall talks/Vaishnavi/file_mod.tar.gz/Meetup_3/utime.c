#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <stdio.h>
#include <utime.h>
#include <sys/time.h>
int main(int argc, char* argv[])
{
	if (argc !=  2)
		error(1,0,"Usage:utime <filename>");
	char *filename = argv[1];
	int ret;
	int fd;
	struct stat buff;
	struct utimbuf times;
	ret = stat(filename,&buff);
	if (ret == -1)
		error(1,errno,"Cannot stat");
	times.actime = buff.st_atim.tv_sec;
	times.modtime = buff.st_mtim.tv_sec;
	fd = open("time_examp.txt",O_RDONLY|O_CREAT);
	if (fd == -1)
		error(1,errno,"Cannot open/create file");
	ret = utime("time_examp.txt",&times);
	if (ret == -1)
		error(1,errno,"Cannot change file access times");
	return 0;
}
