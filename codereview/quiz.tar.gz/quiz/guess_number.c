#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>

#define SUCCESS 0
#define FAILURE 1
#define INVALID_INPUT -2
#define NO_INPUT -1
#define BUFLEN 16
#define CHANCES 7
#define MIN_VALUE 0
#define MAX_VALUE 100

static int compare_rand_num_and_usr_input(int rand_num, int usr_input)
{
	if (usr_input == rand_num) {
		printf("Hurray! You found the number\n");
	} else if (usr_input > rand_num) {
		printf("Your number is larger\n");
		return FAILURE;
	} else if (usr_input < rand_num) {
		printf("Your number is smaller\n");
		return FAILURE;
	}

	return SUCCESS;
}

static int get_random_number(void)
{
	srand(time(NULL));

	return (rand() % 100);
}

static int read_int(int *intp)
{
	char buf[BUFLEN];
	char *retp;
	char *endptr;
	long input;
	int i = 0;

	printf("Enter your guessed number\n");

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT;

	if (!strcmp(buf, "\n"))
		return INVALID_INPUT;

	__fpurge(stdin);

	while (i != (strlen(buf) - 1)) {
		if (isspace(buf[i]))
			return INVALID_INPUT;
		i++;
	}

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return INVALID_INPUT;
	else if ((input < MIN_VALUE) || (input >= MAX_VALUE))
		return INVALID_INPUT;
	else if (input > INT_MAX)
		return INVALID_INPUT;
	else if (input < INT_MIN)
		return INVALID_INPUT;

	*intp = (int) input;

	return SUCCESS;
}

int main(void)
{
	int rand_num;
	int usr_input;
	int no_of_chances = CHANCES;
	int ret;

	rand_num = get_random_number();

	while (no_of_chances) {
		do {
			ret = read_int(&usr_input);
		} while ((ret == NO_INPUT) || (ret == INVALID_INPUT));
		ret = compare_rand_num_and_usr_input(rand_num, usr_input);
		if (ret == 1)
			no_of_chances--;
		else
			break;
	}
	return SUCCESS;
}
