#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>

#define BUFLEN 8
#define ROWS 3
#define COLUMNS 3
#define CROSSES 'X'
#define NOUGHTS 'O'
#define CROSSES_WIN 1
#define NOUGHTS_WIN 2
#define SUCCESS 0
#define FAILURE -1
#define NO_INPUT -1
#define ASCII_VAL_ZERO '0'
#define ASCII_VAL_NINE '9'
#define INVALID_INPUT -2

static void display_toe(char (*toe)[COLUMNS])
{
	int i;
	int j = 0;

	for (i = 0; i < ROWS; i++) {
		printf(" -----------\n");
		printf("| %c | %c | %c |\n", toe[i][j],
		       toe[i][j + 1], toe[i][j + 2]);
	}
	printf(" -----------\n");
}

static int check_horizontally(char (*toe)[COLUMNS])
{
	int i;
	int j;
	int count_X = 0;
	int count_O = 0;

	for (i = 0; i < ROWS; i++) {
		for (j = 0; j < COLUMNS; j++) {
			if (toe[i][j] == CROSSES)
				count_X++;
			if (toe[i][j] == NOUGHTS)
				count_O++;
		}
		if (count_X == 3)
			return CROSSES_WIN;
		else if (count_O == 3)
			return NOUGHTS_WIN;
		count_X = 0;
		count_O = 0;
	}
	return FAILURE;
}

static int check_vertically(char (*toe)[COLUMNS])
{
	int i;
	int j;
	int count_X = 0;
	int count_O = 0;

	for (j = 0; j < COLUMNS; j++) {
		for (i = 0; i < ROWS; i++) {
			if (toe[i][j] == CROSSES)
				count_X++;
			if (toe[i][j] == NOUGHTS)
				count_O++;
		}
		if (count_X == 3)
			return 1;
		else if (count_O == 3)
			return 2;
		count_X = 0;
		count_O = 0;
	}
	return FAILURE;
}

static int check_diagonally(char (*toe)[COLUMNS])
{
	int i;
	int j;
	int count_X = 0;
	int count_O = 0;

	for (j = 0; j < COLUMNS; j++) {
		for (i = 0; i == j; i++) {
			if (toe[i][j] == CROSSES)
				count_X++;
			if (toe[i][j] == NOUGHTS)
				count_O++;
		}
		if (count_X == 3)
			return CROSSES_WIN;
		else if (count_O == 3)
			return NOUGHTS_WIN;
		count_X = 0;
		count_O = 0;
	}
	for (i = 2, j = 0; ((i >= 0) && (j < COLUMNS)); i--, j++) {
		if (toe[i][j] == CROSSES)
			count_X++;
		if (toe[i][j] == NOUGHTS)
			count_O++;
	}
	if (count_X == 3)
		return CROSSES_WIN;
	else if (count_O == 3)
		return NOUGHTS_WIN;
	return FAILURE;
}

static int check_for_winner(char (*toe)[COLUMNS])
{
	int ret;

	ret = check_horizontally(toe);
	if (ret == 1) {
		printf("Player_1 OWN\n");
		return SUCCESS;
	} else if (ret == 2) {
		printf("Player_2 OWN\n");
		return SUCCESS;
	}

	ret = check_vertically(toe);
	if (ret == 1) {
		printf("Player_1 WON\n");
		return SUCCESS;
	} else if (ret == 2) {
		printf("Player_2 WON\n");
		return SUCCESS;
	}

	ret = check_diagonally(toe);
	if (ret == 1) {
		printf("Player_1 WON\n");
		return SUCCESS;
	} else if (ret == 2) {
		printf("Player_2 WON\n");
		return SUCCESS;
	}
	return 1;
}

static int get_position(int *x)
{
	char buf[BUFLEN];
	char *retp;
	int i = 0;

	printf("Enter position between 1-9\n");

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT;

	__fpurge(stdin);

	if ((strlen(buf) - 1) != 1) {
		printf("Please enter Single digit\n");
		return INVALID_INPUT;
	}

	if (!((buf[i] >= ASCII_VAL_ZERO) && (buf[i] <= ASCII_VAL_NINE))) {
		printf("Enter valid Input\n");
		return INVALID_INPUT;
	}

	*x = atoi(buf);

	return SUCCESS;
}

static int validate_pos(char (*toe)[COLUMNS], int pos)
{
	if (toe[(int) (pos / ROWS)][(pos % ROWS) - 1] != ' ')
		return FAILURE;
	return SUCCESS;
}

static void insert_options(char (*toe)[COLUMNS],
			   int row, int column, char symbol)
{
	if (symbol == CROSSES)
		toe[row][column] = CROSSES;
	else
		toe[row][column] = NOUGHTS;
}

static void get_row_and_column(int *row, int *column, int pos)
{
	*row = (int) (pos / ROWS);
	*column = (pos % ROWS) - 1;
}

static int check_for_emptyspace(char (*toe)[COLUMNS])
{
	int i;
	int j;
	int count = 0;

	for (i = 0; i < ROWS; i++) {
		for (j = 0; j < COLUMNS; j++) {
			if (toe[i][j] == ' ')
				count++;
		}
	}
	if (count >= 1)
		return SUCCESS;
	return FAILURE;
}

static int player(char (*toe)[COLUMNS], char mark)
{
	int row;
	int column;
	int ret;
	int temp;
	int pos;

	printf("%c's turn\n", mark);
	do {
		ret = get_position(&pos);
		if (ret == SUCCESS) {
			temp = validate_pos(toe, pos);
			if (temp == FAILURE)
				printf("Enter Valid Position\n");
		}
	} while (ret || temp);

	get_row_and_column(&row, &column, pos);

	insert_options(toe, row, column, mark);

	ret = check_for_winner(toe);
	if (ret == 1) {
		printf("No one win's the game\n");
		return 1;
	}

	return SUCCESS;
}

int main(void)
{
	char toe[ROWS][COLUMNS];
	int ret;
	int num = 9;


	memset(toe, ' ', (ROWS * COLUMNS));

	display_toe(toe);

	while (num > 0) {
		ret = check_for_emptyspace(toe);
		if (ret == FAILURE)
			break;
		ret = player(toe, CROSSES); /*PLAYER1 - Crosses */
		display_toe(toe);
		if (ret == SUCCESS)
			break;

		ret = check_for_emptyspace(toe);
		if (ret == FAILURE)
			break;
		ret = player(toe, NOUGHTS); /*PLAYER2 - Noughts */
		display_toe(toe);
		if (ret == SUCCESS)
			break;

		num = num - 2;
	}

	return SUCCESS;
}
