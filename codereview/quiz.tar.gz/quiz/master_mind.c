#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>

#define ANIMAL_COUNT 1
#define LEN 10
#define NUM_LEN 4
#define BUFLEN 16
#define ITERATIONS 100
#define SUCCESS 0
#define INVALID_INPUT -2
#define NO_INPUT -1
#define CHANCES 8
#define ASCII_VAL_ZERO 48
#define ASCII_VAL_NINE 57
#define MAX_BULLS 4

void display_output(int x, int y)
{
	char buf_bull[BUFLEN];
	char buf_cow[BUFLEN];

	if (x == ANIMAL_COUNT)
		strcpy(buf_bull, "bull\0");
	else
		strcpy(buf_bull, "bulls\0");

	if (y == ANIMAL_COUNT)
		strcpy(buf_cow, "cow\0");
	else
		strcpy(buf_cow, "cows\0");

	printf("%d %s, %d %s\n", x, buf_bull, y, buf_cow);
}

int count_cows(char *secret_num, char *usr_input, int len)
{
	int i;
	int j;
	int count = 0;

	for (i = 0; i < len; i++) {
		if (secret_num[i] == usr_input[i]) {
			;
		} else {
			for (j = i + 1; j < len; j++)
				if (secret_num[i] == usr_input[j])
					count++;
		}
	}
	return count;
}

int count_bulls(char *secret_num, char *usr_input, int len)
{
	int i;
	int count = 0;

	for (i = 0; i < len; i++) {
		if (secret_num[i] == usr_input[i])
			count++;
	}
	return count;
}

int read_usr_guess(char *usr_input, int n_len)
{
	char buf[BUFLEN];
	char *retp;
	int i;
	int j;

	printf("Enter your guess\n");
	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT;

	__fpurge(stdin);
	for (i = 0; i < n_len; ) {
		if ((buf[i] >= ASCII_VAL_ZERO) && (buf[i] <= ASCII_VAL_NINE)) {
			i++;
		} else {
			printf("Enter valid Input\n");
			return INVALID_INPUT;
		}
	}
	if ((strlen(buf) - 1) != NUM_LEN) {
		printf("Please enter 4-digits\n");
		return INVALID_INPUT;
	}
	for (i = 0; i < n_len; i++)
		usr_input[i] = buf[i];
	return SUCCESS;
}

void select_secret_num(char *digits, int d_len, char *number, int n_len)
{
	int i;

	for (i = 0; i < n_len; i++)
		number[i] = digits[i];
}

void shuffle_digits(char *digits)
{
	int rand_pos1;
	int rand_pos2;
	char temp;
	int shuffles = ITERATIONS;

	srand(time(NULL));
	while (shuffles) {
		rand_pos1 = (rand() % 10);
		rand_pos2 = (rand() % 10);
		temp = digits[rand_pos1];
		digits[rand_pos1] = digits[rand_pos2];
		digits[rand_pos2] = temp;
		shuffles--;
	}
}

int main(void)
{
	char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	char secret_num[NUM_LEN];
	char usr_input[NUM_LEN];
	int ret;
	int chances = CHANCES;
	int bulls;
	int cows;

	shuffle_digits(digits);
	select_secret_num(digits, LEN, secret_num, NUM_LEN);
	while (chances) {
		do {
			ret = read_usr_guess(usr_input, NUM_LEN);
		} while ((ret == NO_INPUT) || (ret == INVALID_INPUT));

		bulls = count_bulls(secret_num, usr_input, NUM_LEN);
		cows = count_cows(secret_num, usr_input, NUM_LEN);
		display_output(bulls, cows);
		if (bulls == MAX_BULLS)
			break;
		chances--;
	}
	return SUCCESS;
}
