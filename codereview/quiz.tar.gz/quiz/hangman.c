#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>

#define LEN 10
#define NUM_LEN 4
#define FAILURE 1
#define BUFLEN 25
#define SUCCESS 0
#define INVALID_INPUT -2
#define NO_INPUT -1
#define MAX_ATTEMPTS 7
#define HANGMAN_STAGE 7

enum {
	STAGE1,
	STAGE2,
	STAGE3,
	STAGE4,
	STAGE5,
	STAGE6,
	STAGE7
};

void about_the_game(void)
{
	printf("** HANGMAN **\n** Let's play the game **\n");
	printf("** Instructions to play the Game **\n");
	printf("** Guess letters one at a time to solve the word puzzle **\n");
	printf("** Type a letter with your keyboard **\n");
	printf("** Each time wrong letter is entered **\n");
	printf("** Corresponding Hangman picture will be displayed **\n");
	printf("** You can only enter 7 wrong letters **\n");
	printf("** start 1 2 3!!! **\n\n");
}

int game_status(char *word, char *usr_guess)
{
	int i = 0;
	char temp[strlen(word)];

	for (i = 0; i < strlen(word); i++)
		temp[i] = usr_guess[2 * i];
	temp[i] = '\0';
	if (!strcmp(word, temp))
		return SUCCESS;
	else
		return FAILURE;
}

void display_hangman(int miss_count)
{
	char *hangman[] = {
		"\n\n\n-+-\n",
		" |\n |\n |\n-+-\n",
		" +---\n |\n |\n |\n-+-\n",
		" +--+\n |  O\n |\n |\n-+-\n",
		" +--+\n |  O\n |  |\n |\n-+-\n",
		" +--+\n |  O\n | /|\\\n |\n-+-\n",
		" +--+\n |  O\n | /|\\\n | / \\\n-+-\n",
	};
	switch (miss_count >= 0) {
	case STAGE1:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE2:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE3:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE4:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE5:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE6:
		printf("%s\n", hangman[miss_count]);
		break;
	case STAGE7:
		printf("%s\n", hangman[miss_count]);
		break;
	}
}

int char_validation(char *word, char *usr_guess, char letter)
{
	int i;
	int flag = 0;


	for (i = 0; i < strlen(word); i++) {
		if (word[i] == letter) {
			flag = 1;
			usr_guess[(2 * i)] = word[i];
		}
	}
	printf("%s\n", usr_guess);
	return flag;
}

void display_blank_word(char *usr_guess, int len)
{
	int i;

	for (i = 0; i < (2 * len); i = i + 2) {
		usr_guess[i] = '_';
		usr_guess[i + 1] = ' ';
	}
	usr_guess[i] = '\0';
	printf("%s\n\n", usr_guess);
}

int read_usr_guess(char *character)
{
	char buf[BUFLEN];
	char *retp;
	int i = 0;

	printf("Enter your guess\n");
	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT;
	__fpurge(stdin);
	if ((strlen(buf) - 1) != 1) {
		printf("Enter Valid Input\n");
		return INVALID_INPUT;
	}
	if ((buf[i] >= 'A') && (buf[i] <= 'Z')) {
		buf[i] = tolower(buf[i]);
	} else if ((buf[i] >= 'a') && (buf[i] <= 'z')) {
		;
	} else {
		printf("Enter valid Character\n");
		return INVALID_INPUT;
	}
	*character = buf[i];
	return SUCCESS;
}

void get_random_word(char **words, char *word)
{
	srand(time(NULL));
	strcpy(word,  words[rand() % 4]);
}

int main(void)
{
	char *word_library[] = {"go", "portfolio", "english", "animalfarm"};
	char word[BUFLEN];
	char usr_guess[BUFLEN];
	int ret;
	int miss_count = 0;
	int chances = MAX_ATTEMPTS;
	char character;

	about_the_game();
	get_random_word(word_library, word);
	display_blank_word(usr_guess, strlen(word));
	while (chances) {
		do {
			ret = read_usr_guess(&character);
		} while ((ret == NO_INPUT) || (ret == INVALID_INPUT));
		ret = char_validation(word, usr_guess, character);
		if (!ret) {
			chances--;
			display_hangman(miss_count);
			miss_count += 1;
			if (miss_count == MAX_ATTEMPTS) {
				printf("You ran out of chances!!!\n");
				printf("Word: %s\n", word);
				break;
			}
		}
		ret = game_status(word, usr_guess);
		if (ret == FAILURE) {
			;
		} else {
			printf("You found the Word!!!\n");
			break;
		}
	}
	return 0;
}
