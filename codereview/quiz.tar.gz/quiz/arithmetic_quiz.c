#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdio_ext.h>

#define BUFLEN 16
#define LEN 2
#define SUCCESS 0
#define INVALID_INPUT -2
#define NO_INPUT -1
#define CHANCES 20

void validate_usr_output(int actual_output, int usr_input, int *score)
{
	if (usr_input == actual_output) {
		printf("Correct!\n");
		*score = *score + 1;
	} else {
		printf("Wrong!\n");
	}
}

int read_int(int *intp)
{
	char buf[BUFLEN];
	char *retp;
	char *endptr;
	long input;
	int i = 0;

	printf("Enter your  choice number\n");

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT;

	if (!strcmp(buf, "\n"))
		return INVALID_INPUT;

	__fpurge(stdin);

	while (i != (strlen(buf) - 1)) {
		if (isspace(buf[i]))
			return INVALID_INPUT;
		i++;
	}

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return INVALID_INPUT;
	else if (input > INT_MAX)
		return INVALID_INPUT;
	else if (input < INT_MIN)
		return INVALID_INPUT;

	*intp = (int) input;

	return SUCCESS;
}

int calculate_output(int rnum1, int rnum2, int op)
{
	char operator[LEN] = {'+', '-'};

	printf("%d %c %d ?\n", rnum1, operator[op], rnum2);

	if (op)
		return (rnum1 - rnum2);

	return (rnum1 + rnum2);
}

void get_random_numbers(int *rnum1, int *rnum2, int *op)
{
	srand(time(NULL));

	*rnum1 = rand() % 100;

	*rnum2 = rand() % 100;

	*op = rand() % 2;
}

int main(void)
{
	int num1;
	int num2;
	int op;
	int score = 0;
	int output;
	int ret;
	int chances =  CHANCES;
	int usr_input;

	while (chances) {

		get_random_numbers(&num1, &num2, &op);

		output = calculate_output(num1, num2, op);

		do {
			ret = read_int(&usr_input);

		} while ((ret == NO_INPUT) || (ret == INVALID_INPUT));

		validate_usr_output(output, usr_input, &score);

		chances--;
	}

	printf("Your Score is %d/20\n", score);

	return SUCCESS;
}
