#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <ctype.h>


#define SHUFFLE_TIME 100
#define LENGTH_OF_NUMBER 4
#define ITERATION 4
#define FAILURE 1
#define SUCCESS 0
#define INPUT_SIZE 6

int flag;

static bool validate_input(char *input, int len)
{
	char temp[len];
	int i = 0;

	strcpy(temp, input);

	if (len > 6)
		return false;

	for (i = 0; i < 4; i++) {
		if (!isdigit(temp[i]))
			return false;
	}
	return true;
}


static void shuffle(char buffer[], int length)
{
	char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	int i = 0;
	char temp;
	int index_1 = 0;
	int index_2 = 0;

	srand(time(NULL));
	for (i = 0; i < SHUFFLE_TIME; i++) {
		index_1 = rand() % 10;
		index_2 = rand() % 10;
		temp = digits[index_1];
		digits[index_1] = digits[index_2];
		digits[index_2] = temp;
	}
	strncpy(buffer, digits, length);
	buffer[length] = '\0';
	printf("string %s\n", buffer);
}

static int user_input(char buffer[], int length)
{
	char input_number[6];

	memset(input_number, 0, INPUT_SIZE);
	printf("Enter your guess:\t");
	fgets(input_number, INPUT_SIZE, stdin);

	if (input_number[5] != '\n') {
		printf("Invalid Input\n");
		flag = FAILURE;
		memset(input_number, 0, INPUT_SIZE);
	} else if ((validate_input(input_number, INPUT_SIZE) == true)
		   && (flag != FAILURE)) {
		strncpy(buffer, input_number, length);
		flag = SUCCESS;
	} else {
		printf("Invalid Input\n");
		flag = FAILURE;
	}


	return 0;
}

static int verify(char *random, char *input, int *check)
{
	char ques[LENGTH_OF_NUMBER];
	char ans[LENGTH_OF_NUMBER];
	int i = 0;
	int j = 0;
	int bull = 0;
	int cow = 0;

	strcpy(ques, random);
	strcpy(ans, input);

	for (i = 0; i < LENGTH_OF_NUMBER; i++) {
		for (j = 0; j <  LENGTH_OF_NUMBER; j++) {
			if (ques[i] == ans[j]) {
				if (i == j)
					bull++;
				else
					cow++;
			}
		}
	}
	*check = bull;

	if ((bull == 1) || (bull == 0))
		printf(" %d bull, %d cows\n", bull, cow);
	else if ((cow == 1)  || (cow == 0))
		printf(" %d bulls, %d cow\n", bull, cow);
	else
		printf("cow : %d\n", cow);
	return 0;
}

int main(void)
{
	char random_array[LENGTH_OF_NUMBER];
	char user_array[LENGTH_OF_NUMBER];
	int check = 0;
	int i = 0;

	shuffle(random_array, LENGTH_OF_NUMBER);

	while (i < ITERATION) {
		user_input(user_array, LENGTH_OF_NUMBER);
		if (flag == SUCCESS) {
			verify(random_array, user_array, &check);
			if (check == ITERATION) {
				printf("correct\n");
				break;
			}
			i++;
		}
		if (flag == FAILURE)
			continue;
	}
	return 0;
}
