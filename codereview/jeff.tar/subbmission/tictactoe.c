#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio_ext.h>

#define X 88
#define O 79
#define MATRIX_SIZE 3
#define PLAYER_1 1
#define PLAYER_2 2
#define LAST_CHANCE 10
#define SUCCESS 0

int flag;


static int validate_input(void)
{
	int temp = -1;

	while (1) {
		scanf("%d", &temp);
		__fpurge(stdin);
		if (temp != -1)
			return temp;
		printf("Invaild data\nEnter again:\t");
		continue;
	}
	return SUCCESS;
}




static bool verify_horizontal(char grid[][MATRIX_SIZE], int player_num)
{
	int var_1 = 0;
	int var_2 = 0;
	int element;

	if (player_num == 1)
		element = X;
	if (player_num == 2)
		element = O;

	for (var_1 = 0; var_1 < MATRIX_SIZE; var_1++) {
		for (var_2 = 0; var_2 < MATRIX_SIZE; var_2++) {
			if ((grid[var_1][var_2] == grid[var_1][var_2 + 1])
			    && (grid[var_1][var_2 + 1] ==
				grid[var_1][var_2 + 2])
			    && (grid[var_1][var_2 + 2] == element)) {
				return true;
			}
		}
	}
	return false;
}

static bool verify_vertical(char grid[][MATRIX_SIZE], int player_num)
{
	int var_1 = 0;
	int var_2 = 0;
	int element;

	if (player_num == 1)
		element = X;
	if (player_num == 2)
		element = O;

	for (var_1 = 0; var_1 < MATRIX_SIZE; var_1++) {
		for (var_2 = 0; var_2 < MATRIX_SIZE; var_2++) {
			if ((grid[var_1][var_2] == grid[var_1 + 1][var_2])
			    && (grid[var_1 + 1][var_2] ==
				grid[var_1 + 2][var_2])
			    && (grid[var_1 + 2][var_2] == element))
				return true;
		}
	}
	return false;
}

static bool verify_diagonal(char grid[][MATRIX_SIZE], int player_num)
{
	int var_1 = 0;
	int var_2 = 0;
	int element;

	if (player_num == 1)
		element = X;
	if (player_num == 2)
		element = O;

	if (grid[var_1][var_2] == grid[var_1 + 1][var_2 + 1] &&
	    grid[var_1 + 1][var_2 + 1] == grid[var_1 + 2][var_2 + 2] &&
	    grid[var_1 + 2][var_2 + 2] == element)
		return true;
	if (grid[var_1][var_2 + 2] == grid[var_1 + 1][var_2 + 1] &&
	    grid[var_1 + 1][var_2 + 1] == grid[var_1 + 2][var_2] &&
	    grid[var_1 + 2][var_2] == element)
		return true;
	return false;
}

static int put_input(int row, int col, char ch, char grid[][MATRIX_SIZE])
{
	if (grid[row][col] != 'X' && grid[row][col] != 'O') {
		grid[row][col] = ch;
		flag = 0;
	} else {
		printf("Entered position not free\n");
		flag = 1;
	}
	return SUCCESS;
}

static int get_input(char grid[][MATRIX_SIZE], int pos, int player_num)
{
	char symbol;

	if (player_num == 1)
		symbol = 'X';
	else
		symbol = 'O';
	switch (pos) {
	case 1:
		put_input(0, 0, symbol, grid);
		break;
	case 2:
		put_input(0, 1, symbol, grid);
		break;
	case 3:
		put_input(0, 2, symbol, grid);
		break;
	case 4:
		put_input(1, 0, symbol, grid);
		break;
	case 5:
		put_input(1, 1, symbol, grid);
		break;
	case 6:
		put_input(1, 2, symbol, grid);
		break;
	case 7:
		put_input(2, 0, symbol, grid);
		break;
	case 8:
		put_input(2, 1, symbol, grid);
		break;
	case 9:
		put_input(2, 2, symbol, grid);
		break;
	default:
		printf("enter valid position\n");
		flag = 1;

		break;
	}
	return SUCCESS;
}



static int print_grid(char grid[][MATRIX_SIZE])
{
	int var_1;
	int var_2;

	for (var_1 = 0; var_1 < MATRIX_SIZE; var_1++) {
		printf("----------\n|");
		for (var_2 = 0; var_2 < MATRIX_SIZE; var_2++)
			printf("%c |", grid[var_1][var_2]);
		printf("\n");
	}
	printf("----------\n");
	return SUCCESS;
}

static int start_game(char grid[][MATRIX_SIZE])
{
	int var_1;
	int var_2;

	for (var_1 = 0; var_1 < MATRIX_SIZE; var_1++) {
		for (var_2 = 0; var_2 < MATRIX_SIZE; var_2++)
			grid[var_1][var_2] = ' ';
	}
	return SUCCESS;
}


int main(void)
{
	int position = 0;
	int player_no = 0;
	int chances = 1;
	char grid_pos[MATRIX_SIZE][MATRIX_SIZE] = {"123", "456", "789"};

	printf("Enter x and o based on the numbers below:\n");
	print_grid(grid_pos);
	start_game(grid_pos);

	while (1) {
		printf("Player 1\nEnter position\n");
		position = validate_input();
		player_no = PLAYER_1;
		get_input(grid_pos, position, player_no);
		print_grid(grid_pos);
		if (flag == 1)
			continue;
		chances++;
		if (((verify_horizontal(grid_pos, player_no) == true) ||
		     verify_vertical(grid_pos, player_no) == true) ||
		    verify_diagonal(grid_pos, player_no) == true) {
			printf("Player 1 wins\n");
			return SUCCESS;
		}
		if (chances == LAST_CHANCE) {
			printf("ITS A TIE\n");
			return SUCCESS;
		}
		while (1) {
			printf("player 2\nEnter position\n");
			position = validate_input();
			player_no = PLAYER_2;
			get_input(grid_pos, position, player_no);
			print_grid(grid_pos);
			if (flag == 1)
				continue;
			chances++;
			if (((verify_horizontal(grid_pos, player_no) == true) ||
			     verify_vertical(grid_pos, player_no) == true) ||
			    verify_diagonal(grid_pos, player_no) == true) {
				printf("Player 2 wins\n");
				return SUCCESS;
			}
			break;
		}
	}
	return SUCCESS;
}
