#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUMBER 7
#define INT_MAX 100
#define INT_MIN 0
#define SUCCESS 0
#define RANDOM_GENERATOR 100

static int read_int(int *intp)
{
	char buf[256];
	char *retp;
	char *endptr;
	long input;
	int i = 0;
	int j = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	while (buf[i]) {
		if (buf[i] != ' ')
			buf[j++] = buf[i];
		i++;
	}
	buf[j] = '\0';

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return -2;

	if (*retp == 10)
		return -1;
	if (input > INT_MAX)
		return -2;

	if (input < INT_MIN)
		return -2;

	*intp = (int) input;

	return SUCCESS;
}

int main(void)
{
	srand(time(NULL));
	int i;
	int random = 0;
	int ret;
	int input;

	random = rand() % RANDOM_GENERATOR;
	for (i = 0; i < NUMBER; i++) {
		printf("Enter your number between 1 to 100\n");
		ret = read_int(&input);

		if (ret == SUCCESS) {
			if (random == input) {
				printf("Hurray! you found the number\n");
				break;
			}
			if (random < input)
				printf("Your number is larger\n");
			if (random > input)
				printf("Your number is smaller\n");
		} else {
			printf("Enter a proper value\n");
			i--;
		}
	}
	return 0;
}
