#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

#define HANGMAN_CH 7
#define CASE_SENSITIVE 32
#define MAX_LENGTH_OF_A_WORD 20
#define MAX_WORDS 7
#define NOT_A_CHARACTER 2

enum status {
	SUCCESS,
	FAILURE,
	REPEATED_LETTER
};

int flag;

static void display_hangman(int chance, char *word)
{
	char *arr[HANGMAN_CH] =  {"-+- ", "\n |\n |\n |\n-+- ",
				  " +---\n |\n |\n |\n-+-",
				  " +--+\n |  0\n |\n |\n-+-",
				  " +--+\n |  0\n |  |\n |\n-+-",
				  " +--+\n |  0\n | /|\\\n |\n-+-",
				  " +--+\n |  0\n | /|\\\n | / \\\n-+-"};

	char *(*ptr)[HANGMAN_CH] = &arr;

	if (chance - 1 == HANGMAN_CH - 1) {
		printf("\nYOU LOSE\n");
		printf("The word is :  %s\n", word);
		printf("**********Game over************");
		flag = 1;
	}
	printf("\n%s\n", (*ptr)[chance - 1]);
}

static int check_alphabet(char *ptr)
{
	if (isalpha(*ptr))
		return SUCCESS;
	ptr++;
	return FAILURE;
}

static int check_word(char *src, char dest)
{
	int var;

	for (var = 0; var < strlen(src); var++) {
		if ((src[var] == dest) || (src[var] == dest + CASE_SENSITIVE))
			return SUCCESS;
	}
	return FAILURE;
}

static void verify_letters(int attempt_count, char *random_word)
{
	char input_buffer[MAX_LENGTH_OF_A_WORD];
	char temp_buffer[MAX_LENGTH_OF_A_WORD];
	int chances;
	char letter;

	memset(temp_buffer, ' ', MAX_LENGTH_OF_A_WORD);
	temp_buffer[MAX_LENGTH_OF_A_WORD - 1] = '\0';
	int index;
	int i = 0;

	while (attempt_count != 0) {
		for (i = 0; i < strlen(random_word); i++)
			printf(" _ ");
		printf("\n");

		if (chances > MAX_WORDS)
			break;

		printf("Guess the letter\n");

		fgets(input_buffer, MAX_LENGTH_OF_A_WORD, stdin);
		if (!check_alphabet(input_buffer)) {
			if (strlen(input_buffer) > NOT_A_CHARACTER) {
				printf("Enter a letter\n");
				continue;
			} else
				letter = *input_buffer;
		} else {
			printf("Enter a letter\n");
			continue;
		}

		if (!(check_word(random_word, letter))) {
			for (i = 0; i < strlen(random_word); i++) {
				if ((random_word[i] == letter) ||
				    (random_word[i] ==
				     letter + CASE_SENSITIVE)) {
					if ((temp_buffer[i] == letter) ||
					    (temp_buffer[i] ==
					     letter + CASE_SENSITIVE)) {
						printf("Letter tried\n");
						printf("Enter again\n");
						attempt_count++;
					} else {
						temp_buffer[i] = letter;
						index++;
					}
				}
			}
			for (i = 0; i < strlen(random_word); i++)
				printf(" %c ", temp_buffer[i]);
			printf("\n");
		} else {
			display_hangman(++chances, random_word);
			attempt_count++;
			if (flag == 1)
				return;
		}
		if (index >= REPEATED_LETTER) {
			for (index; index > 0; index--)
				attempt_count--;
		} else {
			attempt_count--;
		}

		index = 0;
	}
}

static void operation(void)
{
	char *words[50] = {
		"multiverse",
		"flash",
		"timetravel",
		"future",
		"destiny",
		"phenomenal"
	};

	char *random_word;
	int attempt_count;
	int i = 0;

	srand(time(NULL));
	random_word = words[rand() % MAX_WORDS - 1];
	attempt_count = strlen(random_word);

	printf("Enter to Hangman Game\n");
	printf("Length of the word : %d\n", attempt_count);

	verify_letters(attempt_count, random_word);

	if (flag != 1) {
		for (i = 0; i < strlen(random_word); i++)
			printf(" _ ");
		printf("\n");
		printf("**********YOU WON**************\n");
	}
}

int main(void)
{
	operation();
	return 0;
}
