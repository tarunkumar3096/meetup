#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <stdio_ext.h>

#define START 1
#define END_OF_QUES 21
#define TOTAL_QUES 20
#define NO_OF_OPERATORS 2

static int validate_input(void)
{
	int temp = -1;

	while (1) {
		scanf("%d", &temp);
		__fpurge(stdin);
		if (temp != -1)
			return temp;
		printf("Invaild data\nEnter again:\t");
		continue;
	}
	return 0;
}


static int check(int x, int y, char ch)
{
	int output;

	switch (ch) {
	case '+':
		output = x + y;
		break;
	case '-':
		output = x - y;
		break;
	}
	return output;
}

int main(void)
{
	srand(time(NULL));
	char character;
	int output = 0;
	int answer = 0;
	int count = 0;
	char operator[NO_OF_OPERATORS] = {'+', '-'};
	int i = 1;
	int wrong;

	while (1) {
		int random1 = rand() % 100;
		int random2 = rand() % 100;

		character = operator[rand() % NO_OF_OPERATORS];
		if (i == START)
			printf("Arithmetic Quiz\n");

		printf("Question : %d\n", i);

		printf("%d %c %d = ?\n", random1, character, random2);
		answer = validate_input();

		output = check(random1, random2, character);

		printf("The correct Answer %d\n", output);

		if (output == answer) {
			printf("**************correct answer************\n");
			count = count + 1;
		} else {
			printf("**************wrong answer**************\n");
		}
		i++;
		if (i == END_OF_QUES)
			break;
	}
	wrong = TOTAL_QUES - count;
	printf("total correct : %d\n", count);
	printf("total wrong   : %d\n", wrong);
	return 0;
}
