#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <error.h>

#define R_C 3

void draw_grid(char grid_data[][R_C])
{
	int itr1;
	int itr2;

	for (itr1 = 0; itr1 < R_C; itr1++) {
		printf("-------------\n|");
		for (itr2 = 0; itr2 < R_C; itr2++)
			printf(" %c |", grid_data[itr1][itr2]);
		printf("\n");
	}
	printf("-------------\n");

}

int check_horizontal(char grid_data[][R_C])
{
	int itr1;
	int itr2;
	char ele;
	int flag;

	for (itr1 = 0; itr1 < R_C; itr1++) {
		ele = grid_data[itr1][0];
		if (ele == ' ')
			continue;
		flag = 0;
		for (itr2 = 0; itr2 < R_C; itr2++) {
			if (grid_data[itr1][itr2] != ele)
				flag = 1;
		}
		if (flag != 1)
			return 1;
	}
	return 0;
}

int check_vertical(char grid_data[][R_C])
{
	int itr1;
	int itr2;
	char ele;
	int flag;

	for (itr1 = 0; itr1 < R_C; itr1++) {
		ele = grid_data[0][itr1];
		if (ele == ' ')
			continue;
		flag = 0;
		for (itr2 = 0; itr2 < R_C; itr2++) {
			if (grid_data[itr2][itr1] != ele)
				flag = 1;
		}
		if (flag != 1)
			return 1;
	}
	return 0;
}

int check_diagonal(char grid_data[][R_C])
{
	int itr1;
	int itr2;
	int flag = 0;
	char ele;

	for (itr1 = 0; itr1 < R_C; itr1++)
		if (grid_data[itr1][itr1] != grid_data[0][0] ||
		    grid_data[0][0] == ' ')
			flag = 1;
	if (flag != 1)
		return 1;
	flag = 0;
	ele = grid_data[R_C - 1][0];
	for (itr1 = 0, itr2 = R_C - 1; itr1 < R_C; itr1++, itr2--)
		if (grid_data[itr1][itr2] != ele || ele == ' ')
			flag = 1;
	if (flag != 1)
		return 1;
	return 0;
}

int fill_data(char grid_data[][R_C], int position, int player_no)
{
	char ch;
	int x;
	int y;

	if (player_no == 1)
		ch = 'X';
	else
		ch = 'O';
	position--;
	x = position / R_C;
	y = position % R_C;
	if (grid_data[x][y] == ' ') {
		grid_data[x][y] = ch;
	} else {
		printf("Invalid position\n");
		return 1;
	}
	return 0;
}

int play_turn(char grid_data[][R_C], int player_no)
{
	int position;
	char *ret;
	char buff[LINE_MAX];

	printf("Player %d, enter position\n", player_no);
	while (1) {
		ret = fgets(buff, LINE_MAX, stdin);
		if (ret == NULL)
			error(1, 0, "Error reading from stdin");
		if (isdigit(buff[0]) == 0 || buff[1] != '\n') {
			printf("Invalid input.Enter again\n");
			continue;
		} else {
			position = (buff[0] - 48);
			if (fill_data(grid_data, position, player_no) == 1) {
				printf("Enter again\n");
				continue;
			}
			break;
		}
	}
	draw_grid(grid_data);
	if (check_horizontal(grid_data) || check_vertical(grid_data) ||
	    check_diagonal(grid_data)) {
		printf("Player %d wins\n", player_no);
		return 1;
	}
	return 0;
}

int main(void)
{

	char grid_data[R_C][R_C] = {"123", "456", "789"};
	int count = 0;

	printf("The positions are numbered as shown:\n");
	draw_grid(grid_data);
	memset(grid_data, 32, sizeof(grid_data));
	while (1) {
		if (play_turn(grid_data, 1))
			break;
		count++;
		if (count == 5) {
			printf("Its a tie!!\n");
			break;
		}
		if (play_turn(grid_data, 2))
			break;
	}
	return 0;
}
