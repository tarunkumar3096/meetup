#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#define CHANCES 8
#define SHUFFLE 100
#define INDICES (rand() % 10)
#define LAST 4

int read_int(int *intp)
{
	char buf[6];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return -2;
	if (strlen(retp) != 5)
		return -2;
	*intp = (int) input;

	return 0;
}

void gen_num(char digits[])
{
	char swap;
	int index1;
	int index2;
	int itr = 0;

	while (itr < SHUFFLE) {
		index1 = INDICES;
		index2 = INDICES;
		swap = digits[index1];
		digits[index1] = digits[index2];
		digits[index2] = swap;
		itr++;
	}
}

int count_bullcow(char digits[], int user_input)
{
	int cows = 0;
	int bulls = 0;
	int itr = LAST - 1;
	int itr2;
	int user[LAST];

	while (user_input) {
		user[itr] = user_input % 10;
		user_input = user_input / 10;
		itr--;
	}
	for (itr = 0; itr < LAST; itr++) {
		for (itr2 = 0; itr2 < LAST; itr2++) {
			if (user[itr] == (digits[itr2]-48)) {
				if (itr == itr2)
					bulls++;
				else
					cows++;
			}
		}
	}
	printf("%d bulls, %d cows\n", bulls, cows);
	if (bulls == 4) {
		printf("You found the number!!\n");
		return 1;
	}
	return 0;
}

int main(void)
{
	int user_input;
	int itr = 0;
	char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

	srand(time(NULL));
	gen_num(digits);
	while (itr < CHANCES) {
		printf("Enter your guess: ");
		if (read_int(&user_input) < 0) {
			printf("Invalid input\n");
			itr--;
		}
		if (count_bullcow(digits, user_input) == 1)
			return 0;
		itr++;
	}
	printf("Sorry!You failed to guess the number\n");
	printf("Number is:");
	for (itr = 0; itr < LAST; itr++)
		printf("%c", digits[itr]);
	printf("\n");
	return 0;
}
