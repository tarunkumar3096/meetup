#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

#define RANGE 100
#define CHANCES 7

void clear_buff(void)
{
	int c;

	while ((c = getchar()) != '\n' && c != EOF)
		;
}

int read_int(int *intp)
{
	char buf[16];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' &&  *endptr != ' ')
		return -2;
	if (*endptr == ' ')
		input = (input * 10) + strtol(endptr+1, &endptr, 10);
	if (input > INT_MAX)
		return -2;
	if (input < INT_MIN || input < 0)
		return -2;

	*intp = (int) input;
	return 0;
}

int main(void)
{
	int rand_num;
	int itr;
	int user_in;
	int chk;

	srand(time(NULL));
	rand_num = rand() % RANGE;
	for (itr = 0; itr < CHANCES; itr++) {
		printf("\nEnter your number:");
		chk = read_int(&user_in);
		if (chk) {
			printf("Please enter a valid input:\n");
			clear_buff();
			itr--;

		} else {
			if (user_in < rand_num) {
				printf("Your number is smaller.\n");
				continue;
			} else if (user_in > rand_num)
				printf("Your number is greater.\n");
			else if (user_in == rand_num) {
				printf("Hurray!You found the number! :)\n");
				return 0;
			}

		}
	}
	printf("Sorry! You failed to find the number :(\n");
	return 0;
}
