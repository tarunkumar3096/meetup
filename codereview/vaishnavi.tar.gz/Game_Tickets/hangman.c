#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <error.h>

#define WORDS 20
#define FINALSTAGE 7
#define SPACEASCII 32
#define FILENAME "Wordlist.txt"

void gen_random_word(char word2find[])
{
	int word_no;
	FILE *fp;

	fp = fopen(FILENAME, "r");
	if (fp == NULL)
		error(1, 0, "Error opening the file\n");
	word_no = (rand() % WORDS) + 1;
	while (word_no) {
		fgets(word2find, LINE_MAX, fp);
		word_no--;
	}
	fclose(fp);
}

void print_blank(int length)
{
	int itr;

	for (itr = 1; itr < length; itr++)
		printf("_ ");
	printf("\n\n");
}

void print_user_status(char user_status[], int blanks)
{
	int itr = 0;

	printf("\n");
	while (user_status[itr] != '\0') {
		printf("%c ", user_status[itr]);
		itr++;
	}
	printf("\n");
	print_blank(blanks);
}

int find_match(char user_in, char word2find[], char user_status[])
{
	int itr = 0;
	int flag = 0;

	while (word2find[itr] != '\n') {
		if (toupper(word2find[itr]) == toupper(user_in)) {
			user_status[itr] = toupper(user_in);
			flag = 1;
		}
		itr++;
	}
	user_status[itr] = '\0';
	return flag;
}

void print_hangman(int stage)
{
	const char * const stages[] = {"\n\n\n\n-+-",
				       " |\n |\n |\n-+-",
				       " +---\n |\n |\n |\n-+-",
				       " +--+\n |  O\n |\n |\n-+-",
				       " +--+\n |  O\n |  |\n |\n-+-",
				       " +--+\n |  O\n | /|\\\n |\n-+-",
				       " +--+\n |  O\n | /|\\\n | / \\\n-+-"};
	printf("%s\n", stages[stage]);
}

char get_input(void)
{
	char user_in;
	char buff[LINE_MAX];
	char *ret;

	while (1) {
		printf("Enter a letter:\n");
		ret = fgets(buff, LINE_MAX, stdin);
		if (ret == NULL)
			error(1, 0, "Error reading from stdin");
		if (isalpha(buff[0]) == 0 || buff[1] != '\n') {
			printf("Invalid input\n");
			continue;
		}
		user_in = buff[0];
		break;
	}
	return user_in;
}

int main(void)
{

	char word2find[LINE_MAX];
	char user_status[LINE_MAX];
	char user_in;
	int blanks;
	int stage = 0;

	srand(time(NULL));
	gen_random_word(word2find);
	blanks = strlen(word2find);
	memset(user_status, SPACEASCII, blanks);
	print_blank(blanks);
	while (1) {
		if (stage == FINALSTAGE) {
			printf("Game over!! Word is: %s\n", word2find);
			break;
		}
		if (strncasecmp(user_status, word2find, (blanks - 1)) == 0) {
			printf("Congrats!!You found the word!!\n");
			break;
		}
		user_in = get_input();
		if (find_match(user_in, word2find, user_status) == 0) {
			print_hangman(stage);
			stage++;
		}
		print_user_status(user_status, blanks);
	}
	return 0;
}
