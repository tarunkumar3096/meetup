#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define NO_OP 2
#define TOTAL 20
#define GEN_NUM (rand() % 100)

int read_int(int *intp)
{
	char buf[16];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' &&  *endptr != ' ')
		return -2;
	if (*endptr == ' ')
		input = (input * 10) + strtol(endptr+1, &endptr, 10);
	if (input > INT_MAX)
		return -2;
	if (input < INT_MIN)
		return -2;

	*intp = (int) input;
	return 0;
}

int calculate(int o1, int o2, char op)
{
	switch (op) {
	case '+':
		return (o1 + o2);
	case '-':
		return (o1 - o2);
	}
}

int main(void)
{
	int oper1;
	int oper2;
	char op;
	int result;
	int user_resp;
	int score;
	int itr = 0;
	char operators[] = {'+', '-'};

	srand(time(NULL));
	while (itr < TOTAL) {
		oper1 = GEN_NUM;
		oper2 = GEN_NUM;
		op = operators[rand() % NO_OP];
		result = calculate(oper1, oper2, op);
		printf("%d %c %d ? ", oper1, op, oper2);
		while (1) {
			if (read_int(&user_resp) < 0) {
				printf("Enter valid input\n");
				continue;
			}
			break;
		}
		if (user_resp == result) {
			printf("Correct!\n");
			score++;
		} else
			printf("Wrong!\n");
		itr++;
	}
	printf("Your score is %d/20\n", score);
	return 0;
}
