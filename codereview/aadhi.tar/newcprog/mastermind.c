#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define SUCCESS 0
#define FAILURE -1
#define NO_INPUT -2
#define UNIQUE_INPUT -3
#define RAND_NO_SIZE 4
#define BUF_SIZE 6
#define CHANCE 8
#define SHUFFLE_MAX 100

static int get_user_input(char *user_input)
{
	char *retp;
	char *endptr;
	long input;
	int i;
	int j;

	printf("enter 4digit number: ");
	retp = fgets(user_input, BUF_SIZE, stdin);
	if (retp == NULL || *retp == '\n')
		return NO_INPUT;
	if (user_input[strlen(user_input) - 1] != '\n')
		while (getchar() != '\n')
			;
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || user_input[0] == ' '
	    || user_input[RAND_NO_SIZE] != '\n')
		return FAILURE;
	for (i = 0; i < RAND_NO_SIZE - 1; i++) {
		for (j = i + 1; j < RAND_NO_SIZE; j++) {
			if (user_input[i] == user_input[j])
				return UNIQUE_INPUT;
		}
	}

	return SUCCESS;
}

static void random_generator(char *random_array, int size)
{
	char digits[] = {'0', '1', '2', '3', '4',
			 '5', '6', '7', '8', '9', '\0'};
	int i;
	int j;
	int shuffle = SHUFFLE_MAX;
	char temp;

	srand(time(NULL));
	while (shuffle) {
		i = rand() % strlen(digits);
		j = rand() % strlen(digits);
		temp = digits[i];
		digits[i] = digits[j];
		digits[j] = temp;
		shuffle--;
	}
	memset(random_array, 0, size);
	strncpy(random_array, digits, RAND_NO_SIZE);
}

static int bull_count(char *random_array, char *user_array)
{
	int i;
	int count = 0;

	for (i = 0; i < RAND_NO_SIZE; i++)
		if (random_array[i] == user_array[i])
			count++;

	return count;
}

static int cow_count(char *random_array, char *user_array)
{
	int i;
	int j;
	int count = 0;

	for (i = 0; i < RAND_NO_SIZE; i++)
		for (j = 0; j < RAND_NO_SIZE; j++)
			if (user_array[i] == random_array[j]) {
				if (i == j)
					continue;
				count++;
				break;
			}

	return count;
}

static void error_display(int num)
{
	if (num == NO_INPUT)
		printf("Error: no inputs\n");
	else if (num == FAILURE)
		printf("Error: invalid input\n");
	else if (num == UNIQUE_INPUT)
		printf("Error: give only unique numbers\n");
}

int main(void)
{
	char random_array[RAND_NO_SIZE + 1];
	char user_array[BUF_SIZE];
	int bull;
	int cow;
	int count;
	int ret;

	random_generator(random_array, sizeof(random_array)+1);
	for (count = 0; count < CHANCE; count++) {
		while (1) {
			ret = get_user_input(user_array);
			if (ret == SUCCESS)
				break;
			error_display(ret);
		}
		bull = bull_count(random_array, user_array);
		if (bull == RAND_NO_SIZE) {
			printf("you found the answer\n");
			break;
		}
		cow = cow_count(random_array, user_array);
		printf("cow = %d, bull = %d\n", cow, bull);
	}
	return SUCCESS;
}
