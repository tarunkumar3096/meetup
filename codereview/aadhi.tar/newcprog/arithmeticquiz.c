#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define CHANCE 20
#define RANDOM_MAX 100
#define SIZE 16
#define FAILURE -1
#define NO_INPUT -2
#define SUCCESS 0

static int get_user_input(int *user_input)
{
	char buf[SIZE];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL || *retp == '\n')
		return NO_INPUT;
	if (buf[strlen(buf) - 1] != '\n')
		while (getchar() != '\n')
			;
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || input > INT_MAX
	    || input < INT_MIN || buf[0] == ' ')
		return FAILURE;
	*user_input = (int) input;
	return SUCCESS;
}

static void error_display(int num)
{
	if (num == NO_INPUT)
		printf("Error: no inputs\n");
	else if (num == FAILURE)
		printf("Error: invalid input\n");
}

static int operation(char operator, int op1, int op2)
{
	if (operator == '+')
		return op1 + op2;
	return op1 - op2;
}

static int compare(int user_guess, int result)
{
	if (user_guess == result) {
		printf("correct!\n");
		return SUCCESS;
	}
	printf("wrong!\n");
	return FAILURE;
}

int main(void)
{
	char op1;
	char op2;
	int index;
	int user_guess;
	int result;
	int sum = 0;
	int i;
	char operator[] = {'+', '-'};

	srand(time(NULL));

	for (i = 0; i < CHANCE; i++) {
		op1 = rand() % RANDOM_MAX;
		op2 = rand() % RANDOM_MAX;
		index = rand() % 2;

		while (1) {
			printf("%d  %c  %d  ?  ", op1, operator[index], op2);
			result = get_user_input(&user_guess);
			if (result == SUCCESS)
				break;
			error_display(result);
		}

		result = operation(operator[index], op1, op2);
		if (compare(user_guess, result) == SUCCESS)
			sum++;
	}
	printf("your score is %d/%d\n", sum, CHANCE);
	return 0;
}
