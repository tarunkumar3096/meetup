#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define MAX 100
#define MIN 0
#define SIZE 16
#define NO_INPUT -3
#define INVALID_INPUT -2
#define FAILURE -1
#define SUCCESS 0
#define CHANCE 7

static int get_user_input(int *user_input)
{
	char buf[SIZE];
	char *retp;
	char *endptr;
	long input;

	printf("enter the value between 0-99: ");
	retp = fgets(buf, SIZE, stdin);
	if (retp == NULL || *retp == '\n')
		return NO_INPUT;
	if (buf[strlen(buf) - 1] != '\n')
		while (getchar() != '\n')
			;
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || buf[0] == ' ')
		return INVALID_INPUT;
	if (input >= MAX || input < MIN)
		return FAILURE;
	*user_input = (int) input;
	return SUCCESS;
}

static int compare(int secrete_no, int number)
{
	int flag = 0;

	if (number < secrete_no) {
		printf("your number is smaller\n");
	} else if (number > secrete_no) {
		printf("your number is larger\n");
	} else if (number == secrete_no) {
		printf("you found the number\n");
		flag = 1;
	}
	return flag;
}

static void error_display(int num)
{
	if (num == NO_INPUT)
		printf("Error: no inputs\n");
	else if (num == INVALID_INPUT)
		printf("Error: invalid input\n");
	else if (num == FAILURE)
		printf("Error: input out of range\n");
}

int main(void)
{
	int secrete_no;
	int chance;
	int user_input;
	int flag;
	int num;

	srand(time(NULL));
	secrete_no = rand() % MAX;
	for (chance = 0; chance < CHANCE; chance++) {
		while (1) {
			num = get_user_input(&user_input);
			if (num == SUCCESS)
				break;
			error_display(num);
		}
		flag = compare(secrete_no, user_input);
		if (flag == 1)
			break;
	}
	return SUCCESS;
}
