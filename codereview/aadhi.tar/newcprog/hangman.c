#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#define SUCCESS 0
#define FAILURE -1
#define CHANCE 7
#define SIZE 3
#define WORD_COUNT 3

static void print_hangman(int failed_chance)
{
	switch (failed_chance) {
	case 1:
		printf("-+-\n");
		break;
	case 2:
		printf(" |\n |\n |\n-+-\n");
		break;
	case 3:
		printf(" +--+\n |\n |\n |\n-+-\n");
		break;
	case 4:
		printf(" +--+\n |  O\n |\n |\n-+-\n");
		break;
	case 5:
		printf(" +--+\n |  O\n |  |\n |\n-+-\n");
		break;
	case 6:
		printf(" +--+\n |  O\n | /|\\\n |\n-+-\n");
		break;
	case 7:
		printf(" +--+\n |  O\n | /|\\\n | / \\\n-+-\n");
		break;
	}
}

static void initialise(char *arr)
{
	int count;

	for (count = 0; count < sizeof(arr); count++)
		arr[count] = '_';
	arr[count] = '\0';
}

static void get_input(char *user_guess)
{
	char buf[SIZE];
	char *retp;

	while (1) {
		printf("enter the letter: ");
		retp = fgets(buf, sizeof(buf), stdin);
		if (retp == NULL || *retp == '\n') {
			printf("Error: no input\n");
			continue;
		}
		if (buf[strlen(buf) - 1] != '\n') {
			while (getchar() != '\n')
				;
			printf("invalid input\n");
			continue;
		}
		*user_guess = buf[0];
		if (isalpha(*user_guess))
			break;
		printf("Error: enter only alphabets\n");
	}
}

static int check_win(char *arr1)
{
	int count;

	for (count = 0; count < strlen(arr1); count++)
		if (arr1[count] == '_')
			return FAILURE;
	return SUCCESS;
}

static int check_matching(char user_guess, char **name_list,
			  char *arr, int random_no)
{
	int count;
	int flag = 0;

	for (count = 0; count < strlen(name_list[random_no]); count++) {
		if (tolower(user_guess) ==
		    tolower(name_list[random_no][count])) {
			arr[count] = name_list[random_no][count];
			flag = 1;
		}
	}
	if (flag == 1)
		return SUCCESS;
	return FAILURE;
}

int main(void)
{
	int failed = 0;
	char user_guess;
	char *name_list[WORD_COUNT] = {"tarun", "vinoth", "suresh"};
	int random_no;

	srand(time(NULL));
	random_no = rand() % WORD_COUNT;

	char arr[strlen(name_list[random_no])];

	initialise(arr);
	while (1) {
		get_input(&user_guess);
		if (check_matching(user_guess, name_list, arr, random_no)
		    == FAILURE)
			failed++;
		if (failed == CHANCE)
			break;
		printf("%s\n", arr);
		if ((check_win(arr)) == SUCCESS) {
			printf("you found the answer\n");
			break;
		}
		print_hangman(failed);
	}
	return SUCCESS;
}
