#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 9
#define MIN 1
#define SUCCESS 0
#define FAILURE -1
#define NO_INPUT -2
#define INVALID_INPUT -3
#define SIZE 3
#define BUF_SIZE 16

static int read_int(int *intp, char symbol)
{
	char buf[BUF_SIZE];
	char *retp;
	char *endptr;
	long input;

	printf("Player %c Turn : ", symbol);
	retp = fgets(buf, BUF_SIZE, stdin);
	if (retp == NULL || *retp == '\n')
		return NO_INPUT;
	if (buf[strlen(buf) - 1] != '\n')
		while (getchar() != '\n')
			;
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || buf[0] == ' ')
		return INVALID_INPUT;
	if (input > MAX || input < MIN)
		return FAILURE;
	*intp = (int) input;
	return SUCCESS;
}

static void initialise(char ref_grid[SIZE][SIZE],
		       char main_grid[SIZE][SIZE])
{
	int i;
	int j;
	char count = '1';

	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			ref_grid[i][j] = count;
			count++;
		}
	}
	for (i = 0; i < SIZE; i++)
		for (j = 0; j < SIZE; j++)
			main_grid[i][j] = '\0';
}

static int mark(char ref_grid[SIZE][SIZE], char main_grid[SIZE][SIZE],
		int user_input, char symbol)
{
	int i;
	int j;

	for (i = 0; i < SIZE; i++)
		for (j = 0; j < SIZE; j++) {
			if (ref_grid[i][j] == user_input + '0') {
				main_grid[i][j] = symbol;
				ref_grid[i][j] = '\0';
				return SUCCESS;
			}
		}
	printf("invalid input\n");
	return FAILURE;
}

static void print(char ref_grid[SIZE][SIZE])
{
	int i;
	int j;

	printf(" -----------\n");
	for (i = 0; i < SIZE; i++) {
		printf("|");
		for (j = 0; j < SIZE; j++) {
			if (ref_grid[i][j] == '\0')
				printf("   |");
			else
				printf(" %c |", ref_grid[i][j]);
		}
		printf("\n");
		printf(" -----------\n");
	}
}

static int horizontal_check(char ref_grid[SIZE][SIZE])
{
	int i;
	int j;
	int count = 0;
	int count1 = 0;

	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			if (ref_grid[i][j] == 'X')
				count++;
			if (ref_grid[i][j] == 'O')
				count1++;
		}
		if (count == SIZE || count1 == SIZE)
			return SUCCESS;
		count = 0;
		count1 = 0;
	}
	return FAILURE;
}

static int vertical_check(char ref_grid[SIZE][SIZE])
{
	int i;
	int j = 0;
	int count = 0;
	int count1 = 0;

	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			if (ref_grid[j][i] == 'X')
				count++;
			if (ref_grid[j][i] == 'O')
				count1++;
		}
		if (count == SIZE || count1 == SIZE)
			return SUCCESS;
		count = 0;
		count1 = 0;
	}
	return FAILURE;
}

static int diagonal_check(char ref_grid[SIZE][SIZE])
{
	int i;
	int j;
	int count1 = 0;
	int count2 = 0;
	int count3 = 0;
	int count4 = 0;

	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			if (i == j && ref_grid[i][j] == 'O')
				count1++;
			if ((i+j) == (SIZE-1) && ref_grid[i][j] == 'O')
				count2++;
			if (i == j && ref_grid[i][j] == 'X')
				count3++;
			if ((i+j) == (SIZE-1) && ref_grid[i][j] == 'X')
				count4++;
		}
	}
	if (count1 == SIZE || count2 == SIZE ||
	    count3 == SIZE || count4 == SIZE)
		return SUCCESS;
	return FAILURE;
}

static void error_display(int num)
{
	if (num == NO_INPUT)
		printf("Error: no inputs\n");
	else if (num == INVALID_INPUT)
		printf("Error: invalid input\n");
	else if (num == FAILURE)
		printf("Error: input out of range\n");
}

static void change_symbol(char *symbol)
{
	if (*symbol == 'X')
		*symbol = 'O';
	else
		*symbol = 'X';
}

int main(void)
{
	char ref_grid[SIZE][SIZE];
	char main_grid[SIZE][SIZE];
	int count = MAX;
	int user_input;
	int number;
	char symbol = 'X';

	initialise(ref_grid, main_grid);
	print(ref_grid);
	while (count) {
		while (1) {
			number = read_int(&user_input, symbol);
			if (number == SUCCESS)
				break;
			error_display(number);
		}
		if ((mark(ref_grid, main_grid, user_input, symbol)) == FAILURE)
			continue;
		print(main_grid);
		if (horizontal_check(main_grid) == SUCCESS) {
			printf("player %c won the match\n", symbol);
			return SUCCESS;
		}
		if (vertical_check(main_grid) == SUCCESS) {
			printf("player %c won the match\n", symbol);
			return SUCCESS;
		}
		if (diagonal_check(main_grid) == SUCCESS) {
			printf("player %c won the match\n", symbol);
			return SUCCESS;
		}
		change_symbol(&symbol);
		count--;
	}
	printf("match draw\n");
	return SUCCESS;
}
