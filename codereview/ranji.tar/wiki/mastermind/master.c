#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define SHUFFLE_COUNT 100
#define CHANCE 20
#define MAX_DIGIT 4
#define MAX_SIZE 50

int bulls;
int cows;

char *generate(void)
{
	srand(time(NULL));

	int i;
	int j;
	int times = SHUFFLE_COUNT;
	static char digits[] = {'0', '1', '2', '3', '4', '5',
				'6', '7', '8', '9'};
	char temp;

	while (times--) {
		i = rand() % 10;
		j = rand() % 10;
		temp = digits[i];
		digits[i] = digits[j];
		digits[j] = temp;
	}
	digits[MAX_DIGIT] = '\0';
	return digits;
}

void check(char *secret_number, char *user_input)
{
	int digit = MAX_DIGIT;
	int i = 0;
	int j = 0;

	bulls = 0;
	cows = 0;
	for (i = 0; i < digit; i++) {
		for (j = 0; j < digit; j++) {
			if (user_input[i] == secret_number[j]) {
				if (i == j)
					bulls++;
				else
					cows++;
			}
		}
	}
}

int is_valid_input(char *data)
{
	int dgt;

	if (data[0] == EOF)
		return 0;
	dgt = strlen(data);
	if (dgt != MAX_DIGIT)
		return 0;
	while (dgt--) {
		if (!isdigit(data[dgt]))
			return 0;
	}
	return 1;
}

int main(void)
{
	char *secret_number = generate();
	char user_input[MAX_SIZE];
	int times = CHANCE;

	while (times) {
		printf("Enter your Guess:");
		do {
			fgets(user_input, sizeof(user_input), stdin);
			user_input[strcspn(user_input, "\n")] = '\0';
		} while (!is_valid_input(user_input));

		check(secret_number, user_input);
		printf("Bulls: %d\tCows: %d\n", bulls, cows);
		times--;
		if (cows == 0 && bulls == MAX_DIGIT) {
			printf("You have found it!\n");
			return 0;
		}
	}
		printf("Sorry You Missed it (%s)\n", secret_number);
	return 1;
}
