#include <stdio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <error.h>
#include <errno.h>

#define MAX_WORD_LIST 20
#define MAX_CHANCE 7
#define FILE_NAME "list.txt"

void create_line(char *sol, int len)
{
	int i;

	for (i = 0; i < len; i++)
		sol[i] = '_';
	sol[i] = 0;
}

int check(char *rand_string, char *user_string)
{
	if (strcmp(rand_string, user_string) == 0)
		return 1;
	else
		return 0;
}

void display(char *user_string)
{
	int i = 0;

	while (user_string[i])
		printf("%c ", user_string[i++]);
}

void hang(void)
{
	static int warn;
	char *hangman[] = {"\n\n\n+--",
			   "|\n|\n|\n+--",
			   "+---\n|\n|\n|\n+--",
			   "+--+\n|  O\n|\n|\n+--",
			   "+--+\n|  O\n|  |\n|\n+--",
			   "+--+\n|  O\n| /|\\\n|\n+--",
			   "+--+\n|  O\n| /|\\\n| / \\\n+--"};

	printf("%s\n", hangman[warn++]);
}

int count_lines(void)
{
	char ch;
	FILE *fp;
	int max_lines = 0;

	fp = fopen(FILE_NAME, "r");
	if (fp == NULL)
		error(1, errno, "Error opening file");

	while ((ch = fgetc(fp)) != EOF)	{
		if (ch == '\n')
			max_lines++;
	}
	fclose(fp);
	if (fp == NULL)
		error(1, errno, "Error closing file");

	return max_lines;
}

void random_picker(char *word_list, int size)
{
	FILE *fp;
	int pos;
	int i;
	int len;
	char *ret;

	srand(time(NULL));

	fp = fopen(FILE_NAME, "r");
	if (fp == NULL)
		error(1, errno, "Error opening file");

	pos = (rand() % count_lines());
	for (i = 0; i <= pos; i++) {
		memset(word_list, '\0', size);
		ret = fgets(word_list, size, fp);
		if (ret == NULL)
			error(1, 0, "Error getting lines");
		len = strlen(word_list);
		word_list[len - 1] = '\0';
	}
	fclose(fp);
	if (fp == NULL)
		error(1, errno, "Error closing file");
}

int main(void)
{
	char word_list[MAX_WORD_LIST];
	int pos;
	int len;
	int chance = MAX_CHANCE;
	char user_input[MAX_WORD_LIST];
	int i;
	char sol[MAX_WORD_LIST];
	int warn = 0;
	int flag = 0;

	random_picker(word_list, MAX_WORD_LIST);
	len = strlen(word_list);
	create_line(sol, len);
	display(sol);

	while (chance) {
		printf("\nEnter a letter:");
		do {
			fgets(user_input, sizeof(user_input), stdin);
			user_input[strcspn(user_input, "\n")] = '\0';
		} while (!(strlen(user_input) == 1 && isalpha(user_input[0])));
		flag = len;
		user_input[0] = tolower(user_input[0]);
		for (i = 0; i < len; i++) {
			if (user_input[0] == word_list[i]) {
				sol[i] = word_list[i];
				flag--;
			}
		}
		if (flag == len) {
			chance--;
			hang();
		}
		display(sol);
		if (!chance)
			printf("\nYou missed your word- \"%s\"\n", word_list);
		if (check(word_list, sol)) {
			printf("\nYou Found it :)\n");
			break;
		}
	}
	return 0;
}

