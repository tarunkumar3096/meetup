#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#define COUNT 20
#define STRING_MAX 50

int score;

void check(int a, int b, char operation, int user_input)
{
		if ((operation == '+' ? a + b : a - b) == user_input) {
			printf("Correct!\n");
			score++;
		} else
			printf("Wrong!\n");
}

int is_valid_input(char *input)
{
	int i;

	for (i = 0; i < strlen(input) - 1; i++) {
		if (isdigit(input[i]) || input[0] == '-' || input[0] == '+')
			continue;
		else
			return 0;
	}
	return 1;
}

int main(void)
{
	int op1;
	int op2;
	int times = COUNT;
	int user_input;
	char input[STRING_MAX];
	int i;
	char operator[2] = {'+', '-'};

	srand(time(NULL));
	while (times--) {
		op1 = rand() % 100;
		op2 = rand() % 100;
		i = rand() % 2;
		printf("%d %c %d = ?\n", op1, operator[i],  op2);
		do {
			fgets(input, sizeof(input), stdin);
		} while (!is_valid_input(input));
		user_input = atoi(input);
		check(op1, op2, operator[i], user_input);
	}
	printf("Your Score %d/%d\n", score, COUNT);
	return 0;
}
