#include <stdio.h>
#include <string.h>

#define MAX_ROW 3
#define MAX_COLOUMN 3
#define X_WON "xxx"
#define O_WON "ooo"

void cleanbuffer(void)
{
	int n;

	while ((n = getchar()) != EOF && n != '\n')
		;
}

void display_grids(char *input)
{
	int i;

	for (i = 0; i < (MAX_ROW * MAX_COLOUMN); i = i + MAX_ROW) {
		printf("------------\n");
		printf("| %c | %c | %c |\n", input[i], input[i+1], input[i+2]);
	}
	printf("-------------\n");

}

int mark(char *input, int pos, char turn)
{
	if (input[pos] == ' ')
		input[pos] = turn;
	else
		return 0;
	return 1;
}

int check_validate(char *temp)
{
	if (!strcmp(temp, X_WON))
		return 'x';
	else if (!strcmp(temp, O_WON))
		return 'o';
	return 0;
}
int validate(char *input)
{
	char temp[4];
	int i;
	int j;
	int sol;
	int k = 0;
	int coordinates[MAX_ROW][MAX_COLOUMN] = {
		{0, 1, 2},
		{3, 4, 5},
		{6, 7, 8}
	};

	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COLOUMN; j++)
			temp[k++] = input[coordinates[i][j]];
		temp[k] = 0;
		sol = check_validate(temp);
		if (sol)
			return sol;
		k = 0;
	}

	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COLOUMN; j++)
			temp[k++] = input[coordinates[j][i]];
		temp[k] = 0;
		sol = check_validate(temp);
		if (sol)
			return sol;
		k = 0;
	}

	for (i = 0; i < MAX_ROW; i++)
		temp[k++] = input[coordinates[i][i]];
	temp[k] = 0;
	sol = check_validate(temp);
	if (sol)
		return sol;
	k = 0;

	for (i = 0; i < MAX_ROW; i++)
		temp[k++] = input[coordinates[0 +  i][2 - i]];
	temp[k] = 0;
	sol = check_validate(temp);
	if (sol)
		return sol;
	k = 0;

	return 0;
}

int main(void)
{
	char input[MAX_ROW * MAX_COLOUMN];
	int chance = MAX_ROW * MAX_COLOUMN;
	int pos;
	char turn;

	memset(input, ' ', sizeof(input));
	display_grids(input);
	while (chance--) {
		turn = 	chance % 2 ? 'x' : 'o';
		printf("%c's turn: ", turn);
		scanf("%d", &pos);
		cleanbuffer();
		pos--;
		if (!mark(input, pos, turn)) {
			chance++;
			printf("Sorry Enter Valid position\n");
		}
		display_grids(input);
		switch (validate(input)) {
		case 'x':
			printf("X Won\n");
			return 0;
		case 'o':
			printf("O Won\n");
			return 0;
		}
	}
	printf("Game DRAW\n");
	return 0;
}
