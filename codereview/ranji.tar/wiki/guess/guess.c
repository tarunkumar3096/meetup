#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CHANCE 7
#define INT_MAX 99
#define INT_MIN 0

int read_int(int *intp)
{
	char buf[256];
	char *retp;
	char *endptr;
	long input;
	int i = 0;
	int j = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	while (buf[i]) {
		if (buf[i] != ' ')
			buf[j++] = buf[i];
		i++;
	}

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || *retp == 10)
		return -2;

	if (input > INT_MAX)
		return -2;

	if (input < INT_MIN)
		return -2;

	*intp = (int) input;
	return 0;
}

int main(void)
{
	srand(time(NULL));
	int i;
	int randno = rand()%100;
	int guess;
	int test;


	for (i = 0; i < CHANCE; i++) {
		printf("\nEnter your number:");
		test = read_int(&guess);
		if (guess < 100) {
			if (test == -2) {
				printf("::INVALID INPUT::");
				i--;
			} else if (test == 0) {
				if (randno > guess)
					printf("Your number is smaller.");
				if (randno < guess)
					printf("Your number is larger.");
				if (randno == guess) {
					printf("Hurray! You found the number!");
					break;
				}
			}
		}
	}
	return 0;
}

