#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>

#define FAILURE 1
#define SUCCESS 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define NULL_POINTER -3
#define NON_UNIQUE -4
#define CPY_ERR -5
#define OUT_OF_RANGE -6

#define DIGIT_FOR_LOC 10 /*10 for 1 digit number*/
#define MAX_SHUFFLE 100
#define CHANCE 8
#define MAX_DIGIT 4
#define MAX_BUF (MAX_DIGIT + 2)

static int unique_input(char *digits, int size)
{
	if (digits == NULL)
		return NULL_POINTER;

	int i = 0;
	int j = 0;

	for (i = 0; i < size; i++) {
		for (j = i + 1; j < size - 1; j++) {
			if (digits[i] == digits[j])
				return FAILURE;
		}
	}

	return SUCCESS;
}

static int read_input(char *user_digits, int size)
{
	if (user_digits == NULL)
		return NULL_POINTER;

	char buf[MAX_BUF];
	char *retp;
	char *endptr;

	retp = fgets(buf, sizeof(buf), stdin);
	if ((retp == NULL) || (*retp == '\n'))
		return NO_INPUT;

	strtol(retp, &endptr, 10);
	if ((*endptr != '\n') || (retp[MAX_DIGIT] != '\n')) {
		__fpurge(stdin);/* To clear data which more than buf[16] */
		return INVALID_INPUT;
	}

	if (isdigit(*retp) == 0)
		return INVALID_INPUT;

	if (unique_input(buf, sizeof(buf)) != SUCCESS)
		return NON_UNIQUE;

	if (strncpy(user_digits, buf, size) == NULL)
		return CPY_ERR;

	return SUCCESS;
}

static int input_validation(char *user_digits, int size)
{
	if (user_digits == NULL)
		return NULL_POINTER;

	int error_code;

	while ((error_code = read_input(user_digits, size)) != 0) {
		switch (error_code) {
		case NO_INPUT:
			printf("\nNo Input\n");
			break;
		case INVALID_INPUT:
			printf("Invalid Input\n");
			break;
		case NULL_POINTER:
			printf("Null pointer\n");
			break;
		case NON_UNIQUE:
			printf("Provide unique digits\n");
			break;
		default:
			printf("error in copying data\n");
		}

		printf("Enter again:\t");
	}

	return SUCCESS;
}

static int number_generator(void)
{
	return rand() % DIGIT_FOR_LOC;
}

static int shuffler(char *digits, int size)
{
	if (digits == NULL)
		return NULL_POINTER;

	int shuffles;
	int temp;
	int loc_1;
	int loc_2;

	for (shuffles = 0; shuffles != MAX_SHUFFLE; shuffles++) {
		loc_1 = number_generator();
		loc_2 = number_generator();

		temp = digits[loc_1];
		digits[loc_1] = digits[loc_2];
		digits[loc_2] = temp;
	}

	return SUCCESS;
}


static int digit_comparator(char *sys_digits, int size_sys,
			    char *user_digits, int size_user)
{
	if ((user_digits == NULL) || (sys_digits == NULL))
		return NULL_POINTER;

	if ((size_sys < MAX_DIGIT) || (size_user < MAX_DIGIT))
		return OUT_OF_RANGE;

	int i = 0;
	int j = 0;
	int cow = 0;
	int bull = 0;

	for (i = 0; i < MAX_DIGIT; i++) {
		for (j = 0; j < MAX_DIGIT; j++) {
			if (sys_digits[i] == user_digits[j]) {
				if (i == j)
					bull++;
				else
					cow++;
			}
		}
	}

	printf("cow = %d\tbull = %d\n", cow, bull);

	if ((cow == 0) && (bull == MAX_DIGIT))
		return SUCCESS;

	return FAILURE;
}


static int comparasion_result(char *digits, int size)
{
	if (digits == NULL)
		return NULL_POINTER;

	char digit_buf[MAX_BUF];
	int ret_compare;

	printf("Enter four digit number:\t");
	if (input_validation(digit_buf, sizeof(digit_buf)) == NULL_POINTER)
		return NULL_POINTER;

	ret_compare = digit_comparator(digits, size, digit_buf,
				       sizeof(digit_buf));

	switch (ret_compare) {
	case NULL_POINTER:
		printf("Null pointer error\n");
		return NULL_POINTER;
	case OUT_OF_RANGE:
		printf("Out of range\n");
		return OUT_OF_RANGE;
	case SUCCESS:
		return SUCCESS;
	}

	return FAILURE;
}


int main(void)
{
	int chance;
	char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
			 '9', '\0'};
	int ret_cmp;

	srand(time(NULL));
	if (shuffler(digits, sizeof(digits)) == FAILURE) {
		printf("Error in the digit buffer\n");
		return 1;
	}

	printf("Total Chance = %d\n", CHANCE);
	for (chance = 0; chance != CHANCE; chance++)  {
		ret_cmp = comparasion_result(digits, sizeof(digits));
		if (ret_cmp == SUCCESS) {
			printf("HURRAY! You found\n");
			break;
		}
	}

	if (ret_cmp == FAILURE)
		printf("Oops! You didn't found\n");
	
	return SUCCESS;
}
