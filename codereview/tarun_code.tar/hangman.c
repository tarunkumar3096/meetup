#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <string.h>
#include <ctype.h>
#include <error.h>
#define FAILURE 1
#define SUCCESS 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define NULL_POINTER -3

#define TOTAL_CHANCE 7
#define MAX_WORDS 4
#define MAX_BUF 4

#define BODY 5
#define TOP 3
#define STAND 2
#define BASE 1
#define DIGITS_FOR_LOC MAX_WORDS /*10 for 1 digit number*/

static void hangman(int chance)
{
	int i = 0;
	char *top =   "+--+";
	char *stand = "|"; 
	char *base =  "+--+";

	char *man[] = {"  O",
		       " /|\\",
		       " / \\"};
	char *body = "  |";

	int pic_loc = chance;
	int loop_count = chance;
	int row = sizeof(man)/sizeof(*man);
	
	if (pic_loc > TOP)
		pic_loc = TOP;
	
	switch (pic_loc) {
	case TOP:
		printf("%s\n", top);
	case STAND:
 		for (i = 0; i < row; i++) { 
			printf("%s", stand);

			if (loop_count > TOP) {
				if ((chance == BODY) && (i == 1))
					printf("%s", body);
				else
					printf("%s", man[i]);
			}

			if ((chance > BODY) && (i == 0))
				loop_count--;
			
			loop_count--;
			printf("\n");
		}
	case BASE:
		printf("%s\n", base);
		break;
	default:
		printf("ERROR in chance\n");
	}
}

static int user_input(char *data, int size)
{
	if (data == NULL)
		return NULL_POINTER;

	char buf[MAX_BUF];
	char *retp;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if ((retp == NULL) || (*retp == '\n'))
		return NO_INPUT;

	if (buf[size] != '\n') {
		__fpurge(stdin);/* To clear data which more than buf[3] */
		return INVALID_INPUT;
	}

	input = isalpha(buf[0]);
	if (input == 0)
		return INVALID_INPUT;

	*data = (char) buf[0];

	return 0;
}

static int input_validation(char *user_data, int size)
{
	if (user_data == NULL)
		return NULL_POINTER;

	int error_code;

	while ((error_code = user_input(user_data, size)) != 0) {
		switch (error_code) {
		case NO_INPUT:
			printf("\nNo Input\n");
			break;
		case INVALID_INPUT:
			printf("Invalid Input\n");
			break;
		case NULL_POINTER:
			printf("Null pointer\n");
			break;
		}

		printf("Enter again:\t");
	}

	return SUCCESS;
}

static int display(char *user_buf, int size)
{
	if (user_buf == NULL)
		return NULL_POINTER;

	int i = 0;

	for (i = 0; i < size; i++) {
		if (user_buf[i] == 0)
			printf(" ");
		else
			printf("%c", user_buf[i]);
	}
	printf("\n");

	for (i = 0; i < size; i++)
		printf("-");
	printf("\n");

	return SUCCESS;
}

static int comparator(char *sys_data, int size)
{
	if (sys_data == NULL)
		return NULL_POINTER;

	char empty_buf[size];
	char character;
	int set_char;
	int chance = 0;
	int i = 0;

	if (memset(empty_buf, 0, sizeof(empty_buf)) == NULL)
		error(1, 0, "error in memset\n");

	if (display(empty_buf, sizeof(empty_buf)) != 0)
		printf("Null pointer error\n");

	for (chance = 0; chance < TOTAL_CHANCE; ) {
		set_char = 0;
		printf("Enter a letter:   ");
		if (input_validation(&character, sizeof(character)) != 0)
			continue;

		for (i = 0; i < size; i++) {
			if (strncasecmp(&sys_data[i], &character, 1) == 0) {
				empty_buf[i] = sys_data[i];
				set_char = 1;
			}
		}

		if (display(empty_buf, sizeof(empty_buf)) != 0)
			printf("Null pointer error\n");

		if (strcasecmp(empty_buf, sys_data) == 0)
			return SUCCESS;

		if (set_char == 1)
			continue;

		chance++;
		hangman(chance);
	}

	return FAILURE;
}


static int number_generator(void)
{
	return rand() % DIGITS_FOR_LOC;
}

int main(void)
{
	int rand;
	char *word[MAX_WORDS] = {"Quiz", "jump", "clean", "puzzle"};

	srand(time(NULL));
	rand = number_generator();
	if (comparator(word[rand], strlen(word[rand])) == 0)
		printf("Hurray! You found the word!\n");
	else
		printf("Oops! You didn't found the word!\n");

	return SUCCESS;
}
