#include <stdio_ext.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <error.h>

#define MAX_COND 4
#define LEADING_DIAGONAL(x, y) finding_marks(x+1, y+1, grid, direction)
#define TRAILING_DIAGONAL(x, y) finding_marks(x-1, y+1, grid, direction)
#define VERTICAL(x, y) finding_marks(x+1, y, grid, direction)
#define HORIZONTAL(x, y) finding_marks(x, y+1, grid, direction)

#define FAILURE 1
#define SUCCESS 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define NULL_POINTER -3

#define SQUARE 3
#define VERTICAL_PATH 1
#define HORIZONTAL_PATH 2
#define TRAILING_DIAGONAL_PATH 3
#define LEADING_DIAGONAL_PATH 4

#define LEADING_DIAGONAL_LOC 00/*row = 0 & column = 0*/
#define TRAILING_DIAGONAL_LOC ((SQUARE - 1) * 10) + 0 /*row = (square -1) & column = 0*/

static int X_count;
static int O_count;
static int direction(int x, int y, char (*grid)[SQUARE], int direction)
{
	switch (direction) {
	case VERTICAL_PATH:
		if (VERTICAL(x, y) == 0)
			return SUCCESS;
		break;
	case HORIZONTAL_PATH:
		if (HORIZONTAL(x, y) == 0)
			return SUCCESS;
		break;
	case TRAILING_DIAGONAL_PATH:
		if (TRAILING_DIAGONAL(x, y) == 0)
			return SUCCESS;
		break;
	case LEADING_DIAGONAL_PATH:
		if (LEADING_DIAGONAL(x, y) == 0)
			return SUCCESS;
		break;
	default:
		printf("Error in direction\n");
	}

	return FAILURE;
}

int finding_marks(int x, int y, char (*grid)[SQUARE], int direction_code)
{
	if ((x < 0) || (x >= SQUARE) || (y < 0) || (y >= SQUARE))
		return FAILURE;

	if (grid[x][y] == 'X')
		X_count++;

	if (grid[x][y] == 'O')
		O_count++;

	if ((X_count == SQUARE) || (O_count == SQUARE))
		return SUCCESS;

	if (direction(x, y, grid, direction_code) == 0)
		return SUCCESS;

	return FAILURE;
}

static int read_int(int *data)
{
	if (data == NULL)
		return NULL_POINTER;

	char buf[3];
	char *retp;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if ((retp == NULL) || (*retp == '\n'))
		return NO_INPUT;

	if (buf[1] != '\n') {
		__fpurge(stdin);/* To clear data which more than buf[3] */
		return INVALID_INPUT;
	}

	if (buf[0] == '0')
		return INVALID_INPUT;

	input = isdigit(buf[0]);
	if (input == 0)
		return INVALID_INPUT;

	*data = atoi(buf);

	return SUCCESS;
}

static void grid_display(char (*grid)[SQUARE], char (*ref_grid)[SQUARE])
{
	int i;
	int j;

	printf("\n----MAIN-----   ------REF-----\n");
	for (i = 0; i < SQUARE; i++) {
		for (j = 0; j < SQUARE; j++)
			printf("| %c ", grid[i][j]);
		printf("| \t");
		for (j = 0; j < SQUARE; j++)
			printf("| %c ", ref_grid[i][j]);
		printf("|\n");
	}
	printf("-------------   -------------\n");
}

static int grid_marking(char (*grid)[SQUARE], char (*ref_grid)[SQUARE], int data)
{
	int user_loc;
	int ret_int;
	int row = 0;
	int column = 0;

	while ((ret_int = read_int(&user_loc)) != SUCCESS) {
		if (ret_int == NO_INPUT)
			printf("No input\n");
		else if (ret_int == INVALID_INPUT)
			printf("Invalid data\n");

		printf("Enter Again\n");
	}

	row = (user_loc - 1) / SQUARE;
	column = (user_loc - 1) % SQUARE;

	if ((grid[row][column] != 'X') && (grid[row][column] != 'O')) {
		grid[row][column] = data;
		ref_grid[row][column] = ' ';
	} else
		return FAILURE;

	grid_display(grid, ref_grid);
	return SUCCESS;
}

static int path_provider(int row, int column, char (*grid)[SQUARE], int direction)
{
	X_count = 0;
	O_count = 0;
	if (finding_marks(row, column, grid, direction) == SUCCESS)
		return SUCCESS;

	return FAILURE;
}

static int loc_provider(char (*grid)[SQUARE])
{

	int i = 0;
	int j = 0;
	int leading_diagonal = LEADING_DIAGONAL_LOC;
	int trailing_diagonal = TRAILING_DIAGONAL_LOC;

	/*For vertical search*/
	for (i = 0, j = 0; j < SQUARE; j++) {
		if (path_provider(i, j, grid, VERTICAL_PATH) == 0)
			return SUCCESS;
	}
	/*For horizontal search*/
	for (i = 0, j = 0; i < SQUARE; i++) {
		if (path_provider(i, j, grid, HORIZONTAL_PATH) == 0)
			return SUCCESS;
	}
	/*For trailing_diagonal search*/
	i = trailing_diagonal / 10;
	j = trailing_diagonal % 10;
	if (path_provider(i, j, grid, TRAILING_DIAGONAL_PATH) == 0)
		return SUCCESS;

	/*For leading_diagonal search*/
	i = leading_diagonal / 10;
	j = leading_diagonal % 10;
	if (path_provider(i, j, grid, LEADING_DIAGONAL_PATH) == 0)
		return SUCCESS;

	return FAILURE;
}

static void digits_initializer(char (*ref)[SQUARE])
{
	int i = 0;
	int j = 0;
	int count = 1;

	for (i = 0; i < SQUARE; i++) {
		for (j = 0; j < SQUARE; j++)
			ref[i][j] = count++ + 48;
	}
}

int main(void)
{
	char ref_grid[SQUARE][SQUARE];
	char main_grid[SQUARE][SQUARE];
	int player_1 = 'X';
	int player_2 = 'O';
	int *player[] = {&player_1, &player_2};
	int input_count = 0;

	digits_initializer(ref_grid);
	if (memset(main_grid, ' ', sizeof(char) * SQUARE * SQUARE) == NULL)
		error(1, 0, "error in memset function");

	grid_display(main_grid, ref_grid);

	for (input_count = 0; input_count != (SQUARE * SQUARE); input_count++) {
		printf("Enter location for player%d:\t", (input_count % 2) + 1);
		while (grid_marking(main_grid, ref_grid,
				    *player[input_count % 2]) != 0)
			printf("Location already exist:\t");

		if (loc_provider(main_grid) == 0)
			break;
	}

	if (X_count == SQUARE)
		printf("Player 1 won\n");
	else if (O_count == SQUARE)
		printf("Player 2 won\n");
	else
		printf("Draw\n");
	return 0;
}
