#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <time.h>
#include <stdio_ext.h>/* for __fpurge() */
#define FAILURE 1
#define SUCCESS 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define NULL_POINTER -3

#define TOTAL_REPETIIONS 20
#define MAX_BUF 16
#define MAX_SYMBOL 2
#define DIGITS_TO_PROCESS 100 /*100 for 2 digit number*/

static int read_int(int *intp)
{
	if (intp == NULL)
		return NULL_POINTER;

	char buf[MAX_BUF];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if ((retp == NULL) || (*retp == '\n'))
		return NO_INPUT;

	input = strtol(retp, &endptr, 10);
	if ((*endptr != '\n')) {
		__fpurge(stdin);/* To clear data which more than buf[16] */
		return INVALID_INPUT;
	}
	
	if (input > INT_MAX)
		return INVALID_INPUT;

	if (input < INT_MIN)
		return INVALID_INPUT;

	*intp = (int) input;

	return SUCCESS;
}

static int addition(int op1, int op2)
{
	return op1 + op2;
}

static int subtraction(int op1, int op2)
{
	return op1 - op2;
}

static int arithmetic_operation(int op1, int op2, char symbol, int *result)
{
	switch (symbol) {
	case '+':
		*result = addition(op1, op2);
		return SUCCESS;
	case '-':
		*result = subtraction(op1, op2);
		return SUCCESS;
	default:
		printf("Max symbol is reached\n");
	}

	return FAILURE;
}

static int number_generator(void)
{
	return rand() % DIGITS_TO_PROCESS;
}

static int comparator(int user_result, int system_result)
{
	if (user_result == system_result)
		return SUCCESS;

	return FAILURE;
}

static int input_validation(void)
{
	int result;
	int error_code;

	while ((error_code = read_int(&result)) != SUCCESS) {
		switch (error_code) {
		case NO_INPUT:
			printf("\nNo Input\n");
			break;
		case INVALID_INPUT:
			printf("Invalid Input\n");
			break;
		case NULL_POINTER:
			printf("NULL pointer\n");
			break;
		}
		printf("Enter again:\t");
	}

	return result;
}

static int sys_result_generator(void)
{
	int operand1;
	int operand2;
	int oper;
	int system_result;
	char symbol[] = {'+', '-'};

	operand1 = number_generator();
	operand2 = number_generator();
	while (1) {
		oper = number_generator() % MAX_SYMBOL;

		printf("%d %c %d ? \t", operand1, symbol[oper], operand2);

		if (arithmetic_operation(operand1, operand2, symbol[oper],
					 &system_result) != SUCCESS) {
			printf("Invalid operator\n");
			continue;
		}
		break;
	}

	return system_result;
}

int main(void)
{
	int repetitions;
	int result = 0;
	int user_int;
	int ret_cmp;
	int system_result;
	int result_count = 0;
	/*It cannot change the char to which display[] points, */
	/*It cannot modify data content that char points by using diplay[]*/
	const char * const display[] = {"Correct", "Wrong"};

	srand(time(NULL));
	for (repetitions = 0; repetitions != TOTAL_REPETIIONS; repetitions++) {

		system_result = sys_result_generator();
		user_int = input_validation();
		ret_cmp = comparator(system_result, user_int);

		printf("%s\n", display[ret_cmp]);
		if (ret_cmp)
			result_count++;
	}

	printf("Your score is %d/%d\n", result_count, TOTAL_REPETIIONS);
	return SUCCESS;
}
