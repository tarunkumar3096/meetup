#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio_ext.h>
#include <time.h>
#define FAILURE 1
#define SUCCESS 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define NULL_POINTER -3

#define MAX_BUF 16
#define INTEGER_MIN 0
#define INTEGER_MAX 100
#define BASE 10
#define TOTAL_CHANCE 7
#define DIGIT_TO_PROCESS 100 /* 100 for 2 digit number*/
/*
 * Reads and stores an integer at location pointed to by intp. Returns 0
 * on success and -1 if no input from user, or -2 if invalid input
 * from user, or input is out of range.
 *
 * If the user inputs non numeric characters, the value stored in intp will
 * be 0.
 */

static int read_int(int *intp)
{
	if (intp == NULL)
		return NULL_POINTER;

	char buf[MAX_BUF];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if ((retp == NULL) || (*retp == '\n'))
		return NO_INPUT;

	input = strtol(retp, &endptr, BASE);
	if (*endptr != '\n') {
		__fpurge(stdin);
		return INVALID_INPUT;
	}

	if (input >= INTEGER_MAX)
		return INVALID_INPUT;

	if (input < INTEGER_MIN)
		return INVALID_INPUT;
	    
	*intp = (int) input;

	return SUCCESS;
}

static int input_validation(int *user_digits)
{
	if (user_digits == NULL)
		return NULL_POINTER;

	int error_code;

	while ((error_code = read_int(user_digits)) != SUCCESS) {
		switch (error_code) {
		case NO_INPUT:
			printf("\nNo Input\n");
			break;
		case INVALID_INPUT:
			printf("Invalid Input\n");
			break;
		case NULL_POINTER:
			printf("NULL pointer\n");
			break;
		}
		printf("Enter again:\t");
	}

	return SUCCESS;
}

static int comparator(int sys_data)
{
	int guess;
	int attempt = 0;

	while (attempt != TOTAL_CHANCE) {
		printf("\nEnter your two DIGIT number:   ");
		if (input_validation(&guess) != 0)
			return NULL_POINTER;

		if (guess > sys_data)
			printf("Your number is larger.\n");
		else if (guess < sys_data)
			printf("Your number is smaller.\n");
		else if (guess == sys_data)
			return SUCCESS;

		attempt++;
	}

	return FAILURE;
}

static int number_generator(void)
{
	return rand() % DIGIT_TO_PROCESS;
}

int main(void)
{
	int rand_num;
	int ret_cmp;

	srand(time(NULL));
	rand_num = number_generator();

	ret_cmp = comparator(rand_num);
	if (ret_cmp == SUCCESS) {
		printf("Hurray! You found the number!\n");
	} else if (ret_int == FAILURE) {
		printf("Oops! You didn't found the number!\n");
	} else {
		printf("Pointer error\n");
		return FAILURE;
	}

	return SUCCESS;
}
