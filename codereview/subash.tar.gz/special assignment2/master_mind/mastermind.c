#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <limits.h>
#define TIME 100
#define CHANCE 8
#define LENGTH 4

void swapping(char digits[], int size, int times)
{
	int num1 = 0;
	int num2 = 0;
	char temp[2];

	while (1) {
		while (times != 0) {
			num1 = rand() % 10;
			num2 = rand() % 10;
			temp[0] = digits[num1];
			temp[1] = digits[num2];
			digits[num1] = temp[1];
			digits[num2] = temp[0];
			times--;
		}
		if (digits[0] == '0') {
			times = TIME;
			continue;
		} else
			break;
	}
}

int unique_number(char result[], int size, int length)
{
	int i = 0;
	int j = 0;
	int count = 0;
	char result1[100];

	strcpy(result1, result);
	for (i = 0; i < size; i++) {
		for (j = 0; j < size; j++) {
			if (result[i] == result1[j])
				count++;
		}
	}
	if (count > length)
		return 0;
	else
		return 1;
}

int read_int(char buf[], int size, int length)
{
	char *retp;
	char *endptr;
	long input;
	int i = 0;

	retp = fgets(buf, size, stdin);
	if (retp == NULL)
		return -2;
	while (1) {
		if (i > LENGTH) {
			while ((getchar()) != '\n')
				;
			return -2;
		}
		if (buf[i] == '\n')
			break;
		i++;
	}
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ')
			return -2;
		i++;
	}
	i = 0;
	if (strlen(buf) == 1 && buf[i] == '\n')
		return -2;
	while (buf[i] != '\n')
		i++;
	buf[i] = '\0';
	if (strlen(buf) > length || strlen(buf) < length)
		return -2;
	input = strtol(retp, &endptr, 10);
	if ((*endptr != '\n' && *endptr != '\0') || *retp == 10)
		return -2;
	if (input > INT_MAX)
		return -2;
	if (input < INT_MIN)
		return -2;
	if (input < 0)
		return -2;
	return 0;
}


int chances(int bull, int cows, int chance, char digits[], int size)
{
	char result[LENGTH+2];
	char check_array[100];
	int i = 0;
	int check = 0;

	strcpy(check_array, digits);
	while (chance != 0) {
		i = 0;
		bull = 0;
		cows = 0;
		printf("enter your guess:");
		check = read_int(result, sizeof(result), LENGTH);
		if (check == -2) {
			printf("Incorrect Input\n");
			continue;
		}
		check = unique_number(result, strlen(result), LENGTH);
		if (check == 0) {
			printf("Only Unique numbers allowed\n");
			result[0] = '\0';
			continue;
		}
		digits[LENGTH] = '\0';
		for (i = 0; i < LENGTH; i++) {
			if (digits[i] == result[i])
				bull++;
			else if (strchr(digits, result[i]) != NULL)
				cows++;
		}
		printf("bull=%d,cows=%d\n", bull, cows);
		if (bull == LENGTH)
			return 1;
		chance--;
	}
	return 0;
}
int main(void)
{
	char digits[] = {'0', '1', '2', '3', '4', '5',
			 '6', '7', '8', '9', '\0'};
	int bull = 0;
	int cows = 0;
	int times = TIME;
	int chance = CHANCE;

	srand(time(0));
	swapping(digits, strlen(digits), times);
	if (chances(bull, cows, chance, digits, strlen(digits)) == 1)
		printf("Number Found\n");
	else
		printf("8 chances over\n");
	printf("random number=%s\n", digits);
	return 0;
}
