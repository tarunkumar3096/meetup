#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <limits.h>

#define CHANCE 8

void hang(char dash[], int size, int failed)
{
	if (failed == 1)
		printf("-+-\n");
	else if (failed == 2)
		printf("|\n|\n|\n-+-\n");
	else if (failed == 3)
		printf("+---\n|\n|\n|\n-+-\n");
	else if (failed == 4)
		printf("+--+\n|  O\n|\n|\n|\n-+-\n");
	else if (failed == 5)
		printf("+--+\n|  O\n|  |\n|\n|\n|\n-+-\n");
	else if (failed == 6)
		printf("+--+\n|  O\n| /|\\\n|\n|\n|\n-+-\n");
	else if (failed == 7)
		printf("+--+\n|  O\n| /|\\\n| / \\\n|\n|\n|\n-+-\n");
}

int validity(char c[], int size, int *flag)
{
	int i = 0;

	if (strlen(c) > 1) {
		printf("Incorrect input\n");
		flag = 0;
		return -1;
	}
	for (i = 0; i < strlen(c); i++) {
		if (tolower(c[i]) < 97 || tolower(c[i]) > 122) {
			printf("Incorrect input\n");
			c[0] = '\0';
			return -1;
		}
	}
	return 0;
}

int read_int(char buf[], int size)
{
	char *retp;
	char *endptr;
	long input;
	int i = 0;

	retp = fgets(buf, size, stdin);
	if (retp == NULL)
		return -2;
	while (1) {
		if (i > size) {
			while ((getchar()) != '\n')
				;
			return -2;
		}
		if (buf[i] == '\n')
			break;
		i++;
	}
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ')
			return -2;
		i++;
	}
	i = 0;
	if (strlen(buf) == 1 && buf[i] == '\n')
		return -2;
	while (buf[i] != '\n')
		i++;
	buf[i] = '\0';
	if (strlen(buf) > 1 || strlen(buf) < 1)
		return -2;
	input = strtol(retp, &endptr, 10);
	if (*retp == 10)
		return -2;
	if (input != '\0')
		return -2;
	return 0;
}

int draw_hangman(char selected[], int size, char dash[], int size1)
{
	int i;
	int failed = 0;
	int chance = CHANCE;
	int flag = 0;
	char c[3] = {0};

	while (chance >= 2) {
		if (strcmp(selected, dash) == 0)
			return 1;
		while (1) {
			i = 0;
			flag = 0;
			printf("Enter a letter:");
			if (read_int(c, sizeof(c)) == -2) {
				printf("Incorrect input\n");
				continue;
			} else
				break;
		}
		c[1] = '\0';
		i = 0;
		if (strchr(selected, tolower(c[0])) == NULL)
			flag = 1;

		for (i = 0; i < strlen(dash); i++) {
			if (selected[i] == tolower(c[0])) {
				dash[i] = tolower(c[0]);
			} else if ((selected[i] != tolower(c[0]))
				   && flag == 1) {
				failed++;
				chance--;
				hang(dash, sizeof(dash), failed);
				break;
			}
		}
		printf("word=%s\n", dash);
		c[0] = '\0';
	}
	return 0;
}

int operation(char selected[], int size)
{
	int i = 0;
	char dash[100] = {0};

	while (i !=  strlen(selected)) {
		strcat(dash, "_");
		i++;
	}
	dash[i] = '\0';
	printf("word=%s\n", dash);
	if (draw_hangman(selected, sizeof(selected), dash, sizeof(dash)) == 1)
		return 1;
	return 0;
}

int main(void)
{
	char *words[3] = {"hello", "world", "hi"};
	char selected[100];
	int num1 = 0;

	srand(time(0));
	num1 = rand() % 3;
	strcpy(selected, words[num1]);
	printf("%zu letter word\n", strlen(selected));
	if (operation(selected, sizeof(selected)) == 1) {
		printf("Word Found\n");
	} else {
		printf("8 Chances over\n");
		printf("word is :%s\n", selected);
	}
	return 0;
}
