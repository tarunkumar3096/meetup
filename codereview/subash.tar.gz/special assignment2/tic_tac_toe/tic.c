#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#define FAIL -3
#define SUCCESS 4
#define EMPTY_SPACE 0
#define NO_INPUT -1
#define INVALID_INPUT -2
#define PLAYER1 1
#define PLAYER2 2
#define ROW 3
#define COL 3

void print(int val)
{
	if (val == 1)
		printf("X\t");
	else if (val == 2)
		printf("O\t");
	else
		printf("-\t");
}

void print_matrix(int array[], int row, int col)
{
	int i = 0;
	int j = 0;

	for (i = 0; i < row; i++) {
		for (j = 0; j < col; j++)
			print(array[(i * row) + j]);
		puts("");
	}
}

int row_wise(int arr[], int size)
{
	int i = 0;
	int j = 0;
	int x_count = 0;
	int y_count = 0;

	for (i = 0; i < ROW * COL; i = i + ROW) {
		for (j = i; j < (ROW + i); j++) {
			if (arr[j] == PLAYER1)
				x_count++;
			if (arr[j] == PLAYER2)
				y_count++;
		}
		if (x_count == ROW)
			return PLAYER1;
		if (y_count == ROW)
			return PLAYER2;
		x_count = 0;
		y_count = 0;
	}
	return FAIL;
}

int column_wise(int arr[], int size)
{
	int i = 0;
	int j = 0;
	int x_count = 0;
	int y_count = 0;

	for (i = 0; i < ROW * COL; i++) {
		for (j = i; j < (ROW * COL); j = j + COL) {
			if (arr[j] == PLAYER1)
				x_count++;
			if (arr[j] == PLAYER2)
				y_count++;
		}
		if (x_count == ROW)
			return PLAYER1;
		if (y_count == ROW)
			return PLAYER2;
		x_count = 0;
		y_count = 0;
	}
	return FAIL;
}

int diagonal_wise(int arr[], int size)
{
	int i = 0;
	int x_count = 0;
	int y_count = 0;

	for (i = 0; i < (ROW * COL); i = COL + (i + 1)) {
		if (arr[i] == PLAYER1)
			x_count++;
		if (arr[i] == PLAYER2)
			y_count++;
	}
	if (x_count == ROW)
		return PLAYER1;
	if (y_count == ROW)
		return PLAYER2;
	x_count = 0;
	y_count = 0;

	for (i = (ROW - 1); i < ((ROW * COL) - 1); i = i + (ROW - 1)) {
		if (arr[i] == PLAYER1)
			x_count++;
		if (arr[i] == PLAYER2)
			y_count++;
	}
	if (x_count == ROW)
		return PLAYER1;
	if (y_count == ROW)
		return PLAYER2;
	x_count = 0;
	y_count = 0;
	return FAIL;
}

int win(int arr[], int size)
{
	int check = 0;

	while (1) {
		check = row_wise(arr, size);

		if (check == PLAYER1)
			return PLAYER1;
		else if (check == PLAYER2)
			return PLAYER2;
		else if (check == FAIL)
			break;
	}
	while (1) {

		check = column_wise(arr, size);

	        if (check == PLAYER1)
			return PLAYER1;
		else if (check == PLAYER2)
			return PLAYER2;
		else if (check == FAIL)
			break;
	}
	while (1) {
		check = diagonal_wise(arr, size);

		if (check == PLAYER1)
			return PLAYER1;
		else if (check == PLAYER2)
			return PLAYER2;
		else if (check == FAIL)
			break;
	}
	return FAIL;
}

int read_int(int *intp, int size)
{
	char *retp;
	char buf[size];
	char *endptr;
	long input;
	int i = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return NO_INPUT -1;
	while (1) {

		if (i > size) {
			while ((getchar()) != '\n')
				;
			printf("Incorrect input\n");
			return INVALID_INPUT;
		}
		if (buf[i] == '\n')
			break;
		i++;
	}
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ')
			return INVALID_INPUT;
		i++;
	}
	i = 0;
	if (strlen(buf) == 1 && buf[i] == '\n')
		return INVALID_INPUT;
	while (buf[i] != '\n')
		i++;
	buf[i] = '\0';
	input = strtol(retp, &endptr, 10);

	if ((*endptr != '\n' && *endptr != '\0') || *retp == 10)
		return INVALID_INPUT;

	if (input > INT_MAX || input >= (ROW * COL))
		return INVALID_INPUT;

	if (input < INT_MIN || input >= (ROW * COL))
		return INVALID_INPUT;

	if (input < 0)
		return INVALID_INPUT;

	*intp = (int) input;
	return *intp;
}

void move_player(int a[], int size, int player)
{
	int pos = 0;

	while (1) {
		printf("enter player%d:", player);
		pos = read_int(&pos, sizeof(a));
		if (pos == NO_INPUT || pos == INVALID_INPUT) {
			printf("enter again\n");
			continue;
		}
		if (a[pos] != EMPTY_SPACE) {
			printf("enter again\n");
			continue;
		} else if (a[pos] == EMPTY_SPACE) {
			if (player == PLAYER1) {
				a[pos] = PLAYER1;
				break;
			} else if (player == PLAYER2) {
				a[pos] = PLAYER2;
				break;
			}
		}
	}
}

int operation(int a[], int size, int player, int *count)
{
	int won = 0;

	while (1) {
		if (*count == (ROW * COL)) {
			printf("draw\n");
			return SUCCESS;
		}
		move_player(a, sizeof(a), player);
		print_matrix(a, ROW, COL);
		printf("\n");
		won = win(a, sizeof(a));
		if (won == PLAYER1) {
			printf("player1 won\n");
			return SUCCESS;
		} else if (won == PLAYER2) {
			printf("player2 won\n");
			return SUCCESS;
		}
		*count = *count + 1;
		break;
	}
	return FAIL;
}

int play(int a[], int size)
{
	int count = 0;

	while (1) {
		if (operation(a, size, PLAYER1, &count) == SUCCESS)
			return SUCCESS;
		if (operation(a, size, PLAYER2, &count) == SUCCESS)
			return SUCCESS;
	}
	return FAIL;
}

int main(void)
{
	int a[ROW*COL] = {0};

	print_matrix(a, ROW, COL);
	if (play(a, sizeof(a)) != SUCCESS)
		return FAIL;
	return SUCCESS;
}
