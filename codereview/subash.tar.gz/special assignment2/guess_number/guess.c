#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <string.h>

#define INVALID_INPUT -2
#define VALID_INPUT 0
#define MAX 7

int read_int(int *intp)
{
	char *retp;
	char *endptr;
	long input;
	char buf[255];
	int i = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return INVALID_INPUT;
	while (1) {
		if (i > sizeof(buf)) {
			while ((getchar()) != '\n')
				;
			return INVALID_INPUT;
		}
		if (buf[i] == '\n')
			break;
		i++;
	}
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ')
			return INVALID_INPUT;
		i++;
	}
	i = 0;
	while (buf[i] != '\n')
		i++;
	buf[i] = '\0';
	input = strtol(retp, &endptr, 10);
	if (*endptr != '\0' || *retp == 10)
		return INVALID_INPUT;
	if (input > INT_MAX)
		return INVALID_INPUT;
	if (input < INT_MIN)
		return INVALID_INPUT;
	if (input < 0)
		return INVALID_INPUT;
	*intp = (int) input;
	return VALID_INPUT;
}

int operation(int *a, int *count, int *input)
{

	for (*count = 0; *count < MAX; *count = *count + 1) {
		printf("enter your number:");
		if (!read_int(input)) {
			if (*a == *input) {
				printf("Hooray found number\n");
				break;
			} else if ((*a < *input) && (*input > 0 && *input < 99))
				printf("number greater\n");
			else if ((*a > *input) && (*input > 0 && *input < 99))
				printf("number is smaller\n");
			else if (*input <= 0 || *input >= 99) {
				*count = *count - 1;
				printf("Enter number between 0 & 99\n");
			}
		} else {
			printf("Error in parsing the input \r\n");
			*count = *count - 1;
			continue;
		}
	}
	return VALID_INPUT;
}
int main(void)
{
	srand(time(NULL));
	int count;
	int a;
	int input;

	a = rand() % 98 + 1;

	operation(&a, &count, &input);
	if (count == 7 && a != input) {
		printf("7 chances over\n");
		printf("The number is:%d\n", a);
		return INVALID_INPUT;
	}
	return VALID_INPUT;
}
