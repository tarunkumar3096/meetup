#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define INVALID_INPUT -2
#define VALID_INPUT 0
#define TIME 20
#define PTS 20

int get_operator(int *op, int *number1, int *number2)
{
	int answer = 0;

	if (*op == 1) {
		printf("%d + %d ? ", *number1, *number2);
		answer = *(number1) + *(number2);
	} else if (*op == 2) {
		printf("%d - %d ? ", *number1, *number2);
		answer = *(number1) - *(number2);
	}
	return answer;
}

int check_result(int *result, int *ans, int *timing, int *score)
{
	if (*(result) == *(ans)) {
		printf("Correct!\n");
		*(timing) = *(timing) - 1;
		*(score) = *(score) - 1;
	} else if (*(result) != *(ans)) {
		printf("Wrong!\n");
		*(timing) = *(timing) - 1;
	}
	return VALID_INPUT;
}

int read_int(int *intp)
{
	char *retp;
	char *endptr;
	long input;
	char buf[255];
	int i = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return INVALID_INPUT;
	while (1) {
		if (i > sizeof(buf)) {
			while ((getchar()) != '\n')
				;
			return INVALID_INPUT;
		}
		if (buf[i] == '\n')
			break;
		i++;
	}
	i = 0;
	while (i < strlen(buf)) {
		if (buf[i] == ' ')
			return INVALID_INPUT;
		i++;
	}
	i = 0;
	if (strlen(buf) == 1 && buf[i] == '\n')
		return INVALID_INPUT;
	while (buf[i] != '\n')
		i++;
	buf[i] = '\0';
	input = strtol(retp, &endptr, 10);
	if ((*endptr != '\n' && *endptr != '\0') || *retp == 10)
		return INVALID_INPUT;
	if (input > INT_MAX)
		return INVALID_INPUT;
	if (input < INT_MIN)
		return INVALID_INPUT;
	*intp = (int) input;
	return VALID_INPUT;
}

int operation(int *times, int *points)
{
	int answer = 0;
	int ret = 0;

	while (1) {
		int num1 = 0;
		int num2 = 0;
		int operator = 0;
		int result = 0;

		srand(time(0));
		num1 = rand() % 100;
		num2 = rand() % 100;
		answer = 0;
		operator = rand() % 2 + 1;
		while (1) {
			answer = get_operator(&operator, &num1, &num2);
			ret = read_int(&result);
			if (ret == -2) {
				printf("Incorrect input\n");
				continue;
			} else
				break;
		}
		check_result(&result, &answer, times, points);
		if (*times == 0)
			return VALID_INPUT;
	}
	return INVALID_INPUT;
}

int main(void)
{
	int times = TIME;
	int points = PTS;
	int check;

	check = operation(&times, &points);
	if (check == INVALID_INPUT)
		return INVALID_INPUT;
	printf("your score is = %d/%d\n", points, PTS);
	return VALID_INPUT;
}
