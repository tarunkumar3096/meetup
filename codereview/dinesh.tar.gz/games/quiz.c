#include <stdio.h>

#define COUNT 20

int generate_rand(int *num1, int *num2, int *opr)
{
	*num1 = rand() % 100;
	*num2 = rand() % 100;
	*opr = rand() % 2;

	return 0;
}

int get_result(int num1, int num2, char opr)
{
	switch (opr) {
	case '+':
		return (num1 + num2);
	case '-':
		return (num1 - num2);
	default:
		printf("Operator not specified\n");
	}
}

int check_input(void)
{
	int num;
	char tmp;

	while (1) {
		if (scanf("%d%c", &num, &tmp) != 2 || tmp != '\n') {
			while ((tmp = getchar()) != '\n')
				;
			printf("Enter only integer\n");
			continue;
		} else {
			break;
		}
	}
	return num;
}

int main(void)
{
	int num1;
	int num2;
	int index_val;
	int count = COUNT;
	int output;
	int success = 0;
	char operator[2] = {'+', '-'};

	srand(time(NULL));

	while (count--) {
		generate_rand(&num1, &num2, &index_val);
		printf("Chance: %d\n", (COUNT - count));
		printf("%d %c %d ? ", num1, operator[index_val], num2);

		output = get_result(num1, num2, operator[index_val]);

		if (output == check_input()) {
			printf("Correct!\n");
			success++;
		} else {
			printf("WRONG!\n");
		}

	}
	printf("Your score is %d/20\n", success);
	return 0;

}
