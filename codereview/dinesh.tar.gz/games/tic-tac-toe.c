#include <stdio.h>
#include <string.h>

#define ROW 3
#define COL 3

#define SUCCESS_X 11
#define SUCCESS_O 10
#define FAIL 0

int display_game(char (*game_array)[COL])
{
	int i;
	int j;

	printf(" -----------\n");
	for (i = 0; i < ROW; i++) {
		for (j = 0; j < COL; j++)
			printf("| %c ", game_array[i][j]);
		printf("|\n -----------\n");
	}
	return 0;
}

int check_pos(char (*game_array)[COL], int pos)
{
	int row;
	int col;

	if (pos >= 0 && pos < 9) {
		row = pos / ROW;
		col = pos % COL;
		if (game_array[row][col] == ' ')
			return 0;
		else
			return 1;
	} else {
		return 1;
	}
	return 0;
}

int mark_pos(char (*game_array)[COL], int pos, char value)
{
	int row = pos / ROW;
	int col = pos % COL;

	game_array[row][col] = value;
	display_game(game_array);

	return 0;
}

int check_row(char (*game_array)[COL])
{
	int i;
	int j;
	char tmp;
	int success = 0;

	for (i = 0; i < ROW; i++) {
		tmp = game_array[i][0];
		if (tmp == ' ')
			return FAIL;
		for (j = 0; j < COL; j++) {
			if (game_array[i][j] == tmp)
				success++;
		}
		if (success == ROW) {
			if (tmp == 'X')
				return SUCCESS_X;
			else if (tmp == 'O')
				return SUCCESS_O;
		}
		success = 0;
	}
	return FAIL;
}

int check_column(char (*game_array)[COL])
{
	int i;
	int j;
	char tmp;
	int success = 0;

	for (j = 0; j < COL; j++) {
		tmp = game_array[0][j];
		if (tmp == ' ')
			return FAIL;
		for (i = 0; i < ROW; i++) {
			if (game_array[i][j] == tmp)
				success++;
		}
		if (success == COL) {
			if (tmp == 'X')
				return SUCCESS_X;
			else if (tmp == 'O')
				return SUCCESS_O;
		}
		success = 0;
	}
	return FAIL;
}

int check_diagonal(char (*game_array)[COL])
{
	int i = 0;
	int j = 0;
	char tmp;
	int success = 0;

	tmp = game_array[i][j];
	if (tmp == ' ')
		return FAIL;
	for (i = 0; i < ROW; i++) {
		if (tmp == game_array[i][j++])
			success++;
	}
	if (success == ROW) {
		if (tmp == 'X')
			return SUCCESS_X;
		else if (tmp == 'O')
			return SUCCESS_O;
	}

	success = 0;
	i = 0;
	j = 2;
	tmp = game_array[i][j];
	if (tmp == ' ')
		return 0;
	for (i = 0; i < ROW; i++) {
		if (tmp == game_array[i][j--])
			success++;
	}
	if (success == ROW) {
		if (tmp == 'X')
			return SUCCESS_X;
		else if (tmp == 'O')
			return SUCCESS_O;
	}

	return FAIL;
}

int validate_game(char (*game_array)[COL])
{
	int ret;

	ret = check_row(game_array);
	if (ret == SUCCESS_X)
		return SUCCESS_X;
	else if (ret == SUCCESS_O)
		return SUCCESS_O;

	ret = check_column(game_array);
	if (ret == SUCCESS_X)
		return SUCCESS_X;
	else if (ret == SUCCESS_O)
		return SUCCESS_O;

	ret = check_diagonal(game_array);
	if (ret == SUCCESS_X)
		return SUCCESS_X;
	else if (ret == SUCCESS_O)
		return SUCCESS_O;

	return FAIL;

}

int game_operation(char (*game_array)[COL])
{
	int chance = ROW * COL;
	int turn;
	int pos;
	int ret;

	while (chance--) {
		turn = chance % 2;

		switch (turn) {
		case 0:
			printf("Player X: ");
			scanf("%d", &pos);
			__fpurge(stdin);
			pos--;
			ret = check_pos(game_array, pos);
			if (ret == 1) {
				printf("Enter valid position\n");
				chance++;
				continue;
			}
			mark_pos(game_array, pos, 'X');
			ret = validate_game(game_array);
			if (ret == SUCCESS_X)
				return SUCCESS_X;
			else if (ret == SUCCESS_O)
				return SUCCESS_O;

			break;
		case 1:
			printf("Player O: ");
			scanf("%d", &pos);
			__fpurge(stdin);
			pos--;
			ret = check_pos(game_array, pos);
			if (ret == 1) {
				printf("Enter valid position\n");
				chance++;
				continue;
			}
			mark_pos(game_array, pos, 'O');
			ret = validate_game(game_array);
			if (ret == SUCCESS_X)
				return SUCCESS_X;
			else if (ret == SUCCESS_O)
				return SUCCESS_O;
			break;
		}
	}
	return 0;
}

int main(void)
{
	char game_array[ROW][COL];
	int ret;

	memset(game_array, ' ', sizeof(game_array));
	display_game(game_array);

	ret = game_operation(game_array);
	if (ret == SUCCESS_X)
		printf("Player X won\n");
	else if (ret == SUCCESS_O)
		printf("Player O won\n");
	else
		printf("Match Draw\n");
	return 0;
}
