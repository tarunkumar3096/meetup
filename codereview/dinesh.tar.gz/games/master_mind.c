#include <stdio.h>
#include <stdio_ext.h>
#include <string.h>

#define MAX_DIG 4
#define CHANCE 8
#define SHUFFLE_COUNT 100

int shuffle_digits(char *digits)
{
	int index1;
	int index2;
	char tmp;
	int i = 0;
	int count = SHUFFLE_COUNT;

	srand(time(NULL));
	while (count--) {
		index1 = rand() % 10;
		index2 = rand() % 10;
		tmp = digits[index1];
		digits[index1] = digits[index2];
		digits[index2] = tmp;
	}

	return 0;
}

int check_isdigit(char *buf)
{
	int i = 0;
	int ret;

	for (i = 0; i < 4; i++) {
		if (isdigit(buf[i]) == 0)
			return 0;
	}
	return 1;
}

int get_user_input(char *user_input)
{
	char tmp;
	int ret;

	printf("Enter your guess:");
	fgets(user_input, MAX_DIG + 2, stdin);
	user_input[strcspn(user_input, "\n")] = '\0';

	while (strlen(user_input) != MAX_DIG || !(check_isdigit(user_input))) {
		__fpurge(stdin);
		printf("Enter valid input: ");
		fgets(user_input, MAX_DIG + 2, stdin);
		user_input[strcspn(user_input, "\n")] = '\0';
	}
	return 0;
}

int find_cow_bull(char *digits, char *user_input)
{
	int bull = 0;
	int cows = 0;
	int i = 0;
	int j;

	for (i = 0; i < MAX_DIG; i++) {
		if (digits[i] == user_input[i])
			bull++;

		j = i + 1;
		if (j == MAX_DIG)
			j = 0;
		while (i != j) {
			if (user_input[i] == digits[j++])
				cows++;
			if (j == MAX_DIG)
				j = 0;
		}
	}
	printf("Bulls: %d\t", bull);
	printf("Cows: %d\n", cows);

	return bull;
}

int main(void)
{
	char digits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	char user_input[MAX_DIG + 2] = {0};
	int ret;
	int count = CHANCE;
	int err = 1;

	shuffle_digits(digits);
	digits[4] = '\0';

	while (count--) {
		get_user_input(user_input);

		ret = find_cow_bull(digits, user_input);
		if (ret == MAX_DIG) {
			err = 0;
			break;
		}
	}
	if (err == 1)
		printf("Sorry, Real value is: %s\n", digits);
	else
		printf("You have successfully found the value\n");
	return 0;
}
