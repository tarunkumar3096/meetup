#include <stdio.h>
#include <string.h>

#define SIZE 10
#define CHANCE 7

int fail;
int success;
int rand_len;
int pos;

int print_hangman(char *hangman_arr)
{
	int i = 0;

	printf("\n");
	for (i = 0; i < rand_len; i++)
		printf("%c ", hangman_arr[i]);
	printf("\n");
	for (i = 0; i < rand_len; i++)
		printf("%c ", '_');
	printf("\n\n");
	return 0;
}

int print_diagram(void)
{
	char hangman_dia[7][35] = {"\n\n\n-+-", " |\n |\n |\n-+-",
				   " +---\n |\n |\n |\n-+-",
				   " +--+\n |  O\n |\n |\n-+-",
				   " +--+\n |  O\n |  |\n |\n-+-",
				   " +--+\n |  O\n | /|\\\n |\n-+-",
				   " +--+\n |  O\n | /|\\\n | / \\\n-+-"};

	printf("%s\n", hangman_dia[fail]);
	return 0;
}

int check_pos(int *pos_arr, int index)
{
	int i = 0;

	for (i = 0; i < pos; i++) {
		if (pos_arr[i] == index)
			return 1;
	}
	return 0;
}

char check_input(void)
{
	char tmp;
	char user_input;

	while (1) {
		if (scanf(" %c%c", &user_input, &tmp) != 2 || tmp != '\n') {
			while ((tmp = getchar()) != '\n')
				;
			printf("Enter Valid Input:");
			continue;
		} else {
			break;
		}
	}
	return user_input;
}

int modify_array(char *hangman_arr, char *rand_word, int *pos_arr)
{
	int i = 0;
	int flag = 0;
	char user_input;
	int ret;

	printf("Enter the letter: ");
	user_input = check_input();

	for (i = 0; i < rand_len; i++) {
		if (rand_word[i] == user_input) {
			if (check_pos(pos_arr, i) == 1) {
				flag++;
				continue;
			}
			hangman_arr[i] = user_input;
			pos_arr[pos++] = i;
			flag++;
			success++;
		}
	}
	if (flag == 0) {
		print_diagram();
		fail++;
		return 1;
	}
	return 0;
}

int hangman_operation(char *rand_word)
{
	char hangman_arr[rand_len];
	int pos_arr[rand_len];
	int i = 0;
	int ret;

	for (i = 0; i < rand_len; i++)
		hangman_arr[i] = ' ';
	print_hangman(hangman_arr);

	while (fail < CHANCE && success != rand_len) {
		ret = modify_array(hangman_arr, rand_word, pos_arr);
		if (ret != 1)
			print_hangman(hangman_arr);
	}
	return 0;
}

int main(void)
{
	int tmp;
	char rand_word[SIZE][] = {"systemcall", "programming", "gnome",
				    "virtual", "ubuntu", "linux", "embedded",
				    "emacs", "debianjessie", "debianstretch"};

	srand(time(NULL));
	tmp = rand() % SIZE;
	rand_len =  strlen(rand_word[tmp]);

	hangman_operation(rand_word[tmp]);

	return 0;
}
