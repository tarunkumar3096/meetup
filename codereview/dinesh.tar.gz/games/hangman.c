#include <stdio.h>
#include <string.h>

#define SIZE 10
#define CHANCE 7

int print_hangman(char *hangman_arr, int rand_len)
{
	int i = 0;

	printf("\n");
	for (i = 0; i < rand_len; i++)
		printf("%c ", hangman_arr[i]);
	printf("\n");
	for (i = 0; i < rand_len; i++)
		printf("%c ", '_');
	printf("\n\n");
	return 0;
}

int print_diagram(int fail)
{
	char hangman_dia[7][35] = {"\n\n\n-+-", " |\n |\n |\n-+-",
				   " +---\n |\n |\n |\n-+-",
				   " +--+\n |  O\n |\n |\n-+-",
				   " +--+\n |  O\n |  |\n |\n-+-",
				   " +--+\n |  O\n | /|\\\n |\n-+-",
				   " +--+\n |  O\n | /|\\\n | / \\\n-+-"};

	printf("%s\n", hangman_dia[fail]);
	return 0;
}

int check_pos(int *pos_arr, int index, int pos)
{
	int i = 0;

	for (i = 0; i < pos; i++) {
		if (pos_arr[i] == index)
			return 1;
	}
	return 0;
}

char check_input(void)
{
	char tmp;
	char user_input;

	while (1) {
		if (scanf(" %c%c", &user_input, &tmp) != 2 || tmp != '\n') {
			while ((tmp = getchar()) != '\n')
				;
			printf("Enter Valid Input:");
			continue;
		} else {
			break;
		}
	}
	return user_input;
}

int modify_array(char *hangman_arr, char *rand_word, int *pos_arr, int rand_len,
		 int *success, int *fail, int *pos)
{
	int i = 0;
	int flag = 0;
	char user_input;
	int ret;

	printf("Enter the letter: ");
	user_input = check_input();

	for (i = 0; i < rand_len; i++) {
		if (rand_word[i] == user_input) {
			if (check_pos(pos_arr, i, *pos) == 1) {
				flag++;
				continue;
			}
			hangman_arr[i] = user_input;
			pos_arr[*pos] = i;
			*pos = *pos + 1;
			flag++;
			*success = *success + 1;
		}
	}
	if (flag == 0) {
		print_diagram(*fail);
		*fail = *fail + 1;
		return 1;
	}
	return 0;
}

int hangman_operation(char *rand_word, int rand_len)
{
	char hangman_arr[rand_len];
	int pos_arr[rand_len];
	int i = 0;
	int ret;
	int fail = 0;
	int success = 0;
	int pos = 0;

	for (i = 0; i < rand_len; i++)
		hangman_arr[i] = ' ';
	print_hangman(hangman_arr, rand_len);

	while (fail < CHANCE && success != rand_len) {
		ret = modify_array(hangman_arr, rand_word,
				   pos_arr, rand_len, &success, &fail, &pos);
		if (ret != 1)
			print_hangman(hangman_arr, rand_len);
	}
	return 0;
}

int main(void)
{
	int tmp;
	int rand_len;
	char rand_word[SIZE][20] = {"systemcall", "programming", "gnome",
				    "virtual", "ubuntu", "linux", "embedded",
				    "emacs", "debianjessie", "debianstretch"};

	srand(time(NULL));
	tmp = rand() % SIZE;
	rand_len =  strlen(rand_word[tmp]);

	hangman_operation(rand_word[tmp], rand_len);

	return 0;
}
