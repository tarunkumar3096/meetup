#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <read_util.h>

#define IN_BUFF_SIZE 16
#define MAX_WORD_LEN 32

#define NO_OF_STEPS 7

#define NO_OF_ROWS 5
#define MAX_COLS 10

#define ERR_FILE -2
#define ERR_READ -3

#define HM_FILENAME "hangman"
#define WORD_FILENAME "words"

#define SUCCESS 0
#define FAILURE -1

static int get_hangman(char hangman[][NO_OF_ROWS][MAX_COLS])
{
	char *ret_str;
	FILE *fp;
	int ret;
	int i;
	int j;

	fp = fopen(HM_FILENAME, "r");
	if (fp == NULL)
		return ERR_FILE;

	for (i = 0; i < NO_OF_STEPS; i++) {
		for (j = 0; j < NO_OF_ROWS; j++) {
			ret_str = fgets(hangman[i][j], MAX_COLS, fp);
			if (ret_str == NULL)
				return ERR_READ;
		}
		if (fgetc(fp) != '\n')
			return ERR_READ;
	}

	ret = fclose(fp);
	if (ret == -1)
		return ERR_FILE;

	return SUCCESS;
}

static int get_word(char *word)
{
	FILE *fp;
	char *ret_str;
	int ret;
	struct stat buf;

	ret = stat(WORD_FILENAME, &buf);
	if (ret == -1)
		return ERR_FILE;

	fp = fopen(WORD_FILENAME, "r");
	if (fp == NULL)
		return ERR_FILE;

	ret = fseek(fp, rand() % buf.st_size, SEEK_SET);
	if (ret == -1)
		return ERR_READ;
	while (fgetc(fp) != '\n')
		;
	ret_str = fgets(word, MAX_WORD_LEN, fp);
	if (feof(fp)) {
		rewind(fp);
		ret_str = fgets(word, MAX_WORD_LEN, fp);
	}

	if (ret_str == NULL)
		return ERR_READ;
	word[strlen(word) - 1] = 0;

	ret = fclose(fp);
	if (ret == -1)
		return ERR_FILE;

	return SUCCESS;
}

static void str_toupper(char *str)
{
	int i;

	for (i = 0; str[i]; i++)
		if (islower(str[i]))
			str[i] = toupper(str[i]);
}

static char *my_strcasestr(char *str, char *substr)
{
	char *match;
	char str_up[strlen(str)];
	char substr_up[strlen(substr)];

	strcpy(str_up, str);
	str_toupper(str_up);

	strcpy(substr_up, substr);
	str_toupper(substr_up);

	match = strstr(str_up, substr_up);
	if (match == NULL)
		return NULL;

	return str + (match - str_up);
}

static int fill_str(char *dest, char *src, char *filler)
{
	int count = 0;
	int found_at = 0;
	char *match;

	match = my_strcasestr(src, filler);
	if (match == NULL)
		return FAILURE;

	do {
		found_at = match - src;
		memcpy(dest + found_at, match, strlen(filler));

		++count;

		match = my_strcasestr(match + strlen(filler), filler);
	} while (match);

	return count;
}

static int fill_char(char *dest, char *src, char filler)
{
	char filler_str[] = {filler, '\0'};

	return fill_str(dest, src, filler_str);
}

static int replace_char(char *str, char old_c, char new_c)
{
	char *at;
	int count = 0;

	if (old_c == 0)
		return count;

	while (1) {
		at = strchr(str, old_c);
		if (at == NULL)
			break;
		*at = new_c;
		++count;
	}

	return count;
}

int main(void)
{
	char hangman[NO_OF_STEPS][NO_OF_ROWS][MAX_COLS];
	char user_in[IN_BUFF_SIZE];
	char word[MAX_WORD_LEN];
	char dest[MAX_WORD_LEN];
	int ret;
	int i = 0;
	int j;

	srand(time(NULL));

	ret = get_hangman(hangman) || get_word(word);
	if (ret != SUCCESS) {
		printf("Internal error\n");
		return -1;
	}
	memset(dest, '_', strlen(word));
	dest[strlen(word)] = 0;

	replace_char(word, ' ', '_');

	while (i < NO_OF_STEPS) {

		for (j = 0; dest[j]; j++)
			printf("%c ", dest[j]);
		printf("\n");
		if (!strcmp(dest, word))
			break;

		printf("\nEnter a letter: ");
		ret = read_string(user_in, sizeof(user_in));
		if (ret == FAILURE) {
			printf("\nForce quit\n");
			exit(EXIT_SUCCESS);
		}
		if (strlen(user_in) > 1) {
			printf("Err! One character at a time!!\n");
			continue;
		}

		ret = fill_char(dest, word, *user_in);
		if (ret == -1) {
			for (j = 0; j < NO_OF_ROWS; j++)
				printf("%s", hangman[i][j]);
			++i;
		}
	}

	if (i == NO_OF_STEPS) {
		printf("\nYou ran out of chances!\n");
		printf("Word: %s\n\n", word);
	} else {
		printf("\nCongrats! You found the word\n\n");
	}

	return 0;
}
