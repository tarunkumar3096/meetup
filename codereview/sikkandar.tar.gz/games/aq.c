#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <read_util.h>

#define SUCCESS 0
#define FAILURE -1

#define REPETITIONS 20

#define EXPR_LEN_MAX 10

#define OPERAND_VAL_MAX 99

enum index_of_ops {
	ADD = 0,
	SUB = 1
};
#define OPERATORS {[ADD] = "+", [SUB] = "-"}
#define OPERATOR_COUNT_MAX 2
#define OPERATOR_LEN_MAX 2

static int get_rand_num(int min, int max)
{
	if (min > max) {
		int temp = min;

		min = max;
		max = temp;
	}

	return rand() % (max + 1 - min) + min;
}

static int get_expression(char *expr_buf, int buf_len)
{
	int i;
	int rand_int;
	int expr_len = 0;
	char pattern[] = "non"; /* n - number, o - operator */
	char list_of_ops[][OPERATOR_LEN_MAX] = OPERATORS;

	expr_buf[0] = 0;

	for (i = 0; pattern[i]; i++) {

		switch (pattern[i]) {
		case 'n':
			rand_int = get_rand_num(0, OPERAND_VAL_MAX);
			expr_len += sprintf(strrchr(expr_buf, 0), "%d ",
					    rand_int);
			break;

		case 'o':
			rand_int = get_rand_num(0, OPERATOR_COUNT_MAX - 1);
			expr_len += sprintf(strrchr(expr_buf, 0), "%s ",
					list_of_ops[rand_int]);
			break;
		}

		if (expr_len >= buf_len)
			return FAILURE;

	}

	return SUCCESS;
}

static int evaluate_expression(char *expr, int *result)
{
	int ret;
	int operand1;
	int operand2;
	char operator[OPERATOR_LEN_MAX];
	char list_of_ops[][OPERATOR_LEN_MAX] = OPERATORS;

	ret =
		sscanf(expr, "%d %c %d",
		       &operand1, operator,  &operand2);
	if (ret == 0)
		return FAILURE;

	if (!strcmp(operator, list_of_ops[ADD]))
		*result = operand1 + operand2;
	else if (!strcmp(operator, list_of_ops[SUB]))
		*result = operand1 - operand2;
	else
		return FAILURE;

	return SUCCESS;
}

int main(void)
{
	int ret;
	int i = 0;
	int result;
	int user_in;
	int score = 0;
	char *endptr;
	char user_in_buf[10];
	char expr[EXPR_LEN_MAX];

	srand(time(NULL));

	while (i < REPETITIONS) {

		ret = get_expression(expr, sizeof(expr));
		if (ret == FAILURE) {
			printf("Failed to generate expression\n");
			return FAILURE;
		}

		ret = evaluate_expression(expr, &result);
		if (ret == FAILURE) {
			printf("Internal error. Re-generating expression\n");
			continue;
		}

		printf("%s= ? ", expr);

		while (1) {
			ret = read_string(user_in_buf, sizeof(user_in_buf));
			if (ret == -1) {
				printf("\nForce quit\n");
				exit(EXIT_SUCCESS);
			}
			user_in = (int)strtol(user_in_buf, &endptr, 10);
			if (*endptr != 0) {
				printf("Invalid input. Enter again\n");
				printf("%s= ? ", expr);
			} else {
				break;
			}
		};

		if (user_in == result) {
			++score;
			printf("Correct!\n");
		} else {
			printf("Wrong!\n");
		}

		++i;
	}

	printf("Your score is %d/%d.\n", score, REPETITIONS);

	return SUCCESS;
}
