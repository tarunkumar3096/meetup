#ifndef READ_UTIL
#define READ_UTIL

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int read_string(char*, int);

#endif
