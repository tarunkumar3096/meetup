#include <read_util.h>

int read_string(char *string, int buffer_size)
{
	int length;
	char *retp;

	do {
		retp = fgets(string, buffer_size + 1, stdin);
		if (retp == NULL)
			return -1;
	} while (*retp == '\n');

	length = strlen(retp);
	if (retp[length - 1] == '\n')
		retp[length - 1] = '\0';
	else
		while (getchar() != '\n')
			;

	return 0;
}
