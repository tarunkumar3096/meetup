#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <read_util.h>

#define NUM_DIGITS 4

#define NUM_STR_LEN (NUM_DIGITS + 1)
#define STR_DIGITS STR(NUM_DIGITS)

#define IN_BUFF_SIZE 16
#define REPETITIONS 8
#define SHUFFLE_FACTOR 100

#define EXPAND(x) #x
#define STR(x) EXPAND(x)

#define SUCCESS 0
#define FAILURE -1

static void swap(char *a, char *b)
{
	char temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

static int get_rand_num(int min, int max)
{
	if (min > max) {
		int temp = min;

		min = max;
		max = temp;
	}

	return rand() % (max + 1 - min) + min;
}

static int randomize(char *dest, char *src, int dest_len)
{
	int i;
	int rand_num1;
	int rand_num2;
	int max_range = strlen(src) - 1;

	if (max_range < dest_len - 1)
		return FAILURE;

	for (i = 0; i < SHUFFLE_FACTOR; i++) {

		rand_num1 = get_rand_num(0, max_range);
		do {
			rand_num2 = get_rand_num(0, max_range);
		} while (rand_num1 == rand_num2);

		swap(src+rand_num1, src+rand_num2);
		if (src[0] == '0')
			swap(src, src + dest_len);
	}

	sprintf(dest, "%."STR_DIGITS"s", src);
	return SUCCESS;
}

static int find(char *str, char c)
{
	char *pos;

	pos = strchr(str, c);
	if (pos == NULL)
		return FAILURE;

	return pos - str;
}

int main(void)
{
	int i = 0;
	int ret;
	char digits[] = "0123456789";
	char user_in[IN_BUFF_SIZE];
	char rand_num_str[NUM_STR_LEN];

	srand(time(NULL));

	ret = randomize(rand_num_str, digits, NUM_DIGITS - 1);
	if (ret == FAILURE) {
		printf("Error generating random number\n");
		exit(EXIT_FAILURE);
	}

	while (i < REPETITIONS) {
		int j;
		int cows = 0;
		int bulls = 0;
		char *endptr;

		printf("Enter your guess: ");
		ret = read_string(user_in, sizeof(user_in));
		if (ret == FAILURE) {
			printf("\nForce quit\n");
			exit(EXIT_SUCCESS);
		}
		strtol(user_in, &endptr, 10);
		if (strlen(user_in) != NUM_DIGITS || *endptr != 0) {
			printf("Enter a %d digit number\n", NUM_DIGITS);
			continue;
		}

		if (!strcmp(user_in, rand_num_str))
			break;

		for (j = 0; user_in[j]; j++) {
			if (rand_num_str[j] == user_in[j])
				++bulls;
			else if (find(rand_num_str, user_in[j]) != FAILURE)
				++cows;
		}

		printf("%d bull%c, %d cow%c\n",
		       bulls, bulls > 1 ? 's' : 0,  cows, cows > 1 ? 's' : 0);
		++i;
	}

	if (i == REPETITIONS) {
		printf("\nYou ran out of chances!\n");
		printf("Number: %s\n\n", rand_num_str);
	} else {
		printf("\nCongrats! You found the number\n\n");
	}

	return EXIT_SUCCESS;
}
