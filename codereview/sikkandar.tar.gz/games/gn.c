#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define CHANCES 7

#define RAND_RANGE 100

#define INT_MAX (RAND_RANGE-1)
#define INT_MIN 0

#define SUCCESS 0
#define FAILURE -1
#define QUIT -1
#define ERR_READ -2

#define IN_BUF_SIZE 16

void remove_char(char *array, char removable, int len)
{
	int i;
	int index = 0;

	for (i = 0 ; i < len-1 ; i++)
		if (*(array+i) != removable) {
			*(array+index) = *(array+i);
			index++;
		}
}


int read_int(int *intp)
{
	char buf[IN_BUF_SIZE];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return QUIT;

	remove_char(&buf[0], ' ', sizeof(buf));

	if (strchr(buf, '\n') == NULL)
		while (getchar() != '\n')
			;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n' || *retp == '\n')
		return ERR_READ;

	if (input > INT_MAX)
		return ERR_READ;

	if (input < INT_MIN)
		return ERR_READ;

	*intp = (int)input;

	return SUCCESS;
}

int play_game(int rand_num, int chances)
{
	int guessed;
	int ret;
	int loop_count = 1;

	do {
		printf("Make your guess no.%d:\t", loop_count);
		ret = read_int(&guessed);
		if (ret == SUCCESS) {
			if (guessed < rand_num)
				printf("Your number is smaller\n");
			else if (guessed > rand_num)
				printf("Your number is larger\n");
			else
				return 0;
		} else if (ret == ERR_READ) {
			printf("You must enter a valid positive integer\n");
			continue;
		} else if (ret == QUIT) {
			printf("\nForce quit\n");
			exit(EXIT_SUCCESS);
		}
		++loop_count;
	} while (loop_count <= chances);

	return FAILURE;
}

int main(void)
{
	int rand_num;
	int result;

	srand(time(NULL));
	rand_num = rand()%RAND_RANGE;

	printf("Play game by entering a valid positive integer\n");
	printf("( %d to %d is considered valid )\n", INT_MIN, INT_MAX);

	result = play_game(rand_num, CHANCES);

	if (result == FAILURE)
		printf("Hurray! You found the number!\n");
	else
		printf("Sorry! You're out of chances :(\n");

	return SUCCESS;
}

