#include <stdio.h>
#include <string.h>

#define SUCCESS 0
#define FAILURE -1

#define NO_OF_RC 3
#define GRID_SIZE (NO_OF_RC * NO_OF_RC)

#define X 'x'
#define O 'o'
#define EMPTY ' '

static int draw3x3grid(char *conts, int len)
{
	char horizontal_border[] = " ----------- ";
	int i;

	if (len != GRID_SIZE)
		return FAILURE;

	printf("%s\n", horizontal_border);

	for (i = 0; i < GRID_SIZE; i += NO_OF_RC) {
		printf("| %c | %c | %c |\n", conts[i+0],
		       conts[i+1], conts[i+2]);
		printf("%s\n", horizontal_border);
	}

	return SUCCESS;
}

static void position_grid(void)
{
	int i;
	char conts[GRID_SIZE];

	for (i = 0; i < GRID_SIZE; ++i)
		conts[i] = i + '1';

	draw3x3grid(conts, GRID_SIZE);
}

static char check_horizontal(char *conts, int grid_size)
{
	int i;
	int j;
	int loop_count;

	if (grid_size != GRID_SIZE)
		return FAILURE;

	for (i = 0; i < GRID_SIZE; i += NO_OF_RC) {
		loop_count = NO_OF_RC - 1;
		for (j = i; loop_count; j++, --loop_count)
			if ((conts[j] == EMPTY) || (conts[j] != conts[j+1]))
				break;
		if (loop_count == 0)
			return conts[j];
	}

	return 0;
}

static char check_vertical(char *conts, int grid_size)
{
	int i;
	int j;
	int loop_count;

	if (grid_size != GRID_SIZE)
		return FAILURE;

	for (i = 0; i < NO_OF_RC; i++) {
		loop_count = NO_OF_RC - 1;
		for (j = i; loop_count; j += NO_OF_RC, --loop_count)
			if ((conts[j] == EMPTY) ||
			    (conts[j] != conts[j+NO_OF_RC]))
				break;
		if (loop_count == 0)
			return conts[j];
	}

	return 0;
}

static char check_diagonal(char *conts, int grid_size)
{
	int i;
	int loop_count;

	if (grid_size != GRID_SIZE)
		return FAILURE;

	loop_count = NO_OF_RC - 1;
	for (i = 0; loop_count; i += NO_OF_RC + 1, --loop_count)
		if ((conts[i] == EMPTY) ||
		    (conts[i] != conts[i + NO_OF_RC + 1]))
			break;
	if (loop_count == 0)
		return conts[i];

	loop_count = NO_OF_RC - 1;
	for (i = NO_OF_RC - 1; loop_count; i += NO_OF_RC - 1, --loop_count)
		if ((conts[i] == EMPTY) ||
		    (conts[i] != conts[i + NO_OF_RC - 1]))
			break;
	if (loop_count == 0)
		return conts[i];

	return 0;
}

static int check_win(char *conts, int grid_size)
{
	int i;
	int ret;

	char (*checks[])(char *, int) = {check_horizontal,
					 check_vertical, check_diagonal};

	for (i = 0; i < sizeof(checks)/sizeof(int *); i++) {
		ret = checks[i](conts, grid_size);
		if (ret != 0)
			return ret;
	}

	return 0;
}

int main(void)
{
	int i = 0;
	int user_in;
	int win_status;
	char avails[] = {X, O};
	char conts[GRID_SIZE];
	int no_of_players = sizeof(avails);

	printf("\nAvailable positions in the grid are:\n");
	position_grid();

	printf("\nGame starts..\n");
	memset(conts, EMPTY, GRID_SIZE);
	draw3x3grid(conts, GRID_SIZE);

	while (i < GRID_SIZE) {
		printf("\nPlayer %d enters '%c' at position ",
		       i % no_of_players + 1, avails[i % no_of_players]);
		if (scanf("%d", &user_in) == 0) {
			printf("\nEnter valid integer\n");
			getchar();
			continue;
		}

		if (user_in < 1 || user_in > GRID_SIZE) {
			printf("Invalid position!\n");
			printf("Enter in range 1 to %d\n", GRID_SIZE);
			continue;
		}

		if (conts[user_in - 1] != EMPTY) {
			printf("Position %d is already filled. Retry\n",
			       user_in);
			continue;
		}

		conts[user_in - 1] = avails[i % no_of_players];
		draw3x3grid(conts, GRID_SIZE);

		win_status = check_win(conts, GRID_SIZE);
		if (win_status != 0)
			break;

		++i;
	}

	if (i == GRID_SIZE)
		printf("\nGame over! Nobody wins!!\n\n");
	else
		printf("\nPlayer %d won!!\n\n", i % no_of_players + 1);

	return 0;
}
