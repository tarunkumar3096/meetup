#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define CHANCES 7
#define MAX_FRUITS 13

static void draw_hangman(int state)
{
	enum states {one = 1, two, three,
		     four, five, six, seven};

	switch (state) {
	case one:
		printf("\n\n\n\n-+-\n\n");
		break;
	case two:
		printf("\n |\n |\n |\n-+-\n\n");
		break;
	case three:
		printf(" +--+\n |\n |\n |\n-+-\n\n");
		break;
	case four:
		printf(" +--+\n |  0\n |\n |\n-+-\n\n");
		break;
	case five:
		printf(" +--+\n |  0\n |  |\n |\n-+-\n\n");
		break;
	case six:
		printf(" +--+\n |  0\n | /|\\\n |\n-+-\n\n");
		break;
	case seven:
		printf(" +--+\n |  0\n | /|\\\n | / \\\n-+-\n\n");
		break;
	default:
		break;
	}
}

static void update_letter_or_state(char *fruit, char letter, char *letters_and_blanks,
			    int num_of_letters, int *state)
{
	int index;
	int flag = 0;

	for (index = 0; index < num_of_letters; index++) {
		if (fruit[index] == letter) {
			letters_and_blanks[index] = letter;
			flag = 1;
		}
	}

	if (flag == 0)
		(*state)++;
}

static int if_complete(char *letters_and_blanks, int num_of_letters)
{
	int index;

	for (index = 0; index < num_of_letters; index++)
		if (letters_and_blanks[index] == '_')
			return 0;

	return 1;
}

static void print_letters_and_blanks(char *arr, int len)
{
	int index;

	for (index = 0; index <= len; index++)
		printf("%c ", arr[index]);

	printf("\n\n");
}

int main(void)
{
	int random;
	int state = 0;
	int num_of_letters;
	char letter;
	char *fruits[MAX_FRUITS] = {"apricot", "blackberry", "cherry",
				    "dragonfruit", "fig", "grape",
				    "raisin", "guava", "mango",
				    "mulberry", "peach", "plum", "raspberry"};

	srand(time(NULL));
	random = rand() % MAX_FRUITS;

	num_of_letters = strlen(fruits[random]);

	char letters_and_blanks[num_of_letters + 1];

	letters_and_blanks[num_of_letters] = 0;
	memset(letters_and_blanks, '_', num_of_letters);

	printf("\n----FRUITS----\n\n");

	while (state < CHANCES) {
		if (state)
			draw_hangman(state);

		print_letters_and_blanks(letters_and_blanks, num_of_letters);

		printf("Enter a letter: ");
		scanf("%c", &letter);
		letter = tolower(letter);
		while (getchar() != '\n')
			;

		update_letter_or_state(fruits[random], letter,
				       letters_and_blanks, num_of_letters,
				       &state);

		if (if_complete(letters_and_blanks, num_of_letters)) {
			printf("\n%s\n", letters_and_blanks);
			printf("Hurray! You found it.\n\n");
			return 1;
		}
	}

	draw_hangman(state);
	printf("Answer is %s\n", fruits[random]);
	printf("Better luck next time.\n\n");

	return 0;
}
