#include <stdio.h>
#include <ctype.h>

#define SIZE 3
#define TURNS (SIZE * SIZE)
#define X 1
#define Y 2
#define X_WON 1
#define Y_WON 2
#define NOBODY_WON 0

static void get_input(int *input, int turn)
{
	if (turn == X)
		printf("Input the position to mark 'x': ");
	else
		printf("Input the position to mark 'o': ");

	if (scanf("%d", input) != 1 || getchar() != '\n') {
		while (getchar() != '\n')
			;
		printf("Invalid input! Try again.\n");
		get_input(input, turn);
	}
	if (!(*input > 0 && *input <= (SIZE * SIZE))) {
		printf("Invalid input! Try again.\n");
		get_input(input, turn);
	}
}

static int validate_row(int *grid, int position)
{
	int index;
	int xcount = 0;
	int ycount = 0;
	int row_start_pos;

	row_start_pos = position / SIZE;

	for (index = (row_start_pos * SIZE);
	     index <  ((row_start_pos * SIZE) + SIZE);
	     index++) {
		if (grid[index] == 'x')
			xcount++;
		if (grid[index] == 'o')
			ycount++;
	}
	if (xcount == SIZE)
		return X;
	if (ycount == SIZE)
		return Y;

	return 0;
}

static int validate_column(int *grid, int position)
{
	int xcount = 0;
	int ycount = 0;
	int index;
	int offset = 0;

	offset = position % SIZE;

	for (index = offset; index < (SIZE * SIZE); index = index + SIZE) {
		if (grid[index] == 'x')
			xcount++;
		if (grid[index] == 'o')
			ycount++;
	}
	if (xcount == SIZE)
		return X;
	if (ycount == SIZE)
		return Y;

	return 0;
}

static int validate_diagonals(int *grid)
{
	int index;
	int i;
	int xcount;
	int ycount;

	xcount = 0;
	ycount = 0;
	for (index = 0, i = 0; i < SIZE; index = index + SIZE, i++) {
		if (grid[index + i] == 'x')
			xcount++;
		if (grid[index + i] == 'o')
			ycount++;
	}
	if (xcount == SIZE)
		return X;
	if (ycount == SIZE)
		return Y;

	xcount = 0;
	ycount = 0;
	for (index = 0, i = SIZE - 1; i > -1; index = index + SIZE, i--) {
		if (grid[index + i] == 'x')
			xcount++;
		if (grid[index + i] == 'o')
			ycount++;
	}
	if (xcount == SIZE)
		return X;
	if (ycount == SIZE)
		return Y;

	return 0;
}

static int check_for_winner(int *grid, int position)
{
	int result;

	result = validate_row(grid, position);
	if (result == X || result == Y)
		return result;

	result = validate_column(grid, position);
	if (result == X || result == Y)
		return result;

	result = validate_diagonals(grid);
	if (result == X || result == Y)
		return result;

	return 0;
}

static void draw_grid(int *grid)
{
	int index;

	printf("\n");
	for (index = 0; index < (SIZE*SIZE); index++) {
		if (grid[index] == 'x' || grid[index] == 'o')
			printf("|%c ", grid[index]);
		else
			printf("|%d ", grid[index]);
		if ((index+1) % SIZE == 0)
			printf("|\n");
	}
}

static int is_position_marked(int *grid, int pos)
{
	if (grid[pos] == 'x' || grid[pos] == 'o') {
	        printf("Position already occupied! Try again.\n");
		return 1;
	}

	return 0;
}

static void grid_init(int *grid)
{
	int index;

	for (index = 0; index < (SIZE * SIZE); index++)
		grid[index] = index + 1;
}

int main(void)
{
	int turns = 0;
	int turn = X;
	int result;
        int input;
	int grid[SIZE*SIZE];

	grid_init(grid);

	draw_grid(grid);

	while (turns < TURNS) {
		get_input(&input, turn);
		if (is_position_marked(grid, input--))
			continue;

	        if (turn == X) {
			grid[input] = 'x';
			turn = Y;
		} else {
			grid[input] = 'o';
			turn = X;
		}

		draw_grid(grid);

		result = check_for_winner(grid, input);
		if (result == X) {
			printf("'x' won..\n");
			return X_WON;
		}
		if (result == Y) {
			printf("'o' won..\n");
			return Y_WON;
		}
		turns++;
	}
	printf("Nobody won..\n");

	return NOBODY_WON;
}
