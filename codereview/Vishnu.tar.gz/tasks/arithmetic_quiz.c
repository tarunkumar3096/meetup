#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

#define CHANCES 20

static int read_int(int *intp)
{
	char buf[16];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return -2;

	if (input > INT_MAX)
		return -2;

	if (input < INT_MIN)
		return -2;

	*intp = (int) input;

	return 0;
}

static int error_occured(int error_num)
{
	if (error_num == -1)
		printf("Reading input failed\n");
	else if (error_num == -2)
		printf("Input should be within the range of INT\n");
	else
		return false;

	while (getchar()!= '\n')
		;

	return true;
}

static int generate_expression()
{
	int num0;
	int num1;
	int result;

	srand(time(NULL));

	while (!((num0 = rand() % 100) > 9 &&
		 (num1 = rand() % 100) > 9))
		;

	if ((random() % 2) == 0) {
		printf("\n%d + %d ? ", num0, num1);
		result = num0 + num1;
	} else {
		printf("\n%d - %d ? ", num0, num1);
		result = num0 - num1;

	}

	return result;
}

static void check_result(int *a, int *b, int *score)
{
	if (*a == *b) {
		printf("Correct!\n");
		(*score)++;
	} else {
		printf("Wrong!\n");
	}
}

int main()
{
	int tries = 0;
	int score = 0;
	int num;
	int expression_result;
	
	while (tries++ < CHANCES) {
		expression_result = generate_expression();

		if (error_occured(read_int(&num)))
			continue;
		
		check_result(&expression_result, &num, &score);
	}

	printf("\nYour score is %d/20\n\n", score);
	
	return 0;
}
