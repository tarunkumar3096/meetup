#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

#define CHANCES 7

static int read_int(int *intp)
{
	char buf[16];
	char *retp;
	char *endptr;
	long input;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return -2;

	if (input > INT_MAX)
		return -2;

	if (input < INT_MIN)
		return -2;

	*intp = (int) input;

	return 0;
}

static int error_occured(int error_num)
{
	if (error_num == -1)
		printf("Reading input failed\n");
	else if (error_num == -2)
		printf("Input should be within the range of INT\n");
	else
		return false;

	while (getchar()!= '\n')
		;

	return true;
}

int main()
{
	int tries = 0;
	int num;
        int random;
	int flag = 0;

	srand(time(NULL));
	random = rand() % 100;
        
	while (tries < CHANCES) {
		printf("\nEnter your number: ");
		if (error_occured(read_int(&num)))
			continue;

		if (num > random) {			
			printf("Your number is larger.\n");
		} else if (num < random) {
			printf("Your number is smaller.\n");
		} else {
			flag = 1;
			break;
		}
		tries++;
        }
	if (flag == 1)
		printf("\nHurray! You found the number!\n\n");
	else
		printf("\nBetter luck next time.\n\n");

	return 0;
}
