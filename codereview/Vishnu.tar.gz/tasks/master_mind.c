#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>
#include <stdlib.h>

#define NUM_OF_SECRET_DIGITS 4
#define BULL 1
#define COW 0
#define CHANCES 8

static int *marked;
static int marked_count;

static int read_int(int *intp)
{
	char buf[16];
	char *retp;
	char *endptr;
	long input;
	int digits = 0;
	int i = 0;

	retp = fgets(buf, sizeof(buf), stdin);
	if (retp == NULL)
		return -1;

	input = strtol(retp, &endptr, 10);
	if (*endptr != '\n')
		return -2;

	if (input > INT_MAX)
		return -2;

	if (input < INT_MIN)
		return -2;

	while (buf[i++] != '\n')
		digits++;
	if (digits != NUM_OF_SECRET_DIGITS)
		return -3;

	*intp = (int) input;

	return 0;
}

static int error_occured(int error_num)
{
	int flag = 0;

	if (error_num == -1) {
		printf("Reading input failed\n");
	} else if (error_num == -2) {
		printf("Input should be within the range of INT\n");
		flag = 1;
	} else if (error_num == -3) {
		printf("Input should have exactly %d digits\n", NUM_OF_SECRET_DIGITS);
	} else {
		return false;
	}
	if (flag == 1)
		while (getchar() != '\n')
			;

	return true;
}


static void shuffle(char *arr)
{
        char temp;
	int shuffles = 0;
	int i;
	int j;

	while (shuffles++ < 100) {
		i = rand() % 10;
		j = rand() % 10;

		temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
}

static int is_in_secret_number(char *secret_num, int value)
{
	int loops = 0;

	while (loops < NUM_OF_SECRET_DIGITS)
		if ((secret_num[loops++] - '0') == value)
			return 1;

	return 0;
}

static int mark(int digit, int bc)
{
	int index;

	if (bc == COW)
		for (index = 0; index < marked_count; index++)
			if (marked[index] == digit)
				return 0;

	marked[marked_count++] = digit;

	return 1;
}

static void find_bull_count(char *secret_num, int input, int *bulls)
{
	int i = NUM_OF_SECRET_DIGITS;
	int digit;
	int secret_digit;

	while (i-- > 0) {
		digit = input % 10;
		input = input / 10;
		secret_digit = secret_num[i] - '0';
		if (secret_digit == digit && mark(digit, BULL))
			(*bulls)++;
	}
}

static void find_cow_count(char *secret_num, int input, int *cows)
{
	int i = NUM_OF_SECRET_DIGITS;
	int digit;

	while (i-- > 0) {
		digit = input % 10;
		input = input / 10;
		if (mark(digit, COW))
			if (is_in_secret_number(secret_num, digit))
				(*cows)++;
	}
}

static int all_matching_digits(char *secret_num, int input, int *bulls, int *cows)
{
	marked = malloc(sizeof(int) * NUM_OF_SECRET_DIGITS);
	marked_count = 0;

	find_bull_count(secret_num, input, bulls);
	if (*bulls == NUM_OF_SECRET_DIGITS)
		return 1;

	find_cow_count(secret_num, input, cows);

	marked_count = 0;
	free(marked);

	return 0;
}

int main(void)
{
	int chances = 0;
        int bulls = 0;
	int cows = 0;
	int input;
	char secret_num[NUM_OF_SECRET_DIGITS + 1];
	char digits[] = {'0', '1', '2', '3', '4',
			 '5', '6', '7', '8', '9', '\0'};

	srand(time(NULL));

        shuffle(digits);

	strncpy(secret_num, digits, NUM_OF_SECRET_DIGITS);
	secret_num[NUM_OF_SECRET_DIGITS + 1] = '\0';

	while (chances < CHANCES) {
		printf("\nEnter your guess: ");
		if (error_occured(read_int(&input)))
			continue;

		if (all_matching_digits(secret_num, input, &bulls, &cows)) {
			printf("Guessed right!\n\n");
			return 1;
		}
		printf("%d bull(s), %d cow(s)\n", bulls, cows);
		bulls = cows = 0;
		chances++;
	}

	printf("\nsecret digit: %s\n", secret_num);
	printf("Better luck next time.\n\n");

	return 0;
}
