#include <stdio.h>

void print_arr(int *arr, int arr_len)
{
	int i;

	for (i = 0; i < arr_len; ++i)
		printf("%d  ", arr[i]);
	printf("\n");
}

void swap(int *a, int *b)
{
#ifdef BREAK
	printf("swapping %d %d\n", *a, *b);
#endif
	int temp = *a;
	*a = *b;
	*b = temp;
}

void bubble_sort(char const **str_elements, int arr_len)
{
	int i;
	int j;
	int comps = 0;
	int swaps = 0;
	int arr[arr_len];

	for (i = 0; i < arr_len; ++i)
		arr[i] = atoi(str_elements[i]);

	for (i = 0; i < arr_len - 1; ++i) {
		for (j = 0; j < arr_len - i - 1; ++j) {
			++comps;
#ifdef BREAK
			getchar();
			printf("Comparing   %d   %d\n", arr[j], arr[j+1]);
#endif
			if (arr[j] > arr[j+1]) {
				++swaps;
				swap(&arr[j], &arr[j+1]);
#ifdef BREAK
				getchar();
				print_arr(arr, arr_len);
#endif
			}
		}
#ifdef BREAK
		printf("---------------------------------------------------------\n");
#endif
	}

	print_arr(arr, arr_len);

#ifdef STATS
	printf("Elements %d\n", arr_len);
	printf("Comparisons %d\n", comps);
	printf("Swaps %d\n", swaps);
#endif
}

void selection_sort(char const **str_elements, int arr_len)
{
	int i;
	int j;
	int min_index;
	int comps = 0;
	int swaps = 0;
	int arr[arr_len];

	for (i = 0; i < arr_len; ++i)
		arr[i] = atoi(str_elements[i]);

	for (i = 0; i < arr_len - 1; ++i) {
		min_index = i;
		for (j = i + 1; j < arr_len; ++j) {
			++comps;
			if (arr[j] < arr[min_index])
				min_index = j;
		}
#ifdef BREAK
		printf("Min element   %d\n", arr[min_index]);
		getchar();
#endif
		if (i != min_index) {
			++swaps;
			swap(&arr[i], &arr[min_index]);
#ifdef BREAK
			print_arr(arr, arr_len);
			getchar();
#endif
		}
	}

	print_arr(arr, arr_len);

#ifdef STATS
	printf("Elements %d\n", arr_len);
	printf("Comparisons %d\n", comps);
	printf("Swaps %d\n", swaps);
#endif
}

int main(int argc, char const *argv[])
{

#if defined BUB
	bubble_sort(argv + 1, argc - 1);
#elif defined SEL
	selection_sort(argv + 1, argc - 1);
#endif

	return 0;
}
